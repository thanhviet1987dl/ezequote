﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmVatTu : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmVatTu()
        {
            InitializeComponent();
            LoadDMVatTu();
            LoadDVT();
            
        }

        public int _IDChiTietVatTu { get; set; }
        public string _KiemTraThemMoi { get; set; }
        void LoadDMVatTu()
        {
            searchVatTu.Columns.Clear();
            string[] fields = { "ID", "TenVatTu" };

            string[] captions = { "ID", "Equipment" };

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                searchVatTu.Columns.Add(col);
                searchVatTu.Columns[i].Visible = true;
                searchVatTu.Columns[i].OptionsColumn.AllowEdit = false;
            }
            searchVatTu.Columns["ID"].Visible = false;

            var result = from c in ep.VatTus select new { c.ID, c.TenVatTu };
            cboVatTu.Properties.DataSource = result.ToList();
            cboVatTu.Properties.ValueMember = "ID";
            cboVatTu.Properties.DisplayMember = "TenVatTu";
            
        }
        void LoadDVT()
        {
            searchDVT.Columns.Clear();
            string[] fields = { "ID", "DVT" };

            string[] captions = { "ID", "Unit" };

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                searchDVT.Columns.Add(col);
                searchDVT.Columns[i].Visible = true;
                searchDVT.Columns[i].OptionsColumn.AllowEdit = false;
            }
            searchDVT.Columns["ID"].Visible = false;

            var result = from c in ep.DonViTinhs select new { c.ID, c.DVT };
            cboDVT.Properties.DataSource = result.ToList();
            cboDVT.Properties.ValueMember = "ID";
            cboDVT.Properties.DisplayMember = "DVT";
        }

        void CheckThemMoi()
        {
            if(_KiemTraThemMoi=="Insert")
            {
                cboDVT.Text = "";
                cboOffice.Text = "";
                cboVatTu.Text = "";
                txtSoLuong.Text = "0";
            }
            if(_KiemTraThemMoi=="Update")
            {
                NapChiTietVatTuLencontrol(_IDChiTietVatTu);
            }
        }

        private void frmVatTu_Load(object sender, EventArgs e)
        {
            CheckThemMoi();
        }

        void NapChiTietVatTuLencontrol(int _ID)
        {
            var result = ep.ChiTietNhaps.SqlQuery("Select * from ChiTietNhap where ID=" + _ID);
            foreach(var item in result.ToList())
            {
                cboVatTu.EditValue = item.IDVatTu;
                cboDVT.EditValue = item.DVT;
                cboOffice.SelectedItem = item.Office;
                dtInput.Value = Convert.ToDateTime(item.NgayNhap);
                txtSoLuong.Text = item.SoLuong.ToString();
            }
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            int _IDVatTu = Convert.ToInt32(cboVatTu.EditValue.ToString());
            int _DVT = Convert.ToInt32( cboDVT.EditValue.ToString());
            string _Office = cboOffice.SelectedItem.ToString();
            int _SoLuong = Convert.ToInt32(txtSoLuong.Text);
            DateTime _DateInput = dtInput.Value;

            if(_KiemTraThemMoi=="Insert")
            {
                ChiTietNhap ctnhapvattu = new ChiTietNhap()
                {
                    IDVatTu = _IDVatTu,
                    DVT = _DVT,
                    Office = _Office,
                    SoLuong = _SoLuong,
                    NgayNhap = _DateInput
                };
                ep.ChiTietNhaps.Add(ctnhapvattu);
                ep.SaveChanges();
            }
            if(_KiemTraThemMoi=="Update")
            {
                ChiTietNhap ctnhap = ep.ChiTietNhaps.Find(_IDChiTietVatTu);
                ctnhap.IDVatTu = _IDVatTu;
                ctnhap.DVT = _DVT;
                ctnhap.Office = _Office;
                ctnhap.SoLuong = _SoLuong;
                ctnhap.NgayNhap = _DateInput;
                ep.SaveChanges();
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void cboVatTu_EditValueChanged(object sender, EventArgs e)
        {

        }
    }
}