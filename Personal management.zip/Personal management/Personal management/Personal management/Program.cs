﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DevExpress.UserSkins;
using DevExpress.Skins;

namespace Personal_management
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            BonusSkins.Register();
            //Application.Run(new frmTest());
            Application.Run(new frmlogin());
            //Application.Run(new frmPhieuDanhGia());
            //Application.Run(new frmMain());
            //Application.Run(new Check_License());
            //Application.Run(new frmNhanVienThaiSan());
        }
    }
}