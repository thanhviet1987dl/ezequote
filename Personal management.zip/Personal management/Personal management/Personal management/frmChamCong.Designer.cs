﻿namespace Personal_management
{
    partial class frmChamCong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucChamCong1 = new Personal_management.UCChamCong();
            this.SuspendLayout();
            // 
            // ucChamCong1
            // 
            this.ucChamCong1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucChamCong1.Location = new System.Drawing.Point(0, 0);
            this.ucChamCong1.Name = "ucChamCong1";
            this.ucChamCong1.Size = new System.Drawing.Size(582, 363);
            this.ucChamCong1.TabIndex = 0;
            // 
            // frmChamCong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 363);
            this.Controls.Add(this.ucChamCong1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmChamCong";
            this.Text = "Chấm công/tiền lương";
            this.ResumeLayout(false);

        }

        #endregion

        private UCChamCong ucChamCong1;
    }
}