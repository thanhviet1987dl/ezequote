﻿namespace Personal_management
{
    partial class frmPhieuDanhGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPhieuDanhGia));
            this.label2 = new System.Windows.Forms.Label();
            this.txtSuTapTrung = new DevExpress.XtraEditors.SpinEdit();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtViecRieng = new DevExpress.XtraEditors.SpinEdit();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSoNgayNghi = new DevExpress.XtraEditors.SpinEdit();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSuCanThan = new DevExpress.XtraEditors.SpinEdit();
            this.label15 = new System.Windows.Forms.Label();
            this.txtGiaoTiep = new DevExpress.XtraEditors.SpinEdit();
            this.label14 = new System.Windows.Forms.Label();
            this.txtKienThuc = new DevExpress.XtraEditors.SpinEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtLangNghe = new DevExpress.XtraEditors.SpinEdit();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtKyNang = new DevExpress.XtraEditors.SpinEdit();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chbToBeLeader = new System.Windows.Forms.CheckBox();
            this.chbLauDai = new System.Windows.Forms.CheckBox();
            this.txtGhiChu = new DevExpress.XtraEditors.MemoEdit();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnXacNhan = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuTapTrung.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtViecRieng.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoNgayNghi.Properties)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuCanThan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiaoTiep.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKienThuc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLangNghe.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKyNang.Properties)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChu.Properties)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Focus:";
            // 
            // txtSuTapTrung
            // 
            this.txtSuTapTrung.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtSuTapTrung.Location = new System.Drawing.Point(55, 20);
            this.txtSuTapTrung.Name = "txtSuTapTrung";
            this.txtSuTapTrung.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSuTapTrung.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtSuTapTrung.Properties.Mask.EditMask = "n2";
            this.txtSuTapTrung.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtSuTapTrung.Size = new System.Drawing.Size(121, 20);
            this.txtSuTapTrung.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(182, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "/10";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Personal Items:";
            // 
            // txtViecRieng
            // 
            this.txtViecRieng.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtViecRieng.Location = new System.Drawing.Point(96, 46);
            this.txtViecRieng.Name = "txtViecRieng";
            this.txtViecRieng.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtViecRieng.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtViecRieng.Properties.Mask.EditMask = "n2";
            this.txtViecRieng.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtViecRieng.Size = new System.Drawing.Size(80, 20);
            this.txtViecRieng.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(182, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "/10";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Day Off:";
            // 
            // txtSoNgayNghi
            // 
            this.txtSoNgayNghi.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtSoNgayNghi.Location = new System.Drawing.Point(65, 72);
            this.txtSoNgayNghi.Name = "txtSoNgayNghi";
            this.txtSoNgayNghi.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSoNgayNghi.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtSoNgayNghi.Properties.Mask.EditMask = "n2";
            this.txtSoNgayNghi.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtSoNgayNghi.Size = new System.Drawing.Size(111, 20);
            this.txtSoNgayNghi.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(182, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "/10";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSuTapTrung);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtSoNgayNghi);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtViecRieng);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(229, 101);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Attitude ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSuCanThan);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtGiaoTiep);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtKienThuc);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtLangNghe);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtKyNang);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 101);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(229, 152);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Working Skills ";
            // 
            // txtSuCanThan
            // 
            this.txtSuCanThan.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtSuCanThan.Location = new System.Drawing.Point(84, 124);
            this.txtSuCanThan.Name = "txtSuCanThan";
            this.txtSuCanThan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSuCanThan.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtSuCanThan.Properties.Mask.EditMask = "n2";
            this.txtSuCanThan.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtSuCanThan.Size = new System.Drawing.Size(92, 20);
            this.txtSuCanThan.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 131);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "Carefulness:";
            // 
            // txtGiaoTiep
            // 
            this.txtGiaoTiep.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGiaoTiep.Location = new System.Drawing.Point(96, 98);
            this.txtGiaoTiep.Name = "txtGiaoTiep";
            this.txtGiaoTiep.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtGiaoTiep.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtGiaoTiep.Properties.Mask.EditMask = "n2";
            this.txtGiaoTiep.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtGiaoTiep.Size = new System.Drawing.Size(80, 20);
            this.txtGiaoTiep.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Communication:";
            // 
            // txtKienThuc
            // 
            this.txtKienThuc.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtKienThuc.Location = new System.Drawing.Point(75, 20);
            this.txtKienThuc.Name = "txtKienThuc";
            this.txtKienThuc.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtKienThuc.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtKienThuc.Properties.Mask.EditMask = "n2";
            this.txtKienThuc.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtKienThuc.Size = new System.Drawing.Size(101, 20);
            this.txtKienThuc.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Knowledge:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(182, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "/10";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Listening:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(182, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "/10";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(182, 127);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "/10";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(182, 101);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "/10";
            // 
            // txtLangNghe
            // 
            this.txtLangNghe.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtLangNghe.Location = new System.Drawing.Point(65, 72);
            this.txtLangNghe.Name = "txtLangNghe";
            this.txtLangNghe.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtLangNghe.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtLangNghe.Properties.Mask.EditMask = "n2";
            this.txtLangNghe.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtLangNghe.Size = new System.Drawing.Size(111, 20);
            this.txtLangNghe.TabIndex = 6;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(182, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "/10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Software Skills:";
            // 
            // txtKyNang
            // 
            this.txtKyNang.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtKyNang.Location = new System.Drawing.Point(96, 46);
            this.txtKyNang.Name = "txtKyNang";
            this.txtKyNang.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtKyNang.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.txtKyNang.Properties.Mask.EditMask = "n2";
            this.txtKyNang.Properties.MaxValue = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtKyNang.Size = new System.Drawing.Size(80, 20);
            this.txtKyNang.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chbToBeLeader);
            this.groupBox3.Controls.Add(this.chbLauDai);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 253);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(229, 66);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Future Goal";
            // 
            // chbToBeLeader
            // 
            this.chbToBeLeader.AutoSize = true;
            this.chbToBeLeader.Location = new System.Drawing.Point(12, 43);
            this.chbToBeLeader.Name = "chbToBeLeader";
            this.chbToBeLeader.Size = new System.Drawing.Size(192, 17);
            this.chbToBeLeader.TabIndex = 10;
            this.chbToBeLeader.Text = "Can be a leader/Just normal staffs";
            this.chbToBeLeader.UseVisualStyleBackColor = true;
            // 
            // chbLauDai
            // 
            this.chbLauDai.AutoSize = true;
            this.chbLauDai.Location = new System.Drawing.Point(12, 20);
            this.chbLauDai.Name = "chbLauDai";
            this.chbLauDai.Size = new System.Drawing.Size(138, 17);
            this.chbLauDai.TabIndex = 9;
            this.chbLauDai.Text = "Temporary/Permernant";
            this.chbLauDai.UseVisualStyleBackColor = true;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGhiChu.Location = new System.Drawing.Point(3, 17);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(223, 119);
            this.txtGhiChu.TabIndex = 11;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtGhiChu);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(0, 319);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(229, 139);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Note";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnXacNhan);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 458);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(229, 30);
            this.panel5.TabIndex = 11;
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhan.Image")));
            this.btnXacNhan.Location = new System.Drawing.Point(167, 2);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(58, 25);
            this.btnXacNhan.TabIndex = 0;
            this.btnXacNhan.Text = "Save";
            this.btnXacNhan.ToolTip = "Lưu thông tin";
            this.btnXacNhan.Click += new System.EventHandler(this.btnXacNhan_Click);
            // 
            // frmPhieuDanhGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 492);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPhieuDanhGia";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phiếu đánh giá";
            this.Load += new System.EventHandler(this.frmPhieuDanhGia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtSuTapTrung.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtViecRieng.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoNgayNghi.Properties)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSuCanThan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiaoTiep.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKienThuc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLangNghe.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKyNang.Properties)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChu.Properties)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.SpinEdit txtSuTapTrung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.SpinEdit txtViecRieng;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.SpinEdit txtSoNgayNghi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private DevExpress.XtraEditors.SpinEdit txtGiaoTiep;
        private System.Windows.Forms.Label label14;
        private DevExpress.XtraEditors.SpinEdit txtKienThuc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private DevExpress.XtraEditors.SpinEdit txtLangNghe;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private DevExpress.XtraEditors.SpinEdit txtKyNang;
        private DevExpress.XtraEditors.SpinEdit txtSuCanThan;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private DevExpress.XtraEditors.MemoEdit txtGhiChu;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel5;
        private DevExpress.XtraEditors.SimpleButton btnXacNhan;
        private System.Windows.Forms.CheckBox chbToBeLeader;
        private System.Windows.Forms.CheckBox chbLauDai;
    }
}