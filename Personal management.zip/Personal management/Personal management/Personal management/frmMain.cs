﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraTab.ViewInfo;
using DevExpress.XtraTab;
using DevExpress.XtraSplashScreen;

namespace Personal_management
{
    public partial class frmMain : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        private static DevExpress.XtraTab.XtraTabControl tabstatic;
        public frmMain()
        {
            InitializeComponent();
            tabstatic = xtraTabControl1;
        }


        void PhanQuyenSuDung(int Ismanagement)
        {
            if (Ismanagement == 0)
            {
                ribbonPagephanquyen.Visible = false;
            }
            if (Ismanagement == 1)
            {
                ribbonPagephanquyen.Visible = true;
            }
        }

        private void xtraTabControl1_CloseButtonClick(object sender, EventArgs e)
        {
            int h = 0;
            ClosePageButtonEventArgs arg = e as ClosePageButtonEventArgs;
            if (xtraTabControl1.SelectedTabPage.Equals((arg.Page as XtraTabPage)))
                h = xtraTabControl1.SelectedTabPageIndex;
            if ((arg.Page as XtraTabPage).Text != "Bắt đầu")
            {
                xtraTabControl1.TabPages.Remove((arg.Page as XtraTabPage));

                xtraTabControl1.SelectedTabPageIndex = h - 1;
            }
            else
                XtraMessageBox.Show("Bạn không thể tắt\nTab bắt đầu này !", "Thông báo");
        }

        #region Kiểm tra TabPabPage có tồn tại không
        public static bool KiemTraTabPage(string Ten)
        {
            bool ok = false;
            foreach (XtraTabPage tabpage in tabstatic.TabPages)
            {
                if (tabpage.Text == Ten)
                {
                    return ok = true;
                }
            }
            return ok;
        }

        #endregion

        #region Tìm vị trí TabPage

        public static int ViTriTabPage(string Ten)
        {
            int vitri = 0;
            for (int i = 0; i < tabstatic.TabPages.Count; i++)
            {
                if (tabstatic.TabPages[i].Text == Ten)
                    vitri = i;
            }
            return vitri;
        }


        #endregion

        private void btnDangNhap_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmlogin frm = new frmlogin();
            frm.Show();
        }

        private void btnDangXuat_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.Hide();
            frmlogin frm = new frmlogin();
            frm.ShowDialog();

        }

        private void btnSaoLuuData_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void btnKhoiPhucDuLieu_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void btnPhanQuyen_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmAddUser frm = new frmAddUser();
            frm.Show();
        }

        private void btnNhanVienChinhThuc_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SplashScreenManager.ShowForm(this, typeof(WaitForm1), true, true, false);
            XtraTabPage quanlynhanvien = new XtraTabPage();
            quanlynhanvien.Text = "Quản lý nhân viên";
            if (KiemTraTabPage(quanlynhanvien.Text) == false)
                xtraTabControl1.TabPages.Add(quanlynhanvien);
            else
                quanlynhanvien.PageVisible = true;
            frmnhanvien frm = new frmnhanvien();
            frm.TopLevel = false;
            frm.Parent = xtraTabControl1.TabPages[ViTriTabPage(quanlynhanvien.Text)];
            frm.Dock = DockStyle.Fill;

            frm.Show();
            xtraTabControl1.SelectedTabPage = xtraTabControl1.TabPages[ViTriTabPage(quanlynhanvien.Text)];
            SplashScreenManager.CloseForm(false);
        }

        private void btnChamCong_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SplashScreenManager.ShowForm(this, typeof(WaitForm1), true, true, false);
            XtraTabPage chamcongtienluong = new XtraTabPage();
            chamcongtienluong.Text = "Chấm công";
            if (KiemTraTabPage(chamcongtienluong.Text) == false)
                xtraTabControl1.TabPages.Add(chamcongtienluong);
            else
                chamcongtienluong.PageVisible = true;
            frmChamCong frm = new frmChamCong();
            frm.TopLevel = false;
            frm.Parent = xtraTabControl1.TabPages[ViTriTabPage(chamcongtienluong.Text)];
            frm.Dock = DockStyle.Fill;

            frm.Show();
            xtraTabControl1.SelectedTabPage = xtraTabControl1.TabPages[ViTriTabPage(chamcongtienluong.Text)];
            SplashScreenManager.CloseForm(false);
        }

        private void btnChucVu_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmChucVu frm = new frmChucVu();
            frm.ShowDialog();
        }


        private void btnTeam_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmTeam frm = new frmTeam();
            frm.ShowDialog();
        }

        private void btnPhongBan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmPhongBan fr = new frmPhongBan();
            fr.ShowDialog();
        }

        private void btnHocVien_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SplashScreenManager.ShowForm(this, typeof(WaitForm1), true, true, false);
            XtraTabPage trainee = new XtraTabPage();
            trainee.Text = "Trainee";
            if (KiemTraTabPage(trainee.Text) == false)
                xtraTabControl1.TabPages.Add(trainee);
            else
                trainee.PageVisible = true;
            frmListNhanVien frm = new frmListNhanVien();
            frm.iIDStatus = 2;
            frm.TopLevel = false;
            frm.Parent = xtraTabControl1.TabPages[ViTriTabPage(trainee.Text)];
            frm.Dock = DockStyle.Fill;

            frm.Show();
            xtraTabControl1.SelectedTabPage = xtraTabControl1.TabPages[ViTriTabPage(trainee.Text)];
            SplashScreenManager.CloseForm(false);
        }

        private void btnNhanVienNghiViec_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SplashScreenManager.ShowForm(this, typeof(WaitForm1), true, true, false);
            XtraTabPage nghiviec = new XtraTabPage();
            nghiviec.Text = "Nghỉ việc";
            if (KiemTraTabPage(nghiviec.Text) == false)
                xtraTabControl1.TabPages.Add(nghiviec);
            else
                nghiviec.PageVisible = true;
            frmListNhanVien frm = new frmListNhanVien();
            frm.iIDStatus = 6;
            frm.TopLevel = false;
            frm.Parent = xtraTabControl1.TabPages[ViTriTabPage(nghiviec.Text)];
            frm.Dock = DockStyle.Fill;

            frm.Show();
            xtraTabControl1.SelectedTabPage = xtraTabControl1.TabPages[ViTriTabPage(nghiviec.Text)];
            SplashScreenManager.CloseForm(false);
        }

        private void btnThaiSan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SplashScreenManager.ShowForm(this, typeof(WaitForm1), true, true, false);
            XtraTabPage thaisan = new XtraTabPage();
            thaisan.Text = "Thai sản";
            if (KiemTraTabPage(thaisan.Text) == false)
                xtraTabControl1.TabPages.Add(thaisan);
            else
                thaisan.PageVisible = true;
            frmListNhanVien frm = new frmListNhanVien();
            frm.iIDStatus = 4;
            frm.TopLevel = false;
            frm.Parent = xtraTabControl1.TabPages[ViTriTabPage(thaisan.Text)];
            frm.Dock = DockStyle.Fill;

            frm.Show();
            xtraTabControl1.SelectedTabPage = xtraTabControl1.TabPages[ViTriTabPage(thaisan.Text)];
            SplashScreenManager.CloseForm(false);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            PhanQuyenSuDung(Corelib._Ismanagement);
            lblUserID.Caption = "My User: " + Corelib._UserID;
            
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblClock.Caption = "Time now: "+DateTime.Now.ToLongTimeString() +"---Today: " + DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void btnVatTu_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SplashScreenManager.ShowForm(this, typeof(WaitForm1), true, true, false);
            XtraTabPage vattu = new XtraTabPage();
            vattu.Text = "Vật tư";
            if (KiemTraTabPage(vattu.Text) == false)
                xtraTabControl1.TabPages.Add(vattu);
            else
                vattu.PageVisible = true;
            frmCTNhapVatTu frm = new frmCTNhapVatTu();
            frm.TopLevel = false;
            frm.Parent = xtraTabControl1.TabPages[ViTriTabPage(vattu.Text)];
            frm.Dock = DockStyle.Fill;

            frm.Show();
            xtraTabControl1.SelectedTabPage = xtraTabControl1.TabPages[ViTriTabPage(vattu.Text)];
            SplashScreenManager.CloseForm(false);
        }
    }
}