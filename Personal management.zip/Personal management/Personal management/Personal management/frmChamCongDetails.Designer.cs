﻿namespace Personal_management
{
    partial class frmChamCongDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChamCongDetails));
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnXacNhanDayOff = new DevExpress.XtraEditors.SimpleButton();
            this.btnSuaDayOff = new DevExpress.XtraEditors.SimpleButton();
            this.btnThemMoiDayOff = new DevExpress.XtraEditors.SimpleButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtGhiChuDayOff = new DevExpress.XtraEditors.MemoEdit();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTongNgayNghi = new DevExpress.XtraEditors.TextEdit();
            this.panelHalfDayOff = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.dtHalfDayOff = new System.Windows.Forms.DateTimePicker();
            this.panelAllDayOff = new System.Windows.Forms.Panel();
            this.dtDenNgayDayOff = new System.Windows.Forms.DateTimePicker();
            this.dtTuNgayDayOff = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdAllDayOff = new System.Windows.Forms.RadioButton();
            this.rdHalfDayOff = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnXacNhanLate = new DevExpress.XtraEditors.SimpleButton();
            this.btnSuaLate = new DevExpress.XtraEditors.SimpleButton();
            this.btnThemMoiLate = new DevExpress.XtraEditors.SimpleButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtGhiChuLate = new DevExpress.XtraEditors.MemoEdit();
            this.label16 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dtNgayDiTreVeSom = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSoPhutDiMuon = new DevExpress.XtraEditors.SpinEdit();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.rdDiMuon = new System.Windows.Forms.RadioButton();
            this.rdVeSom = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnXacNhanDayOT = new DevExpress.XtraEditors.SimpleButton();
            this.btnSuaDayOT = new DevExpress.XtraEditors.SimpleButton();
            this.btnThemMoiDayOT = new DevExpress.XtraEditors.SimpleButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtGhiChuDayOT = new DevExpress.XtraEditors.MemoEdit();
            this.label5 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtTongNgayOT = new DevExpress.XtraEditors.TextEdit();
            this.label6 = new System.Windows.Forms.Label();
            this.panelHalfDayOT = new System.Windows.Forms.Panel();
            this.dtHaftDayOT = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.panelDayOT = new System.Windows.Forms.Panel();
            this.dtDenNgayOT = new System.Windows.Forms.DateTimePicker();
            this.dtTuNgayOT = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.rdOTAllDay = new System.Windows.Forms.RadioButton();
            this.rdHalfDayOT = new System.Windows.Forms.RadioButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.btnXacNhanTimeOT = new DevExpress.XtraEditors.SimpleButton();
            this.btnSuaTimeOT = new DevExpress.XtraEditors.SimpleButton();
            this.btnThemMoiTimeOT = new DevExpress.XtraEditors.SimpleButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txtGhiChuTimeOT = new DevExpress.XtraEditors.MemoEdit();
            this.label17 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.textEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.txtSoPhutOT = new DevExpress.XtraEditors.SpinEdit();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtTenNV = new DevExpress.XtraEditors.TextEdit();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTongPhep = new DevExpress.XtraEditors.TextEdit();
            this.txtPhepConLai = new DevExpress.XtraEditors.TextEdit();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.lblOT = new System.Windows.Forms.Label();
            this.lable102 = new System.Windows.Forms.Label();
            this.lblDiTreVeSom = new System.Windows.Forms.Label();
            this.lable101 = new System.Windows.Forms.Label();
            this.lblSoNgayNghi = new System.Windows.Forms.Label();
            this.lable100 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.grcChiTiet = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.label22 = new System.Windows.Forms.Label();
            this.cboPhep = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuDayOff.Properties)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongNgayNghi.Properties)).BeginInit();
            this.panelHalfDayOff.SuspendLayout();
            this.panelAllDayOff.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuLate.Properties)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoPhutDiMuon.Properties)).BeginInit();
            this.panel17.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuDayOT.Properties)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongNgayOT.Properties)).BeginInit();
            this.panelHalfDayOT.SuspendLayout();
            this.panelDayOT.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuTimeOT.Properties)).BeginInit();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoPhutOT.Properties)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenNV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongPhep.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhepConLai.Properties)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grcChiTiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.tabControl1);
            this.groupControl2.Controls.Add(this.panel2);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupControl2.Location = new System.Drawing.Point(0, 0);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(243, 500);
            this.groupControl2.TabIndex = 7;
            this.groupControl2.Text = "Thông tin chấm công";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Location = new System.Drawing.Point(2, 101);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(239, 277);
            this.tabControl1.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.panelHalfDayOff);
            this.tabPage1.Controls.Add(this.panelAllDayOff);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(231, 251);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Day off";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnXacNhanDayOff);
            this.panel5.Controls.Add(this.btnSuaDayOff);
            this.panel5.Controls.Add(this.btnThemMoiDayOff);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(3, 218);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(225, 30);
            this.panel5.TabIndex = 5;
            // 
            // btnXacNhanDayOff
            // 
            this.btnXacNhanDayOff.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhanDayOff.Image")));
            this.btnXacNhanDayOff.Location = new System.Drawing.Point(167, 2);
            this.btnXacNhanDayOff.Name = "btnXacNhanDayOff";
            this.btnXacNhanDayOff.Size = new System.Drawing.Size(58, 25);
            this.btnXacNhanDayOff.TabIndex = 0;
            this.btnXacNhanDayOff.Text = "Save";
            this.btnXacNhanDayOff.ToolTip = "Lưu thông tin";
            this.btnXacNhanDayOff.Click += new System.EventHandler(this.btnXacNhanDayOff_Click);
            // 
            // btnSuaDayOff
            // 
            this.btnSuaDayOff.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaDayOff.Image")));
            this.btnSuaDayOff.Location = new System.Drawing.Point(105, 2);
            this.btnSuaDayOff.Name = "btnSuaDayOff";
            this.btnSuaDayOff.Size = new System.Drawing.Size(55, 25);
            this.btnSuaDayOff.TabIndex = 0;
            this.btnSuaDayOff.Text = "Edit";
            this.btnSuaDayOff.ToolTip = "Sửa dữ liệu";
            this.btnSuaDayOff.Click += new System.EventHandler(this.btnSuaDayOff_Click);
            // 
            // btnThemMoiDayOff
            // 
            this.btnThemMoiDayOff.Image = ((System.Drawing.Image)(resources.GetObject("btnThemMoiDayOff.Image")));
            this.btnThemMoiDayOff.Location = new System.Drawing.Point(42, 2);
            this.btnThemMoiDayOff.Name = "btnThemMoiDayOff";
            this.btnThemMoiDayOff.Size = new System.Drawing.Size(57, 25);
            this.btnThemMoiDayOff.TabIndex = 0;
            this.btnThemMoiDayOff.Text = "New";
            this.btnThemMoiDayOff.ToolTip = "Thêm mới";
            this.btnThemMoiDayOff.Click += new System.EventHandler(this.btnThemMoiDayOff_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cboPhep);
            this.panel3.Controls.Add(this.txtGhiChuDayOff);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 133);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(225, 85);
            this.panel3.TabIndex = 4;
            // 
            // txtGhiChuDayOff
            // 
            this.txtGhiChuDayOff.Location = new System.Drawing.Point(66, 28);
            this.txtGhiChuDayOff.Name = "txtGhiChuDayOff";
            this.txtGhiChuDayOff.Size = new System.Drawing.Size(159, 50);
            this.txtGhiChuDayOff.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Note:";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.txtTongNgayNghi);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(3, 104);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(225, 29);
            this.panel4.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Total off:";
            // 
            // txtTongNgayNghi
            // 
            this.txtTongNgayNghi.Location = new System.Drawing.Point(66, 4);
            this.txtTongNgayNghi.Name = "txtTongNgayNghi";
            this.txtTongNgayNghi.Properties.ReadOnly = true;
            this.txtTongNgayNghi.Size = new System.Drawing.Size(159, 20);
            this.txtTongNgayNghi.TabIndex = 1;
            // 
            // panelHalfDayOff
            // 
            this.panelHalfDayOff.Controls.Add(this.label23);
            this.panelHalfDayOff.Controls.Add(this.dtHalfDayOff);
            this.panelHalfDayOff.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHalfDayOff.Location = new System.Drawing.Point(3, 76);
            this.panelHalfDayOff.Name = "panelHalfDayOff";
            this.panelHalfDayOff.Size = new System.Drawing.Size(225, 28);
            this.panelHalfDayOff.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(2, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Day:";
            // 
            // dtHalfDayOff
            // 
            this.dtHalfDayOff.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtHalfDayOff.Location = new System.Drawing.Point(65, 3);
            this.dtHalfDayOff.Name = "dtHalfDayOff";
            this.dtHalfDayOff.Size = new System.Drawing.Size(159, 21);
            this.dtHalfDayOff.TabIndex = 1;
            this.dtHalfDayOff.ValueChanged += new System.EventHandler(this.dtTuNgayDayOff_ValueChanged);
            // 
            // panelAllDayOff
            // 
            this.panelAllDayOff.Controls.Add(this.dtDenNgayDayOff);
            this.panelAllDayOff.Controls.Add(this.dtTuNgayDayOff);
            this.panelAllDayOff.Controls.Add(this.label2);
            this.panelAllDayOff.Controls.Add(this.label1);
            this.panelAllDayOff.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAllDayOff.Location = new System.Drawing.Point(3, 23);
            this.panelAllDayOff.Name = "panelAllDayOff";
            this.panelAllDayOff.Size = new System.Drawing.Size(225, 53);
            this.panelAllDayOff.TabIndex = 2;
            // 
            // dtDenNgayDayOff
            // 
            this.dtDenNgayDayOff.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDenNgayDayOff.Location = new System.Drawing.Point(66, 29);
            this.dtDenNgayDayOff.Name = "dtDenNgayDayOff";
            this.dtDenNgayDayOff.Size = new System.Drawing.Size(159, 21);
            this.dtDenNgayDayOff.TabIndex = 1;
            this.dtDenNgayDayOff.ValueChanged += new System.EventHandler(this.dtDenNgayDayOff_ValueChanged);
            // 
            // dtTuNgayDayOff
            // 
            this.dtTuNgayDayOff.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTuNgayDayOff.Location = new System.Drawing.Point(66, 3);
            this.dtTuNgayDayOff.Name = "dtTuNgayDayOff";
            this.dtTuNgayDayOff.Size = new System.Drawing.Size(159, 21);
            this.dtTuNgayDayOff.TabIndex = 1;
            this.dtTuNgayDayOff.ValueChanged += new System.EventHandler(this.dtTuNgayDayOff_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "End day:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Start day:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdAllDayOff);
            this.panel1.Controls.Add(this.rdHalfDayOff);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(225, 20);
            this.panel1.TabIndex = 1;
            // 
            // rdAllDayOff
            // 
            this.rdAllDayOff.AutoSize = true;
            this.rdAllDayOff.Checked = true;
            this.rdAllDayOff.Location = new System.Drawing.Point(8, 3);
            this.rdAllDayOff.Name = "rdAllDayOff";
            this.rdAllDayOff.Size = new System.Drawing.Size(57, 17);
            this.rdAllDayOff.TabIndex = 0;
            this.rdAllDayOff.TabStop = true;
            this.rdAllDayOff.Text = "All day";
            this.rdAllDayOff.UseVisualStyleBackColor = true;
            this.rdAllDayOff.CheckedChanged += new System.EventHandler(this.rdAllDayOff_CheckedChanged);
            // 
            // rdHalfDayOff
            // 
            this.rdHalfDayOff.AutoSize = true;
            this.rdHalfDayOff.Location = new System.Drawing.Point(147, 3);
            this.rdHalfDayOff.Name = "rdHalfDayOff";
            this.rdHalfDayOff.Size = new System.Drawing.Size(65, 17);
            this.rdHalfDayOff.TabIndex = 0;
            this.rdHalfDayOff.Text = "Half day";
            this.rdHalfDayOff.UseVisualStyleBackColor = true;
            this.rdHalfDayOff.CheckedChanged += new System.EventHandler(this.rdHalfDayOff_CheckedChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel12);
            this.tabPage2.Controls.Add(this.panel13);
            this.tabPage2.Controls.Add(this.panel9);
            this.tabPage2.Controls.Add(this.panel17);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(231, 251);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Late/Back early";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btnXacNhanLate);
            this.panel12.Controls.Add(this.btnSuaLate);
            this.panel12.Controls.Add(this.btnThemMoiLate);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(3, 159);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(225, 30);
            this.panel12.TabIndex = 7;
            // 
            // btnXacNhanLate
            // 
            this.btnXacNhanLate.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhanLate.Image")));
            this.btnXacNhanLate.Location = new System.Drawing.Point(163, 2);
            this.btnXacNhanLate.Name = "btnXacNhanLate";
            this.btnXacNhanLate.Size = new System.Drawing.Size(58, 25);
            this.btnXacNhanLate.TabIndex = 0;
            this.btnXacNhanLate.Text = "Save";
            this.btnXacNhanLate.ToolTip = "Lưu thông tin";
            this.btnXacNhanLate.Click += new System.EventHandler(this.btnXacNhanLate_Click);
            // 
            // btnSuaLate
            // 
            this.btnSuaLate.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaLate.Image")));
            this.btnSuaLate.Location = new System.Drawing.Point(101, 2);
            this.btnSuaLate.Name = "btnSuaLate";
            this.btnSuaLate.Size = new System.Drawing.Size(55, 25);
            this.btnSuaLate.TabIndex = 0;
            this.btnSuaLate.Text = "Edit";
            this.btnSuaLate.ToolTip = "Sửa dữ liệu";
            this.btnSuaLate.Click += new System.EventHandler(this.btnSuaLate_Click);
            // 
            // btnThemMoiLate
            // 
            this.btnThemMoiLate.Image = ((System.Drawing.Image)(resources.GetObject("btnThemMoiLate.Image")));
            this.btnThemMoiLate.Location = new System.Drawing.Point(38, 2);
            this.btnThemMoiLate.Name = "btnThemMoiLate";
            this.btnThemMoiLate.Size = new System.Drawing.Size(57, 25);
            this.btnThemMoiLate.TabIndex = 0;
            this.btnThemMoiLate.Text = "New";
            this.btnThemMoiLate.ToolTip = "Thêm mới";
            this.btnThemMoiLate.Click += new System.EventHandler(this.btnThemMoiLate_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.txtGhiChuLate);
            this.panel13.Controls.Add(this.label16);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(3, 74);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(225, 85);
            this.panel13.TabIndex = 6;
            // 
            // txtGhiChuLate
            // 
            this.txtGhiChuLate.Location = new System.Drawing.Point(48, 6);
            this.txtGhiChuLate.Name = "txtGhiChuLate";
            this.txtGhiChuLate.Size = new System.Drawing.Size(177, 76);
            this.txtGhiChuLate.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Note:";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.dtNgayDiTreVeSom);
            this.panel9.Controls.Add(this.label13);
            this.panel9.Controls.Add(this.txtSoPhutDiMuon);
            this.panel9.Controls.Add(this.label14);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(3, 23);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(225, 51);
            this.panel9.TabIndex = 0;
            // 
            // dtNgayDiTreVeSom
            // 
            this.dtNgayDiTreVeSom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayDiTreVeSom.Location = new System.Drawing.Point(48, 3);
            this.dtNgayDiTreVeSom.Name = "dtNgayDiTreVeSom";
            this.dtNgayDiTreVeSom.Size = new System.Drawing.Size(174, 21);
            this.dtNgayDiTreVeSom.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "Day:";
            // 
            // txtSoPhutDiMuon
            // 
            this.txtSoPhutDiMuon.EditValue = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.txtSoPhutDiMuon.Location = new System.Drawing.Point(48, 28);
            this.txtSoPhutDiMuon.Name = "txtSoPhutDiMuon";
            this.txtSoPhutDiMuon.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSoPhutDiMuon.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.txtSoPhutDiMuon.Properties.MaxValue = new decimal(new int[] {
            640,
            0,
            0,
            0});
            this.txtSoPhutDiMuon.Properties.MinValue = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.txtSoPhutDiMuon.Size = new System.Drawing.Size(132, 20);
            this.txtSoPhutDiMuon.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(186, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "(Mins)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Time:";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.rdDiMuon);
            this.panel17.Controls.Add(this.rdVeSom);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(3, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(225, 20);
            this.panel17.TabIndex = 8;
            // 
            // rdDiMuon
            // 
            this.rdDiMuon.AutoSize = true;
            this.rdDiMuon.Checked = true;
            this.rdDiMuon.Location = new System.Drawing.Point(8, 3);
            this.rdDiMuon.Name = "rdDiMuon";
            this.rdDiMuon.Size = new System.Drawing.Size(46, 17);
            this.rdDiMuon.TabIndex = 0;
            this.rdDiMuon.TabStop = true;
            this.rdDiMuon.Text = "Late";
            this.rdDiMuon.UseVisualStyleBackColor = true;
            // 
            // rdVeSom
            // 
            this.rdVeSom.AutoSize = true;
            this.rdVeSom.Location = new System.Drawing.Point(147, 3);
            this.rdVeSom.Name = "rdVeSom";
            this.rdVeSom.Size = new System.Drawing.Size(74, 17);
            this.rdVeSom.TabIndex = 0;
            this.rdVeSom.Text = "Back early";
            this.rdVeSom.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel6);
            this.tabPage3.Controls.Add(this.panel7);
            this.tabPage3.Controls.Add(this.panel8);
            this.tabPage3.Controls.Add(this.panelHalfDayOT);
            this.tabPage3.Controls.Add(this.panelDayOT);
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(231, 251);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Day OT";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnXacNhanDayOT);
            this.panel6.Controls.Add(this.btnSuaDayOT);
            this.panel6.Controls.Add(this.btnThemMoiDayOT);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(3, 221);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(225, 30);
            this.panel6.TabIndex = 10;
            // 
            // btnXacNhanDayOT
            // 
            this.btnXacNhanDayOT.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhanDayOT.Image")));
            this.btnXacNhanDayOT.Location = new System.Drawing.Point(164, 3);
            this.btnXacNhanDayOT.Name = "btnXacNhanDayOT";
            this.btnXacNhanDayOT.Size = new System.Drawing.Size(58, 25);
            this.btnXacNhanDayOT.TabIndex = 0;
            this.btnXacNhanDayOT.Text = "Save";
            this.btnXacNhanDayOT.ToolTip = "Lưu thông tin";
            this.btnXacNhanDayOT.Click += new System.EventHandler(this.btnXacNhanDayOT_Click);
            // 
            // btnSuaDayOT
            // 
            this.btnSuaDayOT.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaDayOT.Image")));
            this.btnSuaDayOT.Location = new System.Drawing.Point(102, 3);
            this.btnSuaDayOT.Name = "btnSuaDayOT";
            this.btnSuaDayOT.Size = new System.Drawing.Size(55, 25);
            this.btnSuaDayOT.TabIndex = 0;
            this.btnSuaDayOT.Text = "Edit";
            this.btnSuaDayOT.ToolTip = "Sửa dữ liệu";
            this.btnSuaDayOT.Click += new System.EventHandler(this.btnSuaDayOT_Click);
            // 
            // btnThemMoiDayOT
            // 
            this.btnThemMoiDayOT.Image = ((System.Drawing.Image)(resources.GetObject("btnThemMoiDayOT.Image")));
            this.btnThemMoiDayOT.Location = new System.Drawing.Point(39, 3);
            this.btnThemMoiDayOT.Name = "btnThemMoiDayOT";
            this.btnThemMoiDayOT.Size = new System.Drawing.Size(57, 25);
            this.btnThemMoiDayOT.TabIndex = 0;
            this.btnThemMoiDayOT.Text = "New";
            this.btnThemMoiDayOT.ToolTip = "Thêm mới";
            this.btnThemMoiDayOT.Click += new System.EventHandler(this.btnThemMoiDayOT_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtGhiChuDayOT);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(3, 136);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(225, 85);
            this.panel7.TabIndex = 9;
            // 
            // txtGhiChuDayOT
            // 
            this.txtGhiChuDayOT.Location = new System.Drawing.Point(66, 6);
            this.txtGhiChuDayOT.Name = "txtGhiChuDayOT";
            this.txtGhiChuDayOT.Size = new System.Drawing.Size(159, 76);
            this.txtGhiChuDayOT.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Note:";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtTongNgayOT);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(3, 107);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(225, 29);
            this.panel8.TabIndex = 8;
            // 
            // txtTongNgayOT
            // 
            this.txtTongNgayOT.Location = new System.Drawing.Point(66, 5);
            this.txtTongNgayOT.Name = "txtTongNgayOT";
            this.txtTongNgayOT.Size = new System.Drawing.Size(159, 20);
            this.txtTongNgayOT.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Total:";
            // 
            // panelHalfDayOT
            // 
            this.panelHalfDayOT.Controls.Add(this.dtHaftDayOT);
            this.panelHalfDayOT.Controls.Add(this.label15);
            this.panelHalfDayOT.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHalfDayOT.Location = new System.Drawing.Point(3, 76);
            this.panelHalfDayOT.Name = "panelHalfDayOT";
            this.panelHalfDayOT.Size = new System.Drawing.Size(225, 31);
            this.panelHalfDayOT.TabIndex = 8;
            // 
            // dtHaftDayOT
            // 
            this.dtHaftDayOT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtHaftDayOT.Location = new System.Drawing.Point(66, 6);
            this.dtHaftDayOT.Name = "dtHaftDayOT";
            this.dtHaftDayOT.Size = new System.Drawing.Size(159, 21);
            this.dtHaftDayOT.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Day:";
            // 
            // panelDayOT
            // 
            this.panelDayOT.Controls.Add(this.dtDenNgayOT);
            this.panelDayOT.Controls.Add(this.dtTuNgayOT);
            this.panelDayOT.Controls.Add(this.label7);
            this.panelDayOT.Controls.Add(this.label9);
            this.panelDayOT.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDayOT.Location = new System.Drawing.Point(3, 23);
            this.panelDayOT.Name = "panelDayOT";
            this.panelDayOT.Size = new System.Drawing.Size(225, 53);
            this.panelDayOT.TabIndex = 7;
            // 
            // dtDenNgayOT
            // 
            this.dtDenNgayOT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDenNgayOT.Location = new System.Drawing.Point(66, 28);
            this.dtDenNgayOT.Name = "dtDenNgayOT";
            this.dtDenNgayOT.Size = new System.Drawing.Size(159, 21);
            this.dtDenNgayOT.TabIndex = 1;
            this.dtDenNgayOT.ValueChanged += new System.EventHandler(this.dtDenNgayOT_ValueChanged);
            // 
            // dtTuNgayOT
            // 
            this.dtTuNgayOT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTuNgayOT.Location = new System.Drawing.Point(66, 2);
            this.dtTuNgayOT.Name = "dtTuNgayOT";
            this.dtTuNgayOT.Size = new System.Drawing.Size(159, 21);
            this.dtTuNgayOT.TabIndex = 1;
            this.dtTuNgayOT.ValueChanged += new System.EventHandler(this.dtTuNgayOT_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "End day:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Start day:";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.rdOTAllDay);
            this.panel10.Controls.Add(this.rdHalfDayOT);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(225, 20);
            this.panel10.TabIndex = 6;
            // 
            // rdOTAllDay
            // 
            this.rdOTAllDay.AutoSize = true;
            this.rdOTAllDay.Checked = true;
            this.rdOTAllDay.Location = new System.Drawing.Point(8, 3);
            this.rdOTAllDay.Name = "rdOTAllDay";
            this.rdOTAllDay.Size = new System.Drawing.Size(57, 17);
            this.rdOTAllDay.TabIndex = 0;
            this.rdOTAllDay.TabStop = true;
            this.rdOTAllDay.Text = "All day";
            this.rdOTAllDay.UseVisualStyleBackColor = true;
            this.rdOTAllDay.CheckedChanged += new System.EventHandler(this.rdOTAllDay_CheckedChanged);
            // 
            // rdHalfDayOT
            // 
            this.rdHalfDayOT.AutoSize = true;
            this.rdHalfDayOT.Location = new System.Drawing.Point(147, 3);
            this.rdHalfDayOT.Name = "rdHalfDayOT";
            this.rdHalfDayOT.Size = new System.Drawing.Size(65, 17);
            this.rdHalfDayOT.TabIndex = 0;
            this.rdHalfDayOT.Text = "Half day";
            this.rdHalfDayOT.UseVisualStyleBackColor = true;
            this.rdHalfDayOT.CheckedChanged += new System.EventHandler(this.rdHalfDayOT_CheckedChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel14);
            this.tabPage4.Controls.Add(this.panel15);
            this.tabPage4.Controls.Add(this.panel16);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(231, 251);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Time OT";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.btnXacNhanTimeOT);
            this.panel14.Controls.Add(this.btnSuaTimeOT);
            this.panel14.Controls.Add(this.btnThemMoiTimeOT);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(3, 146);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(225, 30);
            this.panel14.TabIndex = 10;
            // 
            // btnXacNhanTimeOT
            // 
            this.btnXacNhanTimeOT.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhanTimeOT.Image")));
            this.btnXacNhanTimeOT.Location = new System.Drawing.Point(164, 2);
            this.btnXacNhanTimeOT.Name = "btnXacNhanTimeOT";
            this.btnXacNhanTimeOT.Size = new System.Drawing.Size(58, 25);
            this.btnXacNhanTimeOT.TabIndex = 0;
            this.btnXacNhanTimeOT.Text = "Save";
            this.btnXacNhanTimeOT.ToolTip = "Lưu thông tin";
            // 
            // btnSuaTimeOT
            // 
            this.btnSuaTimeOT.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaTimeOT.Image")));
            this.btnSuaTimeOT.Location = new System.Drawing.Point(102, 2);
            this.btnSuaTimeOT.Name = "btnSuaTimeOT";
            this.btnSuaTimeOT.Size = new System.Drawing.Size(55, 25);
            this.btnSuaTimeOT.TabIndex = 0;
            this.btnSuaTimeOT.Text = "Edit";
            this.btnSuaTimeOT.ToolTip = "Sửa dữ liệu";
            // 
            // btnThemMoiTimeOT
            // 
            this.btnThemMoiTimeOT.Image = ((System.Drawing.Image)(resources.GetObject("btnThemMoiTimeOT.Image")));
            this.btnThemMoiTimeOT.Location = new System.Drawing.Point(39, 2);
            this.btnThemMoiTimeOT.Name = "btnThemMoiTimeOT";
            this.btnThemMoiTimeOT.Size = new System.Drawing.Size(57, 25);
            this.btnThemMoiTimeOT.TabIndex = 0;
            this.btnThemMoiTimeOT.Text = "New";
            this.btnThemMoiTimeOT.ToolTip = "Thêm mới";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.txtGhiChuTimeOT);
            this.panel15.Controls.Add(this.label17);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(3, 61);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(225, 85);
            this.panel15.TabIndex = 9;
            // 
            // txtGhiChuTimeOT
            // 
            this.txtGhiChuTimeOT.Location = new System.Drawing.Point(42, 6);
            this.txtGhiChuTimeOT.Name = "txtGhiChuTimeOT";
            this.txtGhiChuTimeOT.Size = new System.Drawing.Size(183, 76);
            this.txtGhiChuTimeOT.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(5, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Note:";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.textEdit2);
            this.panel16.Controls.Add(this.txtSoPhutOT);
            this.panel16.Controls.Add(this.label18);
            this.panel16.Controls.Add(this.label19);
            this.panel16.Controls.Add(this.label20);
            this.panel16.Controls.Add(this.label21);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(3, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(225, 58);
            this.panel16.TabIndex = 8;
            // 
            // textEdit2
            // 
            this.textEdit2.Location = new System.Drawing.Point(42, 31);
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Size = new System.Drawing.Size(57, 20);
            this.textEdit2.TabIndex = 2;
            // 
            // txtSoPhutOT
            // 
            this.txtSoPhutOT.EditValue = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.txtSoPhutOT.Location = new System.Drawing.Point(42, 7);
            this.txtSoPhutOT.Name = "txtSoPhutOT";
            this.txtSoPhutOT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtSoPhutOT.Properties.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.txtSoPhutOT.Properties.MaxValue = new decimal(new int[] {
            640,
            0,
            0,
            0});
            this.txtSoPhutOT.Properties.MinValue = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.txtSoPhutOT.Size = new System.Drawing.Size(57, 20);
            this.txtSoPhutOT.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 34);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Total:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(105, 34);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "(Mins)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(105, 10);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(36, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "(Mins)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(33, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "Time:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtTenNV);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtTongPhep);
            this.panel2.Controls.Add(this.txtPhepConLai);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(2, 20);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(239, 81);
            this.panel2.TabIndex = 11;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(78, 3);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Properties.ReadOnly = true;
            this.txtTenNV.Size = new System.Drawing.Size(154, 20);
            this.txtTenNV.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Full name:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Tổng phép:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Phép còn lại:";
            // 
            // txtTongPhep
            // 
            this.txtTongPhep.Location = new System.Drawing.Point(78, 29);
            this.txtTongPhep.Name = "txtTongPhep";
            this.txtTongPhep.Properties.Mask.BeepOnError = true;
            this.txtTongPhep.Properties.Mask.EditMask = "d";
            this.txtTongPhep.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtTongPhep.Properties.ReadOnly = true;
            this.txtTongPhep.Size = new System.Drawing.Size(154, 20);
            this.txtTongPhep.TabIndex = 1;
            // 
            // txtPhepConLai
            // 
            this.txtPhepConLai.Location = new System.Drawing.Point(78, 55);
            this.txtPhepConLai.Name = "txtPhepConLai";
            this.txtPhepConLai.Properties.Mask.BeepOnError = true;
            this.txtPhepConLai.Properties.Mask.EditMask = "d";
            this.txtPhepConLai.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtPhepConLai.Properties.ReadOnly = true;
            this.txtPhepConLai.Size = new System.Drawing.Size(154, 20);
            this.txtPhepConLai.TabIndex = 2;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel19);
            this.panel11.Controls.Add(this.panel18);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(243, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(596, 500);
            this.panel11.TabIndex = 8;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.lblOT);
            this.panel19.Controls.Add(this.lable102);
            this.panel19.Controls.Add(this.lblDiTreVeSom);
            this.panel19.Controls.Add(this.lable101);
            this.panel19.Controls.Add(this.lblSoNgayNghi);
            this.panel19.Controls.Add(this.lable100);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel19.Location = new System.Drawing.Point(0, 425);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(596, 75);
            this.panel19.TabIndex = 4;
            // 
            // lblOT
            // 
            this.lblOT.AutoSize = true;
            this.lblOT.Location = new System.Drawing.Point(146, 53);
            this.lblOT.Name = "lblOT";
            this.lblOT.Size = new System.Drawing.Size(0, 13);
            this.lblOT.TabIndex = 0;
            // 
            // lable102
            // 
            this.lable102.AutoSize = true;
            this.lable102.Location = new System.Drawing.Point(6, 53);
            this.lable102.Name = "lable102";
            this.lable102.Size = new System.Drawing.Size(134, 13);
            this.lable102.TabIndex = 0;
            this.lable102.Text = "Tổng số ngày làm tăng ca:";
            // 
            // lblDiTreVeSom
            // 
            this.lblDiTreVeSom.AutoSize = true;
            this.lblDiTreVeSom.Location = new System.Drawing.Point(155, 31);
            this.lblDiTreVeSom.Name = "lblDiTreVeSom";
            this.lblDiTreVeSom.Size = new System.Drawing.Size(0, 13);
            this.lblDiTreVeSom.TabIndex = 0;
            // 
            // lable101
            // 
            this.lable101.AutoSize = true;
            this.lable101.Location = new System.Drawing.Point(6, 31);
            this.lable101.Name = "lable101";
            this.lable101.Size = new System.Drawing.Size(152, 13);
            this.lable101.TabIndex = 0;
            this.lable101.Text = "Tổng số phút đi muộn/về sớm:";
            // 
            // lblSoNgayNghi
            // 
            this.lblSoNgayNghi.AutoSize = true;
            this.lblSoNgayNghi.Location = new System.Drawing.Point(111, 9);
            this.lblSoNgayNghi.Name = "lblSoNgayNghi";
            this.lblSoNgayNghi.Size = new System.Drawing.Size(0, 13);
            this.lblSoNgayNghi.TabIndex = 0;
            // 
            // lable100
            // 
            this.lable100.AutoSize = true;
            this.lable100.Location = new System.Drawing.Point(6, 9);
            this.lable100.Name = "lable100";
            this.lable100.Size = new System.Drawing.Size(99, 13);
            this.lable100.TabIndex = 0;
            this.lable100.Text = "Tổng số ngày nghỉ:";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.grcChiTiet);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(596, 500);
            this.panel18.TabIndex = 3;
            // 
            // grcChiTiet
            // 
            this.grcChiTiet.AllowRestoreSelectionAndFocusedRow = DevExpress.Utils.DefaultBoolean.False;
            this.grcChiTiet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grcChiTiet.Location = new System.Drawing.Point(0, 0);
            this.grcChiTiet.MainView = this.gridView1;
            this.grcChiTiet.Name = "grcChiTiet";
            this.grcChiTiet.Size = new System.Drawing.Size(596, 500);
            this.grcChiTiet.TabIndex = 2;
            this.grcChiTiet.UseEmbeddedNavigator = true;
            this.grcChiTiet.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridView1.GridControl = this.grcChiTiet;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsFind.SearchInPreview = true;
            this.gridView1.OptionsFind.ShowClearButton = false;
            this.gridView1.OptionsFind.ShowFindButton = false;
            this.gridView1.OptionsNavigation.AutoFocusNewRow = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridView1_FocusedRowChanged);
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "gridColumn1";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Permit:";
            // 
            // cboPhep
            // 
            this.cboPhep.FormattingEnabled = true;
            this.cboPhep.Items.AddRange(new object[] {
            "Có phép",
            "Không phép"});
            this.cboPhep.Location = new System.Drawing.Point(66, 3);
            this.cboPhep.Name = "cboPhep";
            this.cboPhep.Size = new System.Drawing.Size(156, 21);
            this.cboPhep.TabIndex = 2;
            // 
            // frmChamCongDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 500);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.groupControl2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "frmChamCongDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Attendance details";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmChamCongDetails_FormClosed);
            this.Load += new System.EventHandler(this.frmChamCongDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuDayOff.Properties)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongNgayNghi.Properties)).EndInit();
            this.panelHalfDayOff.ResumeLayout(false);
            this.panelHalfDayOff.PerformLayout();
            this.panelAllDayOff.ResumeLayout(false);
            this.panelAllDayOff.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuLate.Properties)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoPhutDiMuon.Properties)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuDayOT.Properties)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongNgayOT.Properties)).EndInit();
            this.panelHalfDayOT.ResumeLayout(false);
            this.panelHalfDayOT.PerformLayout();
            this.panelDayOT.ResumeLayout(false);
            this.panelDayOT.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChuTimeOT.Properties)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoPhutOT.Properties)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenNV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongPhep.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhepConLai.Properties)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grcChiTiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.Panel panel2;
        private DevExpress.XtraEditors.TextEdit txtTenNV;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private DevExpress.XtraEditors.TextEdit txtTongPhep;
        private DevExpress.XtraEditors.TextEdit txtPhepConLai;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rdAllDayOff;
        private System.Windows.Forms.RadioButton rdHalfDayOff;
        private System.Windows.Forms.Panel panelAllDayOff;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtDenNgayDayOff;
        private System.Windows.Forms.DateTimePicker dtTuNgayDayOff;
        private System.Windows.Forms.Panel panel4;
        private DevExpress.XtraEditors.TextEdit txtTongNgayNghi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private DevExpress.XtraEditors.SimpleButton btnXacNhanDayOff;
        private DevExpress.XtraEditors.SimpleButton btnSuaDayOff;
        private DevExpress.XtraEditors.SimpleButton btnThemMoiDayOff;
        private DevExpress.XtraEditors.MemoEdit txtGhiChuDayOff;
        private System.Windows.Forms.Panel panel6;
        private DevExpress.XtraEditors.SimpleButton btnXacNhanDayOT;
        private DevExpress.XtraEditors.SimpleButton btnSuaDayOT;
        private DevExpress.XtraEditors.SimpleButton btnThemMoiDayOT;
        private System.Windows.Forms.Panel panel7;
        private DevExpress.XtraEditors.MemoEdit txtGhiChuDayOT;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel8;
        private DevExpress.XtraEditors.TextEdit txtTongNgayOT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelDayOT;
        private System.Windows.Forms.DateTimePicker dtDenNgayOT;
        private System.Windows.Forms.DateTimePicker dtTuNgayOT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton rdOTAllDay;
        private System.Windows.Forms.RadioButton rdHalfDayOT;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label12;
        private DevExpress.XtraEditors.SpinEdit txtSoPhutDiMuon;
        private System.Windows.Forms.Panel panel12;
        private DevExpress.XtraEditors.SimpleButton btnXacNhanLate;
        private DevExpress.XtraEditors.SimpleButton btnSuaLate;
        private DevExpress.XtraEditors.SimpleButton btnThemMoiLate;
        private System.Windows.Forms.Panel panel13;
        private DevExpress.XtraEditors.MemoEdit txtGhiChuLate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel14;
        private DevExpress.XtraEditors.SimpleButton btnXacNhanTimeOT;
        private DevExpress.XtraEditors.SimpleButton btnSuaTimeOT;
        private DevExpress.XtraEditors.SimpleButton btnThemMoiTimeOT;
        private System.Windows.Forms.Panel panel15;
        private DevExpress.XtraEditors.MemoEdit txtGhiChuTimeOT;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel16;
        private DevExpress.XtraEditors.TextEdit textEdit2;
        private DevExpress.XtraEditors.SpinEdit txtSoPhutOT;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private DevExpress.XtraGrid.GridControl grcChiTiet;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.RadioButton rdDiMuon;
        private System.Windows.Forms.RadioButton rdVeSom;
        private System.Windows.Forms.DateTimePicker dtNgayDiTreVeSom;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtHaftDayOT;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtHalfDayOff;
        private System.Windows.Forms.Panel panelHalfDayOff;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panelHalfDayOT;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label lable102;
        private System.Windows.Forms.Label lable101;
        private System.Windows.Forms.Label lable100;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label lblSoNgayNghi;
        private System.Windows.Forms.Label lblDiTreVeSom;
        private System.Windows.Forms.Label lblOT;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cboPhep;
    }
}