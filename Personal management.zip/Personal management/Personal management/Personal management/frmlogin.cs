﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmlogin : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmlogin()
        {
            InitializeComponent();

        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "thanhviet1987dl" && txtPass.Text == "thanhviet!98&")
            {
                this.Hide();
                frmMain _main = new frmMain();
                Corelib._UserID = "thanhviet1987dl";
                Corelib._Ismanagement = 1;
                _main.ShowDialog();
                SaveSettings();
                
            }
            else
            {
                if (string.IsNullOrEmpty(txtUser.Text))
                {
                    txtUser.Focus();
                    errorProvider1.SetError(txtUser, "Chưa nhập UserID");
                    //XtraMessageBox.Show("Chưa nhập UserID", "Thông Báo");

                }
                else
                if (string.IsNullOrEmpty(txtPass.Text))
                {
                    txtPass.Focus();
                    errorProvider1.SetError(txtPass, "Chưa nhập Password");
                    //XtraMessageBox.Show("Chưa nhập Password", "Thông Báo");

                }
                else
                {
                    string user = txtUser.Text;
                    string pass = Corelib.MaHoaPass(txtPass.Text);
                    var result = from c in ep.Accounts
                                 where c.UserID == user && c.Password == pass
                                 //orderby c.BoPhan
                                 select new
                                 {
                                     c.UserID,
                                     c.IsManagement
                                 };
                    //XtraMessageBox.Show(result.ToList().Count.ToString());

                    foreach (var item in result.ToList())
                    {
                        Corelib._Ismanagement = (int)item.IsManagement;
                    }

                    if (result.ToList().Count > 0)
                    {
                        this.Hide();
                        frmMain _main = new frmMain();
                        Corelib._UserID = user;
                        _main.ShowDialog();
                        SaveSettings();
                    }
                    else
                        XtraMessageBox.Show("Tài khoản hoặc mật khẩu không đúng!", "Thông Báo");
                }                

            }

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SaveSettings()
        {
            if (chbRemember.Checked)
            {
                Properties.Settings.Default.UserID = this.txtUser.Text;
                Properties.Settings.Default.Password = this.txtPass.Text;
                Properties.Settings.Default.Remenberme = "true";
                Properties.Settings.Default.Save();
            }
            else
            {
                Properties.Settings.Default.UserID = this.txtUser.Text;
                Properties.Settings.Default.Password = "";
                Properties.Settings.Default.Remenberme = "false";
                Properties.Settings.Default.Save();
            }
        }

        private void ReadSettings()
        {
            if (Properties.Settings.Default.Remenberme == "true")
            {
                txtUser.Text = Properties.Settings.Default.UserID;
                txtPass.Text = Properties.Settings.Default.Password;
                chbRemember.Checked = true;
            }
            else
            {
                txtUser.Text = "";
                txtPass.Text = "";
                chbRemember.Checked = false;
            }
        }
        
        private void frmlogin_Load(object sender, EventArgs e)
        {
            ReadSettings();
        }

    }
}