﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmPhieuDanhGia : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmPhieuDanhGia()
        {
            InitializeComponent();
        }

        public string _MaNV { get; set; }
        public int _ID { get; set; }
        public string _ThemMoi { get; set; }
        void ThemMoiThongTin()
        {
            PhieuDanhGia phieudanhgia = new PhieuDanhGia()
            {
                MaNV = _MaNV,
                NgayLapPhieu = DateTime.Now,
                SuTapTrung = Convert.ToDouble(txtSuTapTrung.Text),
                ViecRieng = Convert.ToDouble(txtViecRieng.Text),
                SoNgayNghi = Convert.ToDouble(txtSoNgayNghi.Text),
                KienThuc = Convert.ToDouble(txtKienThuc.Text),
                KyNang = Convert.ToDouble(txtKyNang.Text),
                LangNghe = Convert.ToDouble(txtLangNghe.Text),
                GiaoTiep = Convert.ToDouble(txtGiaoTiep.Text),
                CanThan = Convert.ToDouble(txtSuCanThan.Text),
                LauDai = chbLauDai.Checked,
                LanhDao = chbToBeLeader.Checked,
                Note = txtGhiChu.Text
            };
            ep.PhieuDanhGias.Add(phieudanhgia);
            ep.SaveChanges();
        }

        void SuaThongTin(int _ID)
        {
            PhieuDanhGia phieudanhgia = ep.PhieuDanhGias.Find(_ID);
            phieudanhgia.NgayLapPhieu = DateTime.Now;
            phieudanhgia.SuTapTrung = Convert.ToDouble(txtSuTapTrung.Text);
            phieudanhgia.ViecRieng = Convert.ToDouble(txtViecRieng.Text);
            phieudanhgia.SoNgayNghi = Convert.ToDouble(txtSoNgayNghi.Text);
            phieudanhgia.KienThuc = Convert.ToDouble(txtKienThuc.Text);
            phieudanhgia.KyNang = Convert.ToDouble(txtKyNang.Text);
            phieudanhgia.LangNghe = Convert.ToDouble(txtLangNghe.Text);
            phieudanhgia.GiaoTiep = Convert.ToDouble(txtGiaoTiep.Text);
            phieudanhgia.CanThan = Convert.ToDouble(txtSuCanThan.Text);
            phieudanhgia.LauDai = chbLauDai.Checked;
            phieudanhgia.LanhDao = chbToBeLeader.Checked;
            phieudanhgia.Note = txtGhiChu.Text;
            ep.SaveChanges();
        }

        void CheckThemMoi()
        {
            if (_ThemMoi == "Insert")
            {
                txtSuTapTrung.Text = "0";
                txtViecRieng.Text = "0";
                txtSoNgayNghi.Text = "0";
                txtKienThuc.Text = "0";
                txtKyNang.Text = "0";
                txtLangNghe.Text = "0";
                txtGiaoTiep.Text = "0";
                txtSuCanThan.Text = "0";
                txtGhiChu.Text = "";
            }
            if (_ThemMoi == "Update")
            {
                NapDuLieuLenControl();
            }
        }

        void NapDuLieuLenControl()
        {
            var result = ep.PhieuDanhGias.SqlQuery("Select * from PhieuDanhGia where ID=" + _ID);
            foreach (var item in result.ToList())
            {
                txtSuTapTrung.Text = item.SuTapTrung.ToString();
                txtViecRieng.Text = item.ViecRieng.ToString();
                txtSoNgayNghi.Text = item.SoNgayNghi.ToString();
                txtKienThuc.Text = item.KienThuc.ToString();
                txtKyNang.Text = item.KyNang.ToString();
                txtLangNghe.Text = item.LangNghe.ToString();
                txtGiaoTiep.Text = item.GiaoTiep.ToString();
                txtSuCanThan.Text = item.CanThan.ToString();
                txtGhiChu.Text = item.Note.ToString();
                chbLauDai.Checked = Convert.ToBoolean(item.LauDai);
                chbToBeLeader.Checked = Convert.ToBoolean(item.LanhDao);
            }
        }
        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            if (_ThemMoi == "Insert")
            {
                ThemMoiThongTin();
                this.Close();
            }
                
            if (_ThemMoi == "Update")
            {
                this.DialogResult = DialogResult.OK;
                SuaThongTin(_ID);
                this.Close();
            }
               
        }

        private void frmPhieuDanhGia_Load(object sender, EventArgs e)
        {
            CheckThemMoi();
        }
    }
}