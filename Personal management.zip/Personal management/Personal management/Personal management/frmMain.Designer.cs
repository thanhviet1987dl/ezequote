﻿namespace Personal_management
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem7 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip8 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem8 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip9 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem9 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip10 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem10 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip11 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem11 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip12 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipItem toolTipItem12 = new DevExpress.Utils.ToolTipItem();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.btnDangNhap = new DevExpress.XtraBars.BarButtonItem();
            this.btnSaoLuuData = new DevExpress.XtraBars.BarButtonItem();
            this.btnDangXuat = new DevExpress.XtraBars.BarButtonItem();
            this.btnKhoiPhucDuLieu = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhanQuyen = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhanVienChinhThuc = new DevExpress.XtraBars.BarButtonItem();
            this.btnHocVien = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhanVienNghiViec = new DevExpress.XtraBars.BarButtonItem();
            this.btnThaiSan = new DevExpress.XtraBars.BarButtonItem();
            this.btnChucVu = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhongBan = new DevExpress.XtraBars.BarButtonItem();
            this.btnTeam = new DevExpress.XtraBars.BarButtonItem();
            this.btnChamCong = new DevExpress.XtraBars.BarButtonItem();
            this.menuHocVan = new DevExpress.XtraBars.BarButtonItem();
            this.menuChuyenMon = new DevExpress.XtraBars.BarButtonItem();
            this.btnVatTu = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPagephanquyen = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage7 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage6 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.repositoryItemImageEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemImageEdit();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.lblUserID = new DevExpress.XtraBars.BarStaticItem();
            this.lblClock = new DevExpress.XtraBars.BarStaticItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.repositoryItemTimeEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit();
            this.repositoryItemCalcEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.repositoryItemTokenEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTokenEdit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemImageEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTokenEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ButtonGroupsVertAlign = DevExpress.Utils.VertAlignment.Center;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.btnDangNhap,
            this.btnSaoLuuData,
            this.btnDangXuat,
            this.btnKhoiPhucDuLieu,
            this.btnPhanQuyen,
            this.btnNhanVienChinhThuc,
            this.btnHocVien,
            this.btnNhanVienNghiViec,
            this.btnThaiSan,
            this.btnChucVu,
            this.btnPhongBan,
            this.btnTeam,
            this.btnChamCong,
            this.menuHocVan,
            this.menuChuyenMon,
            this.btnVatTu});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 26;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.PageCategoryAlignment = DevExpress.XtraBars.Ribbon.RibbonPageCategoryAlignment.Left;
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage2,
            this.ribbonPage3,
            this.ribbonPage4,
            this.ribbonPage5,
            this.ribbonPage7,
            this.ribbonPage6});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemPictureEdit1,
            this.repositoryItemImageEdit1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013;
            this.ribbonControl1.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl1.Size = new System.Drawing.Size(676, 143);
            // 
            // btnDangNhap
            // 
            this.btnDangNhap.Caption = "Login";
            this.btnDangNhap.Glyph = ((System.Drawing.Image)(resources.GetObject("btnDangNhap.Glyph")));
            this.btnDangNhap.Id = 5;
            this.btnDangNhap.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnDangNhap.LargeGlyph")));
            this.btnDangNhap.Name = "btnDangNhap";
            toolTipItem7.Text = "Đăng nhập hệ thống";
            superToolTip7.Items.Add(toolTipItem7);
            this.btnDangNhap.SuperTip = superToolTip7;
            this.btnDangNhap.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.btnDangNhap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDangNhap_ItemClick);
            // 
            // btnSaoLuuData
            // 
            this.btnSaoLuuData.Caption = "Backup";
            this.btnSaoLuuData.Glyph = ((System.Drawing.Image)(resources.GetObject("btnSaoLuuData.Glyph")));
            this.btnSaoLuuData.Id = 6;
            this.btnSaoLuuData.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnSaoLuuData.LargeGlyph")));
            this.btnSaoLuuData.Name = "btnSaoLuuData";
            toolTipItem8.Text = "Sao lưu dữ liệu.";
            superToolTip8.Items.Add(toolTipItem8);
            this.btnSaoLuuData.SuperTip = superToolTip8;
            this.btnSaoLuuData.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSaoLuuData_ItemClick);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Caption = "Logout";
            this.btnDangXuat.Glyph = ((System.Drawing.Image)(resources.GetObject("btnDangXuat.Glyph")));
            this.btnDangXuat.Id = 9;
            this.btnDangXuat.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnDangXuat.LargeGlyph")));
            this.btnDangXuat.Name = "btnDangXuat";
            toolTipItem9.Text = "Thoát khỏi hệ thống.";
            superToolTip9.Items.Add(toolTipItem9);
            this.btnDangXuat.SuperTip = superToolTip9;
            this.btnDangXuat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDangXuat_ItemClick);
            // 
            // btnKhoiPhucDuLieu
            // 
            this.btnKhoiPhucDuLieu.Caption = "Restore";
            this.btnKhoiPhucDuLieu.Glyph = ((System.Drawing.Image)(resources.GetObject("btnKhoiPhucDuLieu.Glyph")));
            this.btnKhoiPhucDuLieu.Id = 10;
            this.btnKhoiPhucDuLieu.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnKhoiPhucDuLieu.LargeGlyph")));
            this.btnKhoiPhucDuLieu.Name = "btnKhoiPhucDuLieu";
            toolTipItem10.Text = "Khôi phục cơ sở dữ liệu.";
            superToolTip10.Items.Add(toolTipItem10);
            this.btnKhoiPhucDuLieu.SuperTip = superToolTip10;
            this.btnKhoiPhucDuLieu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKhoiPhucDuLieu_ItemClick);
            // 
            // btnPhanQuyen
            // 
            this.btnPhanQuyen.Caption = "Decentralization";
            this.btnPhanQuyen.Glyph = ((System.Drawing.Image)(resources.GetObject("btnPhanQuyen.Glyph")));
            this.btnPhanQuyen.Id = 11;
            this.btnPhanQuyen.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnPhanQuyen.LargeGlyph")));
            this.btnPhanQuyen.Name = "btnPhanQuyen";
            this.btnPhanQuyen.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhanQuyen_ItemClick);
            // 
            // btnNhanVienChinhThuc
            // 
            this.btnNhanVienChinhThuc.Caption = "Official staff";
            this.btnNhanVienChinhThuc.Glyph = ((System.Drawing.Image)(resources.GetObject("btnNhanVienChinhThuc.Glyph")));
            this.btnNhanVienChinhThuc.Id = 12;
            this.btnNhanVienChinhThuc.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnNhanVienChinhThuc.LargeGlyph")));
            this.btnNhanVienChinhThuc.Name = "btnNhanVienChinhThuc";
            this.btnNhanVienChinhThuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhanVienChinhThuc_ItemClick);
            // 
            // btnHocVien
            // 
            this.btnHocVien.Caption = "Trainee ";
            this.btnHocVien.Glyph = ((System.Drawing.Image)(resources.GetObject("btnHocVien.Glyph")));
            this.btnHocVien.Id = 13;
            this.btnHocVien.LargeGlyph = global::Personal_management.Properties.Resources.business_and_finance32;
            this.btnHocVien.Name = "btnHocVien";
            this.btnHocVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHocVien_ItemClick);
            // 
            // btnNhanVienNghiViec
            // 
            this.btnNhanVienNghiViec.Caption = "Employees leave";
            this.btnNhanVienNghiViec.Glyph = ((System.Drawing.Image)(resources.GetObject("btnNhanVienNghiViec.Glyph")));
            this.btnNhanVienNghiViec.Id = 14;
            this.btnNhanVienNghiViec.LargeGlyph = global::Personal_management.Properties.Resources.box32;
            this.btnNhanVienNghiViec.Name = "btnNhanVienNghiViec";
            this.btnNhanVienNghiViec.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhanVienNghiViec_ItemClick);
            // 
            // btnThaiSan
            // 
            this.btnThaiSan.Caption = "Maternity";
            this.btnThaiSan.Glyph = ((System.Drawing.Image)(resources.GetObject("btnThaiSan.Glyph")));
            this.btnThaiSan.Id = 15;
            this.btnThaiSan.LargeGlyph = global::Personal_management.Properties.Resources.woman32;
            this.btnThaiSan.Name = "btnThaiSan";
            this.btnThaiSan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThaiSan_ItemClick);
            // 
            // btnChucVu
            // 
            this.btnChucVu.Caption = "Position";
            this.btnChucVu.Glyph = ((System.Drawing.Image)(resources.GetObject("btnChucVu.Glyph")));
            this.btnChucVu.Id = 16;
            this.btnChucVu.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnChucVu.LargeGlyph")));
            this.btnChucVu.Name = "btnChucVu";
            toolTipItem11.Text = "Chức vụ";
            superToolTip11.Items.Add(toolTipItem11);
            this.btnChucVu.SuperTip = superToolTip11;
            this.btnChucVu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnChucVu_ItemClick);
            // 
            // btnPhongBan
            // 
            this.btnPhongBan.Caption = "Department";
            this.btnPhongBan.Glyph = ((System.Drawing.Image)(resources.GetObject("btnPhongBan.Glyph")));
            this.btnPhongBan.Id = 17;
            this.btnPhongBan.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnPhongBan.LargeGlyph")));
            this.btnPhongBan.Name = "btnPhongBan";
            toolTipItem12.Text = "Phòng ban";
            superToolTip12.Items.Add(toolTipItem12);
            this.btnPhongBan.SuperTip = superToolTip12;
            this.btnPhongBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhongBan_ItemClick);
            // 
            // btnTeam
            // 
            this.btnTeam.Caption = "Team";
            this.btnTeam.Glyph = ((System.Drawing.Image)(resources.GetObject("btnTeam.Glyph")));
            this.btnTeam.Id = 18;
            this.btnTeam.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnTeam.LargeGlyph")));
            this.btnTeam.Name = "btnTeam";
            this.btnTeam.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTeam_ItemClick);
            // 
            // btnChamCong
            // 
            this.btnChamCong.Caption = "Attendance details";
            this.btnChamCong.Glyph = ((System.Drawing.Image)(resources.GetObject("btnChamCong.Glyph")));
            this.btnChamCong.Id = 19;
            this.btnChamCong.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnChamCong.LargeGlyph")));
            this.btnChamCong.Name = "btnChamCong";
            this.btnChamCong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnChamCong_ItemClick);
            // 
            // menuHocVan
            // 
            this.menuHocVan.Caption = "Literacy\r\n";
            this.menuHocVan.Glyph = ((System.Drawing.Image)(resources.GetObject("menuHocVan.Glyph")));
            this.menuHocVan.Id = 20;
            this.menuHocVan.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("menuHocVan.LargeGlyph")));
            this.menuHocVan.Name = "menuHocVan";
            // 
            // menuChuyenMon
            // 
            this.menuChuyenMon.Caption = "Major";
            this.menuChuyenMon.Glyph = global::Personal_management.Properties.Resources.boresume_16x16;
            this.menuChuyenMon.Id = 21;
            this.menuChuyenMon.LargeGlyph = global::Personal_management.Properties.Resources.boresume_32x32;
            this.menuChuyenMon.Name = "menuChuyenMon";
            // 
            // btnVatTu
            // 
            this.btnVatTu.Caption = "Equipment";
            this.btnVatTu.Id = 25;
            this.btnVatTu.LargeGlyph = global::Personal_management.Properties.Resources.Equipment1;
            this.btnVatTu.Name = "btnVatTu";
            this.btnVatTu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnVatTu_ItemClick);
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup3,
            this.ribbonPagephanquyen});
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Systems";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.Glyph = ((System.Drawing.Image)(resources.GetObject("ribbonPageGroup2.Glyph")));
            this.ribbonPageGroup2.ItemLinks.Add(this.btnDangNhap);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnDangXuat);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "User";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.btnSaoLuuData);
            this.ribbonPageGroup3.ItemLinks.Add(this.btnKhoiPhucDuLieu);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Data";
            this.ribbonPageGroup3.Visible = false;
            // 
            // ribbonPagephanquyen
            // 
            this.ribbonPagephanquyen.ItemLinks.Add(this.btnPhanQuyen);
            this.ribbonPagephanquyen.Name = "ribbonPagephanquyen";
            this.ribbonPagephanquyen.Text = "Decentralization";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup5});
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "HRM";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.btnNhanVienChinhThuc);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnHocVien);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnNhanVienNghiViec);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnThaiSan);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Human Resource Management";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup6});
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Category";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.btnChucVu);
            this.ribbonPageGroup6.ItemLinks.Add(this.btnPhongBan);
            this.ribbonPageGroup6.ItemLinks.Add(this.btnTeam);
            this.ribbonPageGroup6.ItemLinks.Add(this.menuHocVan);
            this.ribbonPageGroup6.ItemLinks.Add(this.menuChuyenMon);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup7});
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "Timekeeping";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.ItemLinks.Add(this.btnChamCong);
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            // 
            // ribbonPage7
            // 
            this.ribbonPage7.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup4});
            this.ribbonPage7.Name = "ribbonPage7";
            this.ribbonPage7.Text = "Equipment";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.btnVatTu);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            // 
            // ribbonPage6
            // 
            this.ribbonPage6.Name = "ribbonPage6";
            this.ribbonPage6.Text = "Help";
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            // 
            // repositoryItemImageEdit1
            // 
            this.repositoryItemImageEdit1.AutoHeight = false;
            this.repositoryItemImageEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemImageEdit1.Name = "repositoryItemImageEdit1";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "ribbonPage1";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InActiveTabPageHeaderAndOnMouseHover;
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 143);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.Size = new System.Drawing.Size(676, 284);
            this.xtraTabControl1.TabIndex = 1;
            this.xtraTabControl1.CloseButtonClick += new System.EventHandler(this.xtraTabControl1_CloseButtonClick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar3});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.lblUserID,
            this.lblClock});
            this.barManager1.MaxItemId = 7;
            this.barManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTimeEdit1,
            this.repositoryItemCalcEdit1,
            this.repositoryItemTokenEdit1});
            this.barManager1.StatusBar = this.bar3;
            // 
            // bar3
            // 
            this.bar3.BarName = "Status bar";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.lblUserID, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.lblClock, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            this.bar3.Text = "Status bar";
            // 
            // lblUserID
            // 
            this.lblUserID.Caption = "barStaticItem1";
            this.lblUserID.Glyph = ((System.Drawing.Image)(resources.GetObject("lblUserID.Glyph")));
            this.lblUserID.Id = 1;
            this.lblUserID.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("lblUserID.LargeGlyph")));
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // lblClock
            // 
            this.lblClock.Caption = "barStaticItem1";
            this.lblClock.Glyph = ((System.Drawing.Image)(resources.GetObject("lblClock.Glyph")));
            this.lblClock.Id = 3;
            this.lblClock.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("lblClock.LargeGlyph")));
            this.lblClock.Name = "lblClock";
            this.lblClock.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(676, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 427);
            this.barDockControlBottom.Size = new System.Drawing.Size(676, 27);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 427);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(676, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 427);
            // 
            // repositoryItemTimeEdit1
            // 
            this.repositoryItemTimeEdit1.AutoHeight = false;
            this.repositoryItemTimeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemTimeEdit1.Name = "repositoryItemTimeEdit1";
            // 
            // repositoryItemCalcEdit1
            // 
            this.repositoryItemCalcEdit1.AutoHeight = false;
            this.repositoryItemCalcEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEdit1.Name = "repositoryItemCalcEdit1";
            // 
            // repositoryItemTokenEdit1
            // 
            this.repositoryItemTokenEdit1.Name = "repositoryItemTokenEdit1";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 454);
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Ribbon = this.ribbonControl1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ezequote Data Entry";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemImageEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTokenEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.BarButtonItem btnDangNhap;
        private DevExpress.XtraBars.BarButtonItem btnSaoLuuData;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageEdit repositoryItemImageEdit1;
        private DevExpress.XtraBars.BarButtonItem btnDangXuat;
        private DevExpress.XtraBars.BarButtonItem btnKhoiPhucDuLieu;
        private DevExpress.XtraBars.BarButtonItem btnPhanQuyen;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPagephanquyen;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.BarButtonItem btnNhanVienChinhThuc;
        private DevExpress.XtraBars.BarButtonItem btnHocVien;
        private DevExpress.XtraBars.BarButtonItem btnNhanVienNghiViec;
        private DevExpress.XtraBars.BarButtonItem btnThaiSan;
        private DevExpress.XtraBars.BarButtonItem btnChucVu;
        private DevExpress.XtraBars.BarButtonItem btnPhongBan;
        private DevExpress.XtraBars.BarButtonItem btnTeam;
        private DevExpress.XtraBars.BarButtonItem btnChamCong;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private System.Windows.Forms.Timer timer1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage6;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit repositoryItemTimeEdit1;
        private DevExpress.XtraBars.BarStaticItem lblUserID;
        private DevExpress.XtraBars.BarStaticItem lblClock;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTokenEdit repositoryItemTokenEdit1;
        private DevExpress.XtraBars.BarButtonItem menuHocVan;
        private DevExpress.XtraBars.BarButtonItem menuChuyenMon;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage7;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.BarButtonItem btnVatTu;
    }
}