﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Personal_management
{
    public partial class frmPhongBan : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        bool kiemtrathemmoi = false;
        public frmPhongBan()
        {
            InitializeComponent();
            FormatGrid_BoPhan();
            LoadBoPhan();
            txtMa.ReadOnly = true;
            txtTen.ReadOnly = true;
            btnXacNhan.Enabled = false;
        }

        private void FormatGrid_BoPhan()
        {
            gridView1.Columns.Clear();
            string[] fields = { "MaBoPhan", "TenBoPhan"};

            string[] captions = { "Mã bộ phận/phòng ban","Tên bộ phận/phòng ban"};

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;

            }
            gridView1.Columns["MaBoPhan"].Visible = false;
            gridView1.Columns["TenBoPhan"].Width = 200;
        }

        void LoadBoPhan()
        {
            var result = from c in ep.BoPhans select new { c.MaBoPhan, c.TenBoPhan };
            grcBoPhan.DataSource = result.ToList();
        }

        void AddBinding()
        {
            txtMa.DataBindings.Clear();
            txtMa.DataBindings.Add(new Binding("Text", grcBoPhan.DataSource, "MaBoPhan"));
            txtTen.DataBindings.Clear();
            txtTen.DataBindings.Add(new Binding("Text", grcBoPhan.DataSource, "TenBoPhan"));
        }

        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            AddBinding();
        }

        void ThemMoiThongTin()
        {
            txtMa.Text = Corelib.maTuTang("Team", Convert.ToInt32(ep.BoPhans.Count().ToString()));
            BoPhan bophan = new BoPhan()
            {
                MaBoPhan = txtMa.Text,
                TenBoPhan = txtTen.Text
            };
            ep.BoPhans.Add(bophan);
            ep.SaveChanges();
        }

        void SuaThongTin()
        {
            BoPhan bophan = ep.BoPhans.Find(txtMa.Text);
            bophan.TenBoPhan = txtTen.Text;
            ep.SaveChanges();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtTen.ReadOnly = false;
            btnXacNhan.Enabled = true;
            btnAdd.Enabled = false;
            btnSua.Enabled = false;
            kiemtrathemmoi = true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            txtTen.ReadOnly = false;
            btnXacNhan.Enabled = true;
            btnAdd.Enabled = false;
            btnSua.Enabled = false;
            kiemtrathemmoi = false;
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            if (kiemtrathemmoi == true)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn thêm bộ phận mới này vào dữ liệu không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ThemMoiThongTin();
            }
            if (kiemtrathemmoi == false)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn thay đổi thông tin bộ phận này không?", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    SuaThongTin();
            }

            txtTen.ReadOnly = false;
            btnXacNhan.Enabled = true;
            btnAdd.Enabled = false;
            btnSua.Enabled = false;
        }
    }
}
