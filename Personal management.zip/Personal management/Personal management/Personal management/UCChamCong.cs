﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class UCChamCong : UserControl
    {
        Ezequote_personal ep = new Ezequote_personal();
        int _ma = 0;
        string _ten = "";
        int _IsLock = 0;

        public UCChamCong()
        {
            InitializeComponent();
            FormatGrid_NhanVien();
            LoadNhanVien(DateTime.Now.Month,DateTime.Now.Year);

            LoadThang();
            LoadNam();
            cboNam.Text = DateTime.Now.Year.ToString();

            if (_IsLock == 1)
            {
                menuLock.Enabled = false;
                btnSua.Enabled = false;
                btnXacNhan.Enabled = false;
            }               

            txtTongPhep.ReadOnly = true;
            txtPhepConLai.ReadOnly = true;
            btnXacNhan.Enabled = false;

        }

        #region Copy dữ liệu gốc để tạo table chấm công cho tháng mới
        void Copydulieu(int thang, int nam)
        {
            //int _thangHienTai = DateTime.Now.Month;
            int _luongthanggoc = 0;
            //int _namHienTai = DateTime.Now.Year;
            int _maxNam = Convert.ToInt32(ep.ChamCongs.Max(p => p.Nam));
            int _maxThang = Convert.ToInt32(ep.ChamCongs.Max(p => p.Thang));

            if (thang == _maxThang && nam == _maxNam)
            {
                XtraMessageBox.Show("Đã tạo bảng lương cho tháng này", "Thông báo", MessageBoxButtons.OK);
                return;
            }                

            // Kiểm tra nếu lương tháng 1 thì phải sử dụng dữ liệu gốc là lương tháng 12 của năm trước đó
            if (chbOldData.Checked == true)
            {
                if (thang == 1)
                {
                    _luongthanggoc = 12;                    
                    var laydulieugoc = from c in ep.ChamCongs
                                       where c.Thang == _luongthanggoc.ToString() && c.Nam == _maxNam.ToString()
                                       select new
                                       {
                                           c.MaNV,
                                           c.PhepConLai,
                                       };

                    foreach (var item in laydulieugoc.ToList())
                    {
                        //2. Lưu vào table chấm công
                        string _MaNV = item.MaNV.ToString();
                        int _Tongphep = Convert.ToInt32(item.PhepConLai);
                        ChamCong ccong = new ChamCong()
                        {
                            MaNV = _MaNV,
                            Thang = thang.ToString(),
                            Nam = nam.ToString(),
                            TongPhep = _Tongphep,
                            PhepConLai = _Tongphep,
                            NgayNghi = 0,
                            VeSom = 0,
                            DiTre = 0,
                            DateOTCuoiTuan = 0,
                            TimeOTCuoiTuan = 0,
                            IsLock = 0,

                        };
                        ep.ChamCongs.Add(ccong);
                        ep.SaveChanges();
                    }

                }
                else
                {
                    var laydulieugoc = from c in ep.ChamCongs
                                       where c.Thang == (thang - 1).ToString() && c.Nam == nam.ToString()
                                       select new
                                       {
                                           c.MaNV,
                                           c.PhepConLai,
                                       };

                    foreach (var item in laydulieugoc.ToList())
                    {
                        //2. Lưu vào table chấm công
                        string _MaNV = item.MaNV.ToString();
                        int _Tongphep = Convert.ToInt32(item.PhepConLai);
                        ChamCong ccong = new ChamCong()
                        {
                            MaNV = _MaNV,
                            Thang = thang.ToString(),
                            Nam = nam.ToString(),
                            TongPhep = _Tongphep,
                            PhepConLai = _Tongphep,
                            NgayNghi = 0,
                            VeSom = 0,
                            DiTre = 0,
                            DateOTCuoiTuan = 0,
                            TimeOTCuoiTuan = 0,
                            IsLock = 0,

                        };
                        ep.ChamCongs.Add(ccong);
                        ep.SaveChanges();
                    }
                }

            }
            else
            {
                //1. Copy dữ liệu gốc
                var result = from c in ep.NhanViens
                             where c.IsDelete == false
                             select new
                             {
                                 c.MaNV,
                             };
                int sum = result.Count();
                //int start = 1;
                //pgTienTrinh.Minimum = 1;
                //pgTienTrinh.Maximum = sum;
                foreach (var item in result.ToList())
                {
                    //2. Lưu vào table chấm công

                    string _MaNV = item.MaNV.ToString();
                    ChamCong ccong = new ChamCong()
                    {
                        MaNV = _MaNV,
                        TongPhep = 12,
                        PhepConLai = 12,
                        NgayNghi=0,
                        VeSom=0,
                        DiTre=0,
                        DateOTCuoiTuan=0,
                        TimeOTCuoiTuan=0,
                        Thang=DateTime.Now.Month.ToString(),
                        Nam = DateTime.Now.Year.ToString(),
                        IsLock = 0,
                    };
                    ep.ChamCongs.Add(ccong);
                    ep.SaveChanges();
                    //pgTienTrinh.Value = start++;

                }
            }


            XtraMessageBox.Show("Sao chép dữ liệu thành công", "Thông báo", MessageBoxButtons.OK);
            
        }
        #endregion
        
        private void btnTaoBangLuong_Click(object sender, EventArgs e)
        {                    
            Copydulieu(DateTime.Now.Month,DateTime.Now.Year);
            LoadNhanVien(DateTime.Now.Month, DateTime.Now.Year);
        }

        private void FormatGrid_NhanVien()
        {
            gridView1.Columns.Clear();
            string[] fields = { "MaCC", "MaNV", "TenNV", "TenEng", "TongPhep", "PhepConLai", "NgayNghi",
                "VeSom", "DiTre", "DateOTCuoiTuan", "TimeOTCuoiTuan", "GhiChu","IsLock"};

            string[] captions = { "Mã Chấm Công","Mã NV", "Họ tên", "Têng Eng", "Tổng phép", "Phép còn lại", "Ngày nghỉ",
                "Về sớm(Phút)", "Đi muộn(Phút)", "Ngày OT", "Giờ OT", "Ghi chú","Lock"};            

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;

            }
            gridView1.Columns["MaCC"].Visible = false;
            gridView1.Columns["MaNV"].Visible = false;
            gridView1.Columns["IsLock"].Visible = false;
            gridView1.Columns["TenNV"].Width = 200;
        }

        void LoadNhanVien(int thang, int nam)
        {
            var result = from c in ep.ChamCongs
                         where c.Thang == thang.ToString() && c.Nam == nam.ToString()
                         select new
                         {
                             c.MaCC,
                             c.MaNV,
                             c.NhanVien.TenNV,
                             c.NhanVien.TenEng,
                             c.TongPhep,
                             c.PhepConLai,
                             c.NgayNghi,
                             c.VeSom,
                             c.DiTre,
                             c.DateOTCuoiTuan,
                             c.TimeOTCuoiTuan,
                             c.GhiChu,
                             c.IsLock
                         };
            grcChamCong.DataSource = result.ToList();
            //Group by theo bộ phận
            //TenBoPhan.GroupIndex = 1;
            //TenNhom.GroupIndex = 1;
        }

        void LoadDatatoControls()
        {
            _ma = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("MaCC").ToString());
            _ten = gridView1.GetFocusedRowCellDisplayText("TenNV").ToString();
            _IsLock = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("IsLock").ToString());
            txtTenNV.Text = gridView1.GetFocusedRowCellDisplayText("TenNV").ToString();
            txtTongPhep.Text = gridView1.GetFocusedRowCellDisplayText("TongPhep").ToString();
            txtPhepConLai.Text = gridView1.GetFocusedRowCellDisplayText("PhepConLai").ToString();
        }

        void LoadThang()
        {
            cboThang.Items.Clear();
            Dictionary<string, string> comboSource = new Dictionary<string, string>();
            comboSource.Add("1", "Tháng giêng");
            comboSource.Add("2", "Tháng 2");
            comboSource.Add("3", "Tháng 3");
            comboSource.Add("4", "Tháng 4");
            comboSource.Add("5", "Tháng 5");
            comboSource.Add("6", "Tháng 6");
            comboSource.Add("7", "Tháng 7");
            comboSource.Add("8", "Tháng 8");
            comboSource.Add("9", "Tháng 9");
            comboSource.Add("10", "Tháng 10");
            comboSource.Add("11", "Tháng 11");
            comboSource.Add("12", "Tháng 12");
            cboThang.DataSource = new BindingSource(comboSource, null);
            cboThang.DisplayMember = "Value";
            cboThang.ValueMember = "Key";
        }

        void LoadNam()
        {
            cboNam.Items.Clear();
            for (int i = 2014; i <= DateTime.Now.Year; i++)
            {
                cboNam.Items.Add(i);
            }
        }
       
        void ExporttoExcel()
        {
            gridView1.ExportToXlsx("");
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            LoadNhanVien(int.Parse(cboThang.SelectedValue.ToString()), int.Parse(cboNam.SelectedItem.ToString()));
        }
        
        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            LoadDatatoControls();
        }        

        private void gridView1_RowStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs e)
        {

        }

        private void mnExporttoExcel_Click(object sender, EventArgs e)
        {
            if(SaveDia.ShowDialog() == DialogResult.OK)
            {
                string path = SaveDia.FileName;
                gridView1.ExportToXlsx(path);
            }           
        }     

        private void gridView1_DoubleClick(object sender, EventArgs e)
        {
            DXMouseEventArgs ea = e as DXMouseEventArgs;
            GridView view = sender as GridView;
            GridHitInfo info = view.CalcHitInfo(ea.Location);

            if (info.InRow || info.InRowCell)
            {
                //string colCaption = info.Column == null ? "N/A" : info.Column.GetCaption();
                //XtraMessageBox.Show(string.Format("DoubleClick on row: {0}, column: {1}.", info.RowHandle, colCaption));
                int machamcong = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("MaCC").ToString());
                string manhanvien = gridView1.GetFocusedRowCellDisplayText("MaNV").ToString();    
                string tennhanvien = gridView1.GetFocusedRowCellDisplayText("TenNV").ToString();
                double tongphep = Convert.ToDouble(gridView1.GetFocusedRowCellDisplayText("TongPhep").ToString());
                double phepconlai = Convert.ToDouble(gridView1.GetFocusedRowCellDisplayText("PhepConLai").ToString());
                int IsLock = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("IsLock").ToString());
                frmChamCongDetails frm = new frmChamCongDetails();
                frm.MaChamCong = machamcong;
                frm.MaNhanVien = manhanvien;
                frm.TenNhanVien = tennhanvien;
                frm.TongPhep = tongphep;
                frm.PhepConLai = phepconlai;
                frm._Islock = IsLock;
                frm.ShowDialog();
            }
        }

        private void menuRefresh_Click(object sender, EventArgs e)
        {
            LoadNhanVien(DateTime.Now.Month, DateTime.Now.Year);
        }

        void CapNhatDuLieuPhepConLai()
        {
            if(XtraMessageBox.Show("Bạn chắc chắn đã kiểm tra đầy đủ thông tin. Khi bạn thực hiện cập nhật, dữ liệu của tháng này sẽ được khóa và không thể thay đổi.","Thông Báo",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)==DialogResult.OK)
            {
                if (ep.UpdatePhepConLai(DateTime.Now.Month, DateTime.Now.Year) > 0)
                    LoadNhanVien(DateTime.Now.Month, DateTime.Now.Year);
            }
            
            
        }

        private void menuLock_Click(object sender, EventArgs e)
        {
            CapNhatDuLieuPhepConLai();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            txtTongPhep.ReadOnly = false;
            txtPhepConLai.ReadOnly = false;
            btnXacNhan.Enabled = true;
            btnSua.Enabled = false;
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            txtTongPhep.ReadOnly = true;
            txtPhepConLai.ReadOnly = true;
            btnXacNhan.Enabled = false;
            btnSua.Enabled = true;

            ChamCong cc = ep.ChamCongs.Find(_ma);
            cc.TongPhep = Convert.ToInt32(txtTongPhep.Text);
            cc.PhepConLai = Convert.ToInt32(txtPhepConLai.Text);
            if (ep.SaveChanges() > 0)
                XtraMessageBox.Show("Cập nhật dữ liệu thành công.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
