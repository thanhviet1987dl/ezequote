﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Personal_management
{
    class Corelib
    {
        /// <summary>
        /// Hàm tạo mã tự động
        /// </summary>
        /// <param name="kytudau"> Phần ký tự đầu (Ví dụ: NVxxx, EZExxx)</param>
        /// <param name="laysodong">lấy số dòng trong 1 bảng để đánh số tiếp theo ghép vào chuỗi ký tự đầu tạo mã NV005, NV006</param>
        /// <returns></returns>
        public static string maTuTang(string kytudau, int laysodong)
        {
            string ma = "";
            int k = laysodong;
            k = k + 1;
            if (k < 10)
                ma = kytudau + "000" + k;
            else
            if (k < 100)
                ma = kytudau + "00" + k;
            else
            if (k < 1000)
                ma = kytudau + "0" + k;
            else
                ma = kytudau + k;
            return ma;
        }
        public static string _chucVu { get; set; }
        public static string _boPhan { get; set; }
        public static string _groupTeam { get; set; }
        public static string _UserID { get; set; }
        public static int _Ismanagement { get; set; }

        #region Tạo key bản quyền cho phần mềm
        public static string ConvertStringToSecureCode(string Input1)
        {
            MD5 Secu1 = MD5.Create();
            byte[] data1 = Secu1.ComputeHash(Encoding.Default.GetBytes(Input1));
            StringBuilder sbd = new StringBuilder();
            for (int i = 0; i <= data1.Length - 1; i++)
            {
                sbd.Append(data1[i].ToString("x2"));
            }
            return sbd.ToString();
        }

        public static string GetRequestLicenseCode()
        {
            string Hd1 = HardDiskSeriesNumber();
            string Code1 = ConvertStringToSecureCode(Hd1);
            string Code2 = Code1.Substring(24).ToUpper();
            return Code2;
        }


        public static string HardDiskSeriesNumber()
        {
            string output = ExecuteCommandSync("vol");
            string aa = output.Split('.')[output.Split('.').Length - 1];
            string bb = aa.Split(' ')[aa.Split(' ').Length - 1];
            return bb.ToString().ToUpper();
        }

        public static string ExecuteCommandSync(object command)
        {
            try
            {
                // create the ProcessStartInfo using "cmd" as the program to be run,
                // and "/c " as the parameters.
                // Incidentally, /c tells cmd that we want it to execute the command that follows,
                // and then exit.
                System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + command);

                // The following commands are needed to redirect the standard output.
                // This means that it will be redirected to the Process.StandardOutput StreamReader.
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                procStartInfo.CreateNoWindow = true;
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
                return result;
            }
            catch (Exception)
            {
                // Log the exception
                return null;
            }
        }


        #endregion

        /// <summary>
        /// Hàm convert hình ảnh về chuỗi byte
        /// </summary>
        /// <param name="pathimage">Đường dẫn đến file ảnh</param>
        /// <returns></returns>
        public static byte[] converImgToByte(string pathimage)
        {
            FileStream fs;
            fs = new FileStream(pathimage, FileMode.Open, FileAccess.Read);
            byte[] picbyte = new byte[fs.Length];
            fs.Read(picbyte, 0, System.Convert.ToInt32(fs.Length));
            fs.Close();
            return picbyte;
        }

        /// <summary>
        /// Hàm convert chuỗi byte về hình ảnh
        /// </summary>
        /// <param name="byteString"> Chuỗi mã hóa hình ảnh ở dạng byte</param>
        /// <returns></returns>
        public static Image ByteToImg(string byteString)
        {
            byte[] imgBytes = Convert.FromBase64String(byteString);
            MemoryStream ms = new MemoryStream(imgBytes, 0, imgBytes.Length);
            ms.Write(imgBytes, 0, imgBytes.Length);
            Image image = Image.FromStream(ms, true);
            return image;
        }

        /// <summary>
        /// Mã hóa chuỗi có mật khẩu
        /// </summary>
        /// <param name="toEncrypt">Chuỗi cần mã hóa</param>
        /// <returns>Chuỗi đã mã hóa</returns>
        /// 

        public static string key = "ngothanhviet1987";
        public static string MaHoaPass(string toEncrypt)
        {
            
            bool useHashing = true;
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        /// <summary>
        /// Giải mã
        /// </summary>
        /// <param name="toDecrypt">Chuỗi đã mã hóa</param>
        /// <returns>Chuỗi giản mã</returns>
        public static string GiaiMaPass(string toDecrypt)
        {
            bool useHashing = true;
            byte[] keyArray;
            byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            return UTF8Encoding.UTF8.GetString(resultArray);
        }

    }
}
