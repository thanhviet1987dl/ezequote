﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmNhanVienThuViec : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmNhanVienThuViec()
        {
            InitializeComponent();
        }
        public string MaNhanVien { get; set; }
        public string TenNhanVien { get; set; }

        private void frmNhanVienThuViec_Load(object sender, EventArgs e)
        {
            lblTen.Text = TenNhanVien;
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show("Đây là thông tin không thể sửa đổi sau khi lưu. Vui lòng lòng kiểm tra kỹ trước khi thực hiện", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                NhanVienThuViec nvthuviec = new NhanVienThuViec()
                {
                    MaNV = MaNhanVien,
                    TuNgay = dtTuNgay.Value,
                    DenNgay = dtDenNgay.Value
                };
                ep.NhanVienThuViecs.Add(nvthuviec);
                ep.SaveChanges();

                // Update IDStatus=2 : đang thử việc
                NhanVien nv = ep.NhanViens.Find(MaNhanVien);
                nv.IDStatus = 2;
                ep.SaveChanges();
            }
        }
    }
}