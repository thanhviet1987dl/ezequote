﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmDanhSachPhieuDanhGia : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        int index = -1;
        public frmDanhSachPhieuDanhGia()
        {
            InitializeComponent();
        }
        public string _MaNV { get; set; }
        void LayThongTinNhanVien(string manv)
        {
            var result = ep.NhanViens.SqlQuery("SELECT * FROM NhanVien WHERE MaNV = " + "'" + manv + "'");
            foreach (var item in result.ToList())
            {
                this.Text = "Danh sách phiếu đánh giá nhân viên: " + item.TenNV + "--" + item.TenEng;
            }
        }
        void NapDanhSachPhieuDanhGia(string manv)
        {
            gridView1.Columns.Clear();
            string[] fields = { "ID", "MaNV", "NgayLapPhieu", "SuTapTrung", "ViecRieng", "SoNgayNghi", "KienThuc", "KyNang", "LangNghe", "GiaoTiep", "CanThan", "LauDai", "LanhDao", "Note" };

            string[] captions = { "ID", "MaNV", "Date", "Focus", "Personal Items", "Day Off", "Knowledge", "Software Skill", "Listening", "Communication", "Carefulness", "Temporary/Permernant", "Can be a leader/Just normal staffs", "Commnent" };

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;

            }
            gridView1.Columns["ID"].Visible = false;
            gridView1.Columns["MaNV"].Visible = false;

            // set autocolumnwith = false
            // sau đó bật thuộc tính bestfitcolumn để tự chỉnh độ rộng theo độ rộng nội dung
            gridView1.BestFitColumns();

            //var result = ep.PhieuDanhGias.SqlQuery("SELECT * FROM PhieuDanhGia WHERE MaNV = " + "'" + manv + "'");
            var result = from c in ep.PhieuDanhGias
                         where c.MaNV == manv
                         select new
                         {
                             c.ID,
                             c.MaNV,
                             c.SuTapTrung,
                             c.NgayLapPhieu,
                             c.ViecRieng,
                             c.SoNgayNghi,
                             c.KienThuc,
                             c.KyNang,
                             c.LangNghe,
                             c.GiaoTiep,
                             c.CanThan,
                             LauDai = (c.LauDai != true) ? "Temporary " : "Permernant",
                             LanhDao = (c.LanhDao != true) ? "Just normal staffs" : "Can be a leader ",
                             c.Note
                         };
            grcDSPhieuDanhGia.DataSource = result.ToList();

        }
        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPhieuDanhGia frm = new frmPhieuDanhGia();
            if (index == -1)
                XtraMessageBox.Show("Chưa có dữ liệu để cập nhật", "Thông báo", MessageBoxButtons.OK);
            else
            {
                frm._ID = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("ID").ToString());
                frm._ThemMoi = "Update";
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    NapDanhSachPhieuDanhGia(_MaNV);
                }
            }
        }
        private void frmDanhSachPhieuDanhGia_Load(object sender, EventArgs e)
        {
            NapDanhSachPhieuDanhGia(_MaNV);
            LayThongTinNhanVien(_MaNV);
        }
        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            index = e.FocusedRowHandle;
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPrint frm = new frmPrint();
            frm._MaNV = _MaNV;
            frm._IDPhieuDanhGia = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("ID").ToString());
            frm.ShowDialog();
        }
    }
}