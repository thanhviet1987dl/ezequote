﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmListNhanVien : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmListNhanVien()
        {
            InitializeComponent();
            FormatGrid_NhanVien();
        }
        public int iIDStatus { get; set; }

        private void FormatGrid_NhanVien()
        {
            gridView1.Columns.Clear();
            string[] fields = {  "TenNV", "TuNgay", "DenNgay", "Note"};

            string[] captions = { "Full name", "Start day", "End day","Note"};

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;
            }
        }

        void LoadDanhSachNhanVien()
        {
            if (iIDStatus == 2) // Đang học việc
            {
                var result2 = from c in ep.NhanVienThuViecs select new { c.NhanVien.TenNV, c.TuNgay, c.DenNgay, c.Note };
                grcNhanVien.DataSource = result2.ToList();
                chartControl1.DataSource = ep.chartthuviec(DateTime.Now.Year).ToList();
            }
            if (iIDStatus == 4) // Thai sản
            {
                var result4 = from c in ep.NhanVienThaiSans select new { c.NhanVien.TenNV, c.TuNgay, c.DenNgay, c.Note };
                grcNhanVien.DataSource = result4.ToList();
                chartControl1.DataSource = ep.chartthaisan(DateTime.Now.Year).ToList();
            }
            if (iIDStatus == 6) // Đã nghỉ việc
            {
                var result6 = from c in ep.NhanVienNghiViecs select new { c.NhanVien.TenNV, c.TuNgay, c.DenNgay, c.Note };
                grcNhanVien.DataSource = result6.ToList();
                chartControl1.DataSource = ep.chartnghiviec(DateTime.Now.Year).ToList();
            }
        }

        private void frmListNhanVien_Load(object sender, EventArgs e)
        {
            LoadDanhSachNhanVien();
            //chartControl1.DataSource = ep.thangsinhnhanvien().ToList();
            ////set the member of the chart data source used to data bind to the X-values of the series  
            //chartControl1.Series["Số NV"].XValueMember = "Thang";
            ////set the member columns of the chart data source used to data bind to the X-values of the series  
            //chartControl1.Series["Số NV"].YValueMembers = "SoNhanVien";

        }
    }
}