﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmPrint : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmPrint()
        {
            InitializeComponent();
        }

        public string _MaNV { get; set; }
        public int _IDPhieuDanhGia { get; set; }
        public void PrintPhieuDanhGia(string manv, int idPhieudanhgia)
        {
            // Lấy thông tin nhân viên
            string hoten = "";
            string teneng = "";
            string bophan = "";
            string chucvu = "";
            string gioitinh = "";
            DateTime ngaybatdau = DateTime.Now;

            var result = from c in ep.NhanViens
                         where c.MaNV == manv
                         //orderby c.BoPhan
                         select new
                         {
                             c.MaNV,
                             c.TenNV,
                             c.TenEng,
                             c.NgaySinh,
                             c.BoPhan.TenBoPhan,
                             c.ChucVu.TenChucVu,
                             GioiTinh = (c.GioiTinh != true) ? "Nữ" : "Nam",
                             TinhTrangHonNhan = (c.TinhTrangHonNhan != true) ? "Chưa kết hôn" : "Đã kết hôn",
                             c.GroupTeam.TenNhom,
                             c.QueQuan,
                             c.HinhAnh,
                             c.SoDT,
                             c.Email,
                             c.NgayBatDau,
                             c.GhiChu,
                             c.SoCMND,
                             c.SoTaiKhoan,
                             c.IDStatus,
                             c.Status.NameStatus,
                             c.VP,
                             c.TrinhDoHocVan.HocVan,
                             c.TrinhDoChuyenMon.ChuyenMon

                         };

            foreach (var item in result.ToList())
            {
                hoten = item.TenNV;
                teneng = item.TenEng;
                bophan = item.TenBoPhan;
                chucvu = item.TenChucVu;
                gioitinh = item.GioiTinh;
                ngaybatdau = Convert.ToDateTime(item.NgayBatDau);
            }

            // Lấy thông tin phiếu đánh giá
            double taptrung = 0;
            double viecrieng = 0;
            double ngaynghi = 0;
            double kienthuc = 0;
            double kynang = 0;
            double langnghe = 0;
            double giaotiep = 0;
            double canthan = 0;
            string laudai = "";
            string lanhdao = "";
            string note = "";
            var result1 = from c in ep.PhieuDanhGias
                          where c.ID == _IDPhieuDanhGia
                          select new
                          {
                              c.ID,
                              c.MaNV,
                              c.SuTapTrung,
                              c.NgayLapPhieu,
                              c.ViecRieng,
                              c.SoNgayNghi,
                              c.KienThuc,
                              c.KyNang,
                              c.LangNghe,
                              c.GiaoTiep,
                              c.CanThan,
                              LauDai = (c.LauDai != true) ? "Temporary " : "Permernant",
                              LanhDao = (c.LanhDao != true) ? "Just normal staffs" : "Can be a leader ",
                              c.Note
                          };

            foreach (var item in result1.ToList())
            {
                taptrung = Convert.ToDouble(item.SuTapTrung);
                viecrieng = Convert.ToDouble(item.ViecRieng);
                ngaynghi = Convert.ToDouble(item.SoNgayNghi);
                kienthuc = Convert.ToDouble(item.KienThuc);
                kynang = Convert.ToDouble(item.KyNang);
                langnghe = Convert.ToDouble(item.LangNghe);
                giaotiep = Convert.ToDouble(item.GiaoTiep);
                canthan = Convert.ToDouble(item.CanThan);
                laudai = item.LauDai;
                lanhdao = item.LanhDao;
                note = item.Note;
            }

            rptPhieuDanhGia rpt = new rptPhieuDanhGia();
            foreach (DevExpress.XtraReports.Parameters.Parameter p in rpt.Parameters)
                p.Visible = false;
            documentViewer1.DocumentSource = rpt;
            rpt.LoadData(hoten, teneng, bophan, chucvu, gioitinh, ngaybatdau, taptrung, viecrieng, ngaynghi, kienthuc, kynang, langnghe, giaotiep, canthan, laudai, lanhdao, note);
            rpt.CreateDocument();

        }

        private void frmPrint_Load(object sender, EventArgs e)
        {
            PrintPhieuDanhGia(_MaNV, 1);
        }
    }
}