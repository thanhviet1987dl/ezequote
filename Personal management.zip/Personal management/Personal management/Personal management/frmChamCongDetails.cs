﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmChamCongDetails : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        bool kiemtrathemmoingaynghi = false;
        bool kiemtrathemmoiditrevesom = false;
        bool kiemtrathemmoidayOT = false;
        string _maChiTietChamCong = "";
        //double ngaynghiold = 0;

        public frmChamCongDetails()
        {
            InitializeComponent();
            FormatGrid_NhanVien();
            btnXacNhanDayOff.Enabled = false;
            btnXacNhanLate.Enabled = false;
            btnXacNhanDayOT.Enabled = false;
            btnXacNhanTimeOT.Enabled = false;
            txtGhiChuDayOff.ReadOnly = true;
            txtGhiChuDayOT.ReadOnly = true;
            txtGhiChuLate.ReadOnly = true;
            txtGhiChuTimeOT.ReadOnly = true;
        }

        public int MaChamCong { get; set; }

        public string MaNhanVien { get; set; }

        public string TenNhanVien { get; set; }

        public double TongPhep { get; set; }

        public double PhepConLai { get; set; }

        public int _Islock { get; set; }

        void KiemTraDuLieuDaKhoaChua()
        {
            if (_Islock == 1)
            {
                btnThemMoiDayOff.Enabled = false;
                btnSuaDayOff.Enabled = false;
                btnThemMoiLate.Enabled = false;
                btnSuaLate.Enabled = false;
                btnThemMoiDayOT.Enabled = false;
                btnSuaDayOT.Enabled = false;
            }
        }
        void ShowThongTinLucLoadForm()
        {
            txtTenNV.Text = this.TenNhanVien;
            txtTongPhep.Text = this.TongPhep.ToString();
            txtPhepConLai.Text = this.PhepConLai.ToString();

        }

        private void FormatGrid_NhanVien()
        {
            gridView1.Columns.Clear();
            string[] fields = { "MaCCCT", "MaCC", "TenNV", "TuNgay", "DenNgay", "SoNgayNghi","Phep", "SoPhutDiMuon",
                "SoPhutVeSom", "SoNgayTangCa", "SoPhutTangCa", "GhiChu"};

            string[] captions = { "Mã CCCT","Mã Chấm Công", "Họ tên", "Từ ngày", "Đến ngày", "Số ngày nghỉ", "Phép","Đi muộn (Phút)",
                "Về sớm(Phút)", "Ngày OT", "Giờ OT", "Ghi chú"};

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;

            }
            gridView1.Columns["MaCCCT"].Visible = false;
            gridView1.Columns["MaCC"].Visible = false;
            gridView1.Columns["SoPhutTangCa"].Visible = false;
        }

        void XuLyNgayNghi()
        {
            if (rdHalfDayOff.Checked == true)
            {
                panelAllDayOff.Visible = false;
            }
            if (rdAllDayOff.Checked == true)
            {
                panelAllDayOff.Visible = true;
            }
            txtTongNgayNghi.Text = ((dtDenNgayDayOff.Value.Day - dtTuNgayDayOff.Value.Day) + 1).ToString();
        }

        void NapDuLieuLenGridControl()
        {

            var query = from c1 in ep.ChiTietChamCongs
                        join c2 in ep.ChamCongs on c1.MaCC equals c2.MaCC
                        join c3 in ep.NhanViens on c2.MaNV equals c3.MaNV
                        where c1.MaCC == MaChamCong
                        select new
                        {
                            c1.MaCCCT,
                            c1.MaCC,
                            c3.TenNV,
                            c1.TuNgay,
                            c1.DenNgay,
                            c1.SoNgayNghi,
                            c1.Phep,
                            c1.SoPhutDiMuon,
                            c1.SoPhutVeSom,
                            c1.SoNgayTangCa,
                            c1.SoPhutTangCa,
                            c1.GhiChu
                        };

            grcChiTiet.DataSource = query.ToList();
            gridView1.BestFitColumns();
            //Group by theo tên
            //gridView1.Columns["TenNV"].GroupIndex = 1;

        }

        void NapDuLieuLenCacControl()
        {

            _maChiTietChamCong = gridView1.GetFocusedRowCellDisplayText("MaCCCT").ToString();
            //ngaynghiold = Convert.ToDouble(gridView1.GetFocusedRowCellDisplayText("SoNgayNghi"));
            string _tuNgay = gridView1.GetFocusedRowCellDisplayText("TuNgay");
            string _denNgay = gridView1.GetFocusedRowCellDisplayText("DenNgay");
            if (_tuNgay != "")
                dtTuNgayDayOff.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("TuNgay"));
            if (_tuNgay != "")
                dtHalfDayOff.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("TuNgay"));

            if (_denNgay != "")
                dtDenNgayDayOff.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("DenNgay"));
            txtTongNgayNghi.Text = gridView1.GetFocusedRowCellDisplayText("SoNgayNghi").ToString();
            if (_tuNgay != "")
                dtNgayDiTreVeSom.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("TuNgay"));
            txtSoPhutDiMuon.Text = gridView1.GetFocusedRowCellDisplayText("SoPhutDiMuon").ToString();

            if (_tuNgay != "")
                dtTuNgayOT.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("TuNgay"));
            if (_denNgay != "")
                dtDenNgayOT.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("DenNgay"));
            if (_tuNgay != "")
                dtHaftDayOT.Value = Convert.ToDateTime(gridView1.GetFocusedRowCellDisplayText("TuNgay"));

            txtTongNgayOT.Text = gridView1.GetFocusedRowCellDisplayText("SoNgayTangCa").ToString();
            cboPhep.Text = gridView1.GetFocusedRowCellDisplayText("Phep").ToString();
            //txtGhiChuDayOff.Text= gridView1.GetFocusedRowCellDisplayText("GhiChu").ToString();
            //txtGhiChuDayOT.Text = gridView1.GetFocusedRowCellDisplayText("GhiChu").ToString();
            //txtGhiChuLate.Text = gridView1.GetFocusedRowCellDisplayText("GhiChu").ToString();
            //txtGhiChuTimeOT.Text = gridView1.GetFocusedRowCellDisplayText("GhiChu").ToString();


        }

        void ThemMoiThongTinNgayNghi()
        {
            if (rdAllDayOff.Checked == true)
            {
                ChiTietChamCong ctcc = new ChiTietChamCong()
                {
                    MaCCCT = Corelib.maTuTang("CTCC", Convert.ToInt32(ep.ChiTietChamCongs.Count().ToString())),
                    MaCC = MaChamCong,
                    TuNgay = dtTuNgayDayOff.Value.Date,
                    DenNgay = dtDenNgayDayOff.Value.Date,
                    SoNgayNghi = Convert.ToDouble(txtTongNgayNghi.Text),
                    GhiChu = txtGhiChuDayOff.Text,
                    Phep = cboPhep.SelectedItem.ToString()

                };
                ep.ChiTietChamCongs.Add(ctcc);
                ep.SaveChanges();
            }
            if (rdHalfDayOff.Checked == true)
            {
                ChiTietChamCong ctcc = new ChiTietChamCong()
                {
                    MaCCCT = Corelib.maTuTang("CTCC", Convert.ToInt32(ep.ChiTietChamCongs.Count().ToString())),
                    MaCC = MaChamCong,
                    TuNgay = dtHalfDayOff.Value.Date,
                    DenNgay = dtHalfDayOff.Value.Date,
                    SoNgayNghi = Convert.ToDouble(txtTongNgayNghi.Text),
                    GhiChu = txtGhiChuDayOff.Text,
                    Phep = cboPhep.SelectedItem.ToString()
                };
                ep.ChiTietChamCongs.Add(ctcc);
                ep.SaveChanges();
            }

        }

        void SuaThongTinNgayNghi()
        {
            if (rdAllDayOff.Checked == true)
            {
                ChiTietChamCong CTChamCong = ep.ChiTietChamCongs.Find(_maChiTietChamCong);
                //CTChamCong.MaCC = MaChamCong;
                CTChamCong.TuNgay = dtTuNgayDayOff.Value.Date;
                CTChamCong.DenNgay = dtDenNgayDayOff.Value.Date;
                CTChamCong.SoNgayNghi = Convert.ToDouble(txtTongNgayNghi.Text);
                CTChamCong.GhiChu = txtGhiChuDayOff.Text;
                CTChamCong.Phep = cboPhep.SelectedItem.ToString();
                ep.SaveChanges();
            }
            if (rdHalfDayOff.Checked == true)
            {
                ChiTietChamCong CTChamCong = ep.ChiTietChamCongs.Find(_maChiTietChamCong);
                //CTChamCong.MaCC = MaChamCong;
                CTChamCong.TuNgay = dtHalfDayOff.Value.Date;
                CTChamCong.DenNgay = dtHalfDayOff.Value.Date;
                CTChamCong.SoNgayNghi = Convert.ToDouble(txtTongNgayNghi.Text);
                CTChamCong.GhiChu = txtGhiChuDayOff.Text;
                CTChamCong.Phep = cboPhep.SelectedItem.ToString();
                ep.SaveChanges();
            }

        }

        void ThemMoiThongTinDiTreVeSom()
        {
            if (rdDiMuon.Checked == true)
            {
                ChiTietChamCong ctcc = new ChiTietChamCong()
                {
                    MaCCCT = Corelib.maTuTang("CTCC", Convert.ToInt32(ep.ChiTietChamCongs.Count().ToString())),
                    MaCC = MaChamCong,
                    TuNgay = dtNgayDiTreVeSom.Value.Date,
                    DenNgay = dtNgayDiTreVeSom.Value.Date,
                    SoPhutDiMuon = Convert.ToDouble(txtSoPhutDiMuon.Text),
                    GhiChu = txtGhiChuLate.Text
                };
                ep.ChiTietChamCongs.Add(ctcc);
                ep.SaveChanges();
            }

            if (rdVeSom.Checked == true)
            {
                ChiTietChamCong ctcc = new ChiTietChamCong()
                {
                    MaCCCT = Corelib.maTuTang("CTCC", Convert.ToInt32(ep.ChiTietChamCongs.Count().ToString())),
                    MaCC = MaChamCong,
                    TuNgay = dtNgayDiTreVeSom.Value.Date,
                    DenNgay = dtNgayDiTreVeSom.Value.Date,
                    SoPhutVeSom = Convert.ToDouble(txtSoPhutDiMuon.Text),
                    GhiChu = txtGhiChuLate.Text
                };
                ep.ChiTietChamCongs.Add(ctcc);
                ep.SaveChanges();
            }

        }

        void SuaThongTinDiTreVeSom()
        {
            if (rdDiMuon.Checked == true)
            {
                ChiTietChamCong CTChamCong = ep.ChiTietChamCongs.Find(_maChiTietChamCong);
                //CTChamCong.MaCC = MaChamCong;
                CTChamCong.TuNgay = dtNgayDiTreVeSom.Value.Date;
                CTChamCong.DenNgay = dtNgayDiTreVeSom.Value.Date;
                CTChamCong.SoNgayNghi = Convert.ToDouble(txtTongNgayNghi.Text);
                CTChamCong.GhiChu = txtGhiChuLate.Text;
                ep.SaveChanges();
            }
            if (rdVeSom.Checked == true)
            {
                ChiTietChamCong CTChamCong = ep.ChiTietChamCongs.Find(_maChiTietChamCong);
                //CTChamCong.MaCC = MaChamCong;
                CTChamCong.TuNgay = dtNgayDiTreVeSom.Value.Date;
                CTChamCong.DenNgay = dtNgayDiTreVeSom.Value.Date;
                CTChamCong.SoNgayNghi = Convert.ToDouble(txtTongNgayNghi.Text);
                CTChamCong.GhiChu = txtGhiChuLate.Text;
                ep.SaveChanges();
            }

        }

        void ThemMoiThongTinDayOT()
        {
            if (rdOTAllDay.Checked == true)
            {
                ChiTietChamCong ctcc = new ChiTietChamCong()
                {
                    MaCCCT = Corelib.maTuTang("CTCC", Convert.ToInt32(ep.ChiTietChamCongs.Count().ToString())),
                    MaCC = MaChamCong,
                    TuNgay = dtTuNgayOT.Value.Date,
                    DenNgay = dtDenNgayOT.Value.Date,
                    SoNgayTangCa = Convert.ToDouble(txtTongNgayOT.Text),
                    GhiChu = txtGhiChuDayOT.Text
                };
                ep.ChiTietChamCongs.Add(ctcc);
                ep.SaveChanges();
            }
            if (rdHalfDayOT.Checked == true)
            {
                ChiTietChamCong ctcc = new ChiTietChamCong()
                {
                    MaCCCT = Corelib.maTuTang("CTCC", Convert.ToInt32(ep.ChiTietChamCongs.Count().ToString())),
                    MaCC = MaChamCong,
                    TuNgay = dtHaftDayOT.Value.Date,
                    DenNgay = dtHaftDayOT.Value.Date,
                    SoNgayTangCa = Convert.ToDouble(txtTongNgayOT.Text),
                    GhiChu = txtGhiChuDayOT.Text
                };
                ep.ChiTietChamCongs.Add(ctcc);
                ep.SaveChanges();
            }

        }

        void SuaThongTinDayOT()
        {
            if (rdOTAllDay.Checked == true)
            {
                ChiTietChamCong CTChamCong = ep.ChiTietChamCongs.Find(_maChiTietChamCong);
                //CTChamCong.MaCC = MaChamCong;
                CTChamCong.TuNgay = dtTuNgayOT.Value.Date;
                CTChamCong.DenNgay = dtDenNgayOT.Value.Date;
                CTChamCong.SoNgayTangCa = Convert.ToDouble(txtTongNgayOT.Text);
                CTChamCong.GhiChu = txtGhiChuDayOT.Text;
                ep.SaveChanges();
            }
            if (rdHalfDayOT.Checked == true)
            {
                ChiTietChamCong CTChamCong = ep.ChiTietChamCongs.Find(_maChiTietChamCong);
                //CTChamCong.MaCC = MaChamCong;
                CTChamCong.TuNgay = dtHaftDayOT.Value.Date;
                CTChamCong.DenNgay = dtHaftDayOT.Value.Date;
                CTChamCong.SoNgayTangCa = Convert.ToDouble(txtTongNgayOT.Text);
                CTChamCong.GhiChu = txtGhiChuDayOT.Text;
                ep.SaveChanges();
            }

        }

        void CapNhatDuLieuNgayNghiVeBangGoc()
        {
            ChamCong cc = ep.ChamCongs.Find(MaChamCong);
            //cc.TongPhep = Convert.ToDouble(txtTongPhep.Text);

            var laytongsongaynghi = from c in ep.ChiTietChamCongs
                                    where c.MaCC == MaChamCong
                                    select new
                                    {
                                        c.SoNgayNghi
                                    };

            double Total = 0;
            if (laytongsongaynghi != null)
            {
                foreach (var item in laytongsongaynghi.ToList())
                {
                    Total += Convert.ToDouble(item.SoNgayNghi);
                }
            }

            //double ngaynghimoi = Convert.ToDouble(txtTongNgayNghi.Text);
            ////cc.PhepConLai = PhepConLai - Convert.ToDouble(txtTongNgayNghi.Text);
            //if (PhepConLai > 0 && ngaynghimoi >= ngaynghiold)
            //    cc.PhepConLai = PhepConLai - Convert.ToDouble(txtTongNgayNghi.Text);
            //else 
            //if(PhepConLai<0)
            //    cc.PhepConLai = PhepConLai + (ngaynghiold - ngaynghimoi);
            //if (ngaynghimoi < ngaynghiold)
            //    cc.PhepConLai = PhepConLai + (ngaynghiold - ngaynghimoi);
            cc.NgayNghi = Total;
            ep.SaveChanges();

        }

        void CapNhatDuLieuDiMuonVeBangGoc()
        {
            ChamCong cc = ep.ChamCongs.Find(MaChamCong);
            //cc.TongPhep = Convert.ToDouble(txtTongPhep.Text);

            var laytongsophutdimuon = from c in ep.ChiTietChamCongs
                                      where c.MaCC == MaChamCong
                                      select new
                                      {
                                          c.SoPhutDiMuon
                                      };

            double Total = 0;
            if (laytongsophutdimuon != null)
            {
                foreach (var item in laytongsophutdimuon.ToList())
                {
                    Total += Convert.ToDouble(item.SoPhutDiMuon);
                }
            }
            cc.DiTre = Convert.ToInt32(Total);
            ep.SaveChanges();
        }

        void CapNhatDuLieuVeSomVeBangGoc()
        {
            ChamCong cc = ep.ChamCongs.Find(MaChamCong);
            //cc.TongPhep = Convert.ToDouble(txtTongPhep.Text);

            var laytongsophutvesom = from c in ep.ChiTietChamCongs
                                     where c.MaCC == MaChamCong
                                     select new
                                     {
                                         c.SoPhutVeSom
                                     };

            double Total = 0;
            if (laytongsophutvesom != null)
            {
                foreach (var item in laytongsophutvesom.ToList())
                {
                    Total += Convert.ToDouble(item.SoPhutVeSom);
                }
            }
            cc.VeSom = Convert.ToInt32(Total);
            ep.SaveChanges();
        }

        void LayTongSoThongTinChamCong()
        {
            var laytongsongaynghi = from c in ep.ChiTietChamCongs
                                    where c.MaCC == MaChamCong
                                    select new
                                    {
                                        c.SoNgayNghi
                                    };

            double Totalngaynghi = 0;
            if (laytongsongaynghi != null)
            {
                foreach (var item in laytongsongaynghi.ToList())
                {
                    Totalngaynghi += Convert.ToDouble(item.SoNgayNghi);
                }
            }

            lblSoNgayNghi.Text = Totalngaynghi.ToString() + " (Ngày)";

            var laytongsodimuon = from c in ep.ChiTietChamCongs
                                  where c.MaCC == MaChamCong
                                  select new
                                  {
                                      c.SoPhutDiMuon
                                  };

            double Totaldimuon = 0;
            if (laytongsodimuon != null)
            {
                foreach (var item in laytongsodimuon.ToList())
                {
                    Totaldimuon += Convert.ToDouble(item.SoPhutDiMuon);
                }
            }

            var laytongsovesom = from c in ep.ChiTietChamCongs
                                 where c.MaCC == MaChamCong
                                 select new
                                 {
                                     c.SoPhutVeSom
                                 };

            double Totalvesom = 0;
            if (laytongsovesom != null)
            {
                foreach (var item in laytongsovesom.ToList())
                {
                    Totalvesom += Convert.ToDouble(item.SoPhutVeSom);
                }
            }

            lblDiTreVeSom.Text = (Totaldimuon + Totalvesom).ToString() + " (Phút)";

            var laytongsoOT = from c in ep.ChiTietChamCongs
                              where c.MaCC == MaChamCong
                              select new
                              {
                                  c.SoNgayTangCa
                              };

            double TotalOT = 0;
            if (laytongsoOT != null)
            {
                foreach (var item in laytongsoOT.ToList())
                {
                    TotalOT += Convert.ToDouble(item.SoNgayTangCa);
                }
            }

            lblOT.Text = TotalOT.ToString() + " (Ngày)";

        }

        private void frmChamCongDetails_Load(object sender, EventArgs e)
        {
            ShowThongTinLucLoadForm();
            XuLyNgayNghi();
            NapDuLieuLenGridControl();
            panelHalfDayOff.Visible = false;
            panelHalfDayOT.Visible = false;
            tabControl1.TabPages.Remove(tabPage4);
            LayTongSoThongTinChamCong();
            KiemTraDuLieuDaKhoaChua();
        }

        private void rdAllDayOff_CheckedChanged(object sender, EventArgs e)
        {
            panelAllDayOff.Visible = true;
            panelHalfDayOff.Visible = false;
            if (rdAllDayOff.Checked == true)
                txtTongNgayNghi.Text = ((dtDenNgayDayOff.Value.Day - dtTuNgayDayOff.Value.Day) + 1).ToString();
        }

        private void rdHalfDayOff_CheckedChanged(object sender, EventArgs e)
        {
            panelAllDayOff.Visible = false;
            panelHalfDayOff.Visible = true;
            if (rdHalfDayOff.Checked == true)
                txtTongNgayNghi.Text = "0.5";
        }

        private void dtTuNgayDayOff_ValueChanged(object sender, EventArgs e)
        {
            if (rdAllDayOff.Checked == true)
                txtTongNgayNghi.Text = ((dtDenNgayDayOff.Value.Day - dtTuNgayDayOff.Value.Day) + 1).ToString();
        }

        private void dtDenNgayDayOff_ValueChanged(object sender, EventArgs e)
        {
            if (rdAllDayOff.Checked == true)
                txtTongNgayNghi.Text = ((dtDenNgayDayOff.Value.Day - dtTuNgayDayOff.Value.Day) + 1).ToString();
        }

        private void btnThemMoiDayOff_Click(object sender, EventArgs e)
        {
            kiemtrathemmoingaynghi = true;
            btnXacNhanDayOff.Enabled = true;
            btnSuaDayOff.Enabled = false;
            btnThemMoiDayOff.Enabled = false;
            txtGhiChuDayOff.ReadOnly = false;
        }

        private void btnSuaDayOff_Click(object sender, EventArgs e)
        {
            kiemtrathemmoingaynghi = false;
            btnXacNhanDayOff.Enabled = true;
            btnThemMoiDayOff.Enabled = false;
            btnSuaDayOff.Enabled = false;
            txtGhiChuDayOff.ReadOnly = false;
        }

        private void btnXacNhanDayOff_Click(object sender, EventArgs e)
        {
            if (kiemtrathemmoingaynghi == true)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn lưu thông tin này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ThemMoiThongTinNgayNghi();
                NapDuLieuLenGridControl();
                btnXacNhanDayOff.Enabled = false;
                btnThemMoiDayOff.Enabled = true;
                btnSuaDayOff.Enabled = true;
                txtGhiChuDayOff.ReadOnly = true;
                CapNhatDuLieuNgayNghiVeBangGoc();
            }

            if (kiemtrathemmoingaynghi == false)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn lưu thông tin này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    SuaThongTinNgayNghi();
                NapDuLieuLenGridControl();
                btnXacNhanDayOff.Enabled = false;
                btnThemMoiDayOff.Enabled = true;
                btnSuaDayOff.Enabled = true;
                txtGhiChuDayOff.ReadOnly = true;
                CapNhatDuLieuNgayNghiVeBangGoc();
            }
            LayTongSoThongTinChamCong();
        }

        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            NapDuLieuLenCacControl();
        }

        private void btnThemMoiLate_Click(object sender, EventArgs e)
        {
            kiemtrathemmoiditrevesom = true;
            btnXacNhanLate.Enabled = true;
            btnThemMoiLate.Enabled = false;
            btnSuaLate.Enabled = false;
            txtGhiChuLate.ReadOnly = false;
        }

        private void btnSuaLate_Click(object sender, EventArgs e)
        {
            kiemtrathemmoiditrevesom = false;
            btnXacNhanLate.Enabled = true;
            btnThemMoiLate.Enabled = false;
            btnSuaLate.Enabled = false;
            txtGhiChuLate.ReadOnly = false;
        }

        private void btnXacNhanLate_Click(object sender, EventArgs e)
        {
            if (kiemtrathemmoiditrevesom == true)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn lưu thông tin này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ThemMoiThongTinDiTreVeSom();
                NapDuLieuLenGridControl();
                btnXacNhanLate.Enabled = false;
                btnThemMoiLate.Enabled = true;
                btnSuaLate.Enabled = true;
                txtGhiChuLate.ReadOnly = true;
                if (rdDiMuon.Checked == true)
                    CapNhatDuLieuDiMuonVeBangGoc();
                if (rdVeSom.Checked == true)
                    CapNhatDuLieuVeSomVeBangGoc();
            }

            if (kiemtrathemmoiditrevesom == false)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn lưu thông tin này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    SuaThongTinDiTreVeSom();
                NapDuLieuLenGridControl();
                btnXacNhanLate.Enabled = false;
                btnThemMoiLate.Enabled = true;
                btnSuaLate.Enabled = true;
                txtGhiChuLate.ReadOnly = true;
                if (rdDiMuon.Checked == true)
                    CapNhatDuLieuDiMuonVeBangGoc();
                if (rdVeSom.Checked == true)
                    CapNhatDuLieuVeSomVeBangGoc();
            }
            LayTongSoThongTinChamCong();

        }

        private void rdOTAllDay_CheckedChanged(object sender, EventArgs e)
        {
            panelDayOT.Visible = true;
            panelHalfDayOT.Visible = false;
            if (rdAllDayOff.Checked == true)
                txtTongNgayOT.Text = ((dtDenNgayDayOff.Value.Day - dtTuNgayDayOff.Value.Day) + 1).ToString();
        }

        private void rdHalfDayOT_CheckedChanged(object sender, EventArgs e)
        {
            panelDayOT.Visible = false;
            panelHalfDayOT.Visible = true;
            if (rdHalfDayOT.Checked == true)
                txtTongNgayOT.Text = "0.5";
        }

        private void btnThemMoiDayOT_Click(object sender, EventArgs e)
        {
            kiemtrathemmoidayOT = true;
            btnXacNhanDayOT.Enabled = true;
            btnThemMoiDayOT.Enabled = false;
            btnSuaDayOT.Enabled = false;
            txtGhiChuDayOT.ReadOnly = false;
        }

        private void btnSuaDayOT_Click(object sender, EventArgs e)
        {
            kiemtrathemmoidayOT = false;
            btnXacNhanDayOT.Enabled = true;
            btnThemMoiDayOT.Enabled = false;
            btnSuaDayOT.Enabled = false;
            txtGhiChuDayOT.ReadOnly = false;
        }

        private void btnXacNhanDayOT_Click(object sender, EventArgs e)
        {
            if (kiemtrathemmoidayOT == true)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn lưu thông tin này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ThemMoiThongTinDayOT();
                NapDuLieuLenGridControl();
                btnXacNhanDayOT.Enabled = false;
                btnThemMoiDayOT.Enabled = true;
                btnSuaDayOT.Enabled = true;
                txtGhiChuDayOT.ReadOnly = true;
            }

            if (kiemtrathemmoidayOT == false)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn lưu thông tin này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    SuaThongTinDayOT();
                NapDuLieuLenGridControl();
                btnXacNhanDayOT.Enabled = false;
                btnThemMoiDayOT.Enabled = true;
                btnSuaDayOT.Enabled = true;
                txtGhiChuDayOT.ReadOnly = true;
            }
            LayTongSoThongTinChamCong();
        }

        private void dtTuNgayOT_ValueChanged(object sender, EventArgs e)
        {
            if (rdOTAllDay.Checked == true)
                txtTongNgayOT.Text = ((dtDenNgayOT.Value.Day - dtTuNgayOT.Value.Day) + 1).ToString();
        }

        private void dtDenNgayOT_ValueChanged(object sender, EventArgs e)
        {
            if (rdOTAllDay.Checked == true)
                txtTongNgayOT.Text = ((dtDenNgayOT.Value.Day - dtTuNgayOT.Value.Day) + 1).ToString();
        }

        private void frmChamCongDetails_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
    }

}