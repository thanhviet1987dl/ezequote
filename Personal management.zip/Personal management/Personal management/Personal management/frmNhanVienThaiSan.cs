﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmNhanVienThaiSan : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmNhanVienThaiSan()
        {
            InitializeComponent();
        }

        public string MaNhanVien { get; set; }
        public string TenNhanVien { get; set; }

        private void frmNhanVienThaiSan_Load(object sender, EventArgs e)
        {
            lblTen.Text = TenNhanVien;
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            if (XtraMessageBox.Show("Đây là thông tin không thể sửa đổi sau khi lưu. Vui lòng lòng kiểm tra kỹ trước khi thực hiện", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Thêm nhân viên này vào danh sách nhân viên thai sản
                NhanVienThaiSan nvthaisan = new NhanVienThaiSan()
                {
                    MaNV = MaNhanVien,
                    TuNgay = dtTuNgay.Value,
                    DenNgay = dtDenNgay.Value,
                    Note = txtNote.Text
                    
                };
                ep.NhanVienThaiSans.Add(nvthaisan);
                ep.SaveChanges();

                // Update IDStatus=4 : đang thai sản
                NhanVien nv = ep.NhanViens.Find(MaNhanVien);
                nv.IDStatus = 4;
                ep.SaveChanges();

            }
        }
    }
}