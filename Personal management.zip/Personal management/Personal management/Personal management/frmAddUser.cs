﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmAddUser : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public frmAddUser()
        {
            InitializeComponent();
            FormatGrid_NhanVien();
            NapDanhSachNhanVien();
        }

        void NapDanhSachNhanVien()
        {
            var result = from c in ep.NhanViens
                         where c.IsDelete == false && c.IDStatus != 6
                         //orderby c.BoPhan
                         select new
                         {
                             c.MaNV,
                             c.TenNV,
                             c.TenEng,

                         };
            cboNhanVien.Properties.DataSource = result.ToList();
            cboNhanVien.Properties.ValueMember = "MaNV";
            cboNhanVien.Properties.DisplayMember = "TenNV";
        }

        private void FormatGrid_NhanVien()
        {
            searchLookUpEdit1View.Columns.Clear();
            string[] fields = { "MaNV", "TenNV", "TenEng" };

            string[] captions = { "Mã NV", "Họ tên", "Tên Eng" };

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                searchLookUpEdit1View.Columns.Add(col);
                searchLookUpEdit1View.Columns[i].Visible = true;
                searchLookUpEdit1View.Columns[i].OptionsColumn.AllowEdit = false;
            }


            searchLookUpEdit1View.Columns["MaNV"].Visible = false;
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            if(KiemTraUserID()==true)
            {
                Account acc = new Account()
                {
                    MaNV = cboNhanVien.EditValue.ToString(),
                    UserID = txtUser.Text,
                    Password = Corelib.MaHoaPass(txtPass.Text),
                    IsManagement = 0
                };
                ep.Accounts.Add(acc);
                if (ep.SaveChanges() > 0)
                    XtraMessageBox.Show("Tạo user mới thành công", "Thông Báo");
            }           
        }

        bool KiemTraUserID()
        {
            string _tenEng = string.Empty;
            var result = from c in ep.Accounts
                         where c.MaNV == cboNhanVien.EditValue.ToString()
                         //orderby c.BoPhan
                         select new
                         {
                             c.UserID
                         };

            if (result.ToList().Count > 0)
            {
                XtraMessageBox.Show("UserID này đã tồn tại. Vui lòng chọn UserID khác.", "Thông Báo");
                return false;
            }
            else
                return true;
                
        }
        private void cboNhanVien_EditValueChanged(object sender, EventArgs e)
        {
            string _tenEng = string.Empty;
            var result = from c in ep.NhanViens
                         where c.MaNV == cboNhanVien.EditValue.ToString()
                         //orderby c.BoPhan
                         select new
                         {
                             c.TenNV,
                             c.TenEng,
                         };

            foreach (var item in result.ToList())
            {
                _tenEng = item.TenEng;
            }
            txtUser.Text = _tenEng;
        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {
            txtPass.Text = "123456";
        }
    }
}