﻿namespace Personal_management
{
    partial class UC_Personal
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraSplashScreen.SplashScreenManager splashScreenManager1 = new DevExpress.XtraSplashScreen.SplashScreenManager(this, null, true, true, typeof(System.Windows.Forms.UserControl));
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Personal));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.imgPersonals = new DevExpress.XtraEditors.PictureEdit();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.grcNhanVien = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nhânViênTraineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhânViênChínhThứcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.nhânViênThaiSảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kếtthúcthaisảntoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.nhânViênĐãThôiViệcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đãNộpĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rútĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đãHoànThànhNghĩaVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TraineethôiviệctoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cậpNhậtSangBảngLươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.PhieuDanhGiaStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.OpenFileDia = new System.Windows.Forms.OpenFileDialog();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.cboOffice = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtNgayBatDau = new System.Windows.Forms.DateTimePicker();
            this.dtngaysinh = new System.Windows.Forms.DateTimePicker();
            this.cbogroupteam = new System.Windows.Forms.ComboBox();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtSoTK = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtSoCMND = new DevExpress.XtraEditors.TextEdit();
            this.cboChucVu = new System.Windows.Forms.ComboBox();
            this.cboChuyenMon = new System.Windows.Forms.ComboBox();
            this.cboHocVan = new System.Windows.Forms.ComboBox();
            this.cboBoPhan = new System.Windows.Forms.ComboBox();
            this.chbGioiTinh = new DevExpress.XtraEditors.CheckEdit();
            this.btnXoa = new DevExpress.XtraEditors.SimpleButton();
            this.btnXacNhan = new DevExpress.XtraEditors.SimpleButton();
            this.btnSua = new DevExpress.XtraEditors.SimpleButton();
            this.btnAdd = new DevExpress.XtraEditors.SimpleButton();
            this.txtGhiChu = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.chbTinhTrangHonNhan = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtEngTen = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtTen = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtEmail = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.txtSoDT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtMa = new DevExpress.XtraEditors.TextEdit();
            this.lvlMa = new DevExpress.XtraEditors.LabelControl();
            this.txtQueQuan = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgPersonals.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grcNhanVien)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoTK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoCMND.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chbGioiTinh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chbTinhTrangHonNhan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEngTen.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTen.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmail.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoDT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQueQuan.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // splashScreenManager1
            // 
            splashScreenManager1.ClosingDelay = 500;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.imgPersonals);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl1.Location = new System.Drawing.Point(0, 488);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(345, 274);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Image";
            // 
            // imgPersonals
            // 
            this.imgPersonals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.imgPersonals.EditValue = global::Personal_management.Properties.Resources.noimage;
            this.imgPersonals.EnterMoveNextControl = true;
            this.imgPersonals.Location = new System.Drawing.Point(2, 20);
            this.imgPersonals.Name = "imgPersonals";
            this.imgPersonals.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.imgPersonals.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Squeeze;
            this.imgPersonals.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.imgPersonals.Size = new System.Drawing.Size(341, 252);
            this.imgPersonals.TabIndex = 22;
            this.imgPersonals.TabStop = true;
            this.imgPersonals.DoubleClick += new System.EventHandler(this.imgPersonals_DoubleClick);
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.grcNhanVien);
            this.groupControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl3.Location = new System.Drawing.Point(354, 3);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(688, 762);
            this.groupControl3.TabIndex = 2;
            this.groupControl3.Text = "Staff list";
            // 
            // grcNhanVien
            // 
            this.grcNhanVien.AllowRestoreSelectionAndFocusedRow = DevExpress.Utils.DefaultBoolean.False;
            this.grcNhanVien.ContextMenuStrip = this.contextMenuStrip1;
            this.grcNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grcNhanVien.Location = new System.Drawing.Point(2, 20);
            this.grcNhanVien.MainView = this.gridView1;
            this.grcNhanVien.Name = "grcNhanVien";
            this.grcNhanVien.Size = new System.Drawing.Size(684, 740);
            this.grcNhanVien.TabIndex = 0;
            this.grcNhanVien.UseEmbeddedNavigator = true;
            this.grcNhanVien.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nhânViênTraineToolStripMenuItem,
            this.nhânViênChínhThứcToolStripMenuItem,
            this.toolStripSeparator2,
            this.nhânViênThaiSảnToolStripMenuItem,
            this.kếtthúcthaisảntoolStripMenuItem1,
            this.toolStripSeparator3,
            this.nhânViênĐãThôiViệcToolStripMenuItem,
            this.toolStripSeparator4,
            this.cậpNhậtSangBảngLươngToolStripMenuItem,
            this.toolStripSeparator5,
            this.PhieuDanhGiaStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(244, 204);
            // 
            // nhânViênTraineToolStripMenuItem
            // 
            this.nhânViênTraineToolStripMenuItem.Image = global::Personal_management.Properties.Resources.education;
            this.nhânViênTraineToolStripMenuItem.Name = "nhânViênTraineToolStripMenuItem";
            this.nhânViênTraineToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.nhânViênTraineToolStripMenuItem.Text = "Nhân viên Trainee";
            this.nhânViênTraineToolStripMenuItem.Click += new System.EventHandler(this.nhânViênTraineToolStripMenuItem_Click);
            // 
            // nhânViênChínhThứcToolStripMenuItem
            // 
            this.nhânViênChínhThứcToolStripMenuItem.Image = global::Personal_management.Properties.Resources.contract;
            this.nhânViênChínhThứcToolStripMenuItem.Name = "nhânViênChínhThứcToolStripMenuItem";
            this.nhânViênChínhThứcToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.nhânViênChínhThứcToolStripMenuItem.Text = "Ký hợp đồng";
            this.nhânViênChínhThứcToolStripMenuItem.Click += new System.EventHandler(this.nhânViênChínhThứcToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(240, 6);
            // 
            // nhânViênThaiSảnToolStripMenuItem
            // 
            this.nhânViênThaiSảnToolStripMenuItem.Image = global::Personal_management.Properties.Resources.woman;
            this.nhânViênThaiSảnToolStripMenuItem.Name = "nhânViênThaiSảnToolStripMenuItem";
            this.nhânViênThaiSảnToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.nhânViênThaiSảnToolStripMenuItem.Text = "Nhân viên thai sản";
            this.nhânViênThaiSảnToolStripMenuItem.Click += new System.EventHandler(this.nhânViênThaiSảnToolStripMenuItem_Click);
            // 
            // kếtthúcthaisảntoolStripMenuItem1
            // 
            this.kếtthúcthaisảntoolStripMenuItem1.Image = global::Personal_management.Properties.Resources.ok;
            this.kếtthúcthaisảntoolStripMenuItem1.Name = "kếtthúcthaisảntoolStripMenuItem1";
            this.kếtthúcthaisảntoolStripMenuItem1.Size = new System.Drawing.Size(243, 22);
            this.kếtthúcthaisảntoolStripMenuItem1.Text = "Kết thúc thai sản";
            this.kếtthúcthaisảntoolStripMenuItem1.Click += new System.EventHandler(this.kếtthúcthaisảntoolStripMenuItem1_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(240, 6);
            // 
            // nhânViênĐãThôiViệcToolStripMenuItem
            // 
            this.nhânViênĐãThôiViệcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đãNộpĐơnToolStripMenuItem,
            this.rútĐơnToolStripMenuItem,
            this.đãHoànThànhNghĩaVụToolStripMenuItem,
            this.toolStripSeparator1,
            this.TraineethôiviệctoolStripMenuItem1});
            this.nhânViênĐãThôiViệcToolStripMenuItem.Image = global::Personal_management.Properties.Resources.box16;
            this.nhânViênĐãThôiViệcToolStripMenuItem.Name = "nhânViênĐãThôiViệcToolStripMenuItem";
            this.nhânViênĐãThôiViệcToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.nhânViênĐãThôiViệcToolStripMenuItem.Text = "Xin thôi việc";
            // 
            // đãNộpĐơnToolStripMenuItem
            // 
            this.đãNộpĐơnToolStripMenuItem.Image = global::Personal_management.Properties.Resources.don_thoi_viec;
            this.đãNộpĐơnToolStripMenuItem.Name = "đãNộpĐơnToolStripMenuItem";
            this.đãNộpĐơnToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.đãNộpĐơnToolStripMenuItem.Text = "Nộp đơn";
            this.đãNộpĐơnToolStripMenuItem.Click += new System.EventHandler(this.đãNộpĐơnToolStripMenuItem_Click);
            // 
            // rútĐơnToolStripMenuItem
            // 
            this.rútĐơnToolStripMenuItem.Image = global::Personal_management.Properties.Resources.huydon;
            this.rútĐơnToolStripMenuItem.Name = "rútĐơnToolStripMenuItem";
            this.rútĐơnToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.rútĐơnToolStripMenuItem.Text = "Hủy đơn";
            this.rútĐơnToolStripMenuItem.Click += new System.EventHandler(this.rútĐơnToolStripMenuItem_Click);
            // 
            // đãHoànThànhNghĩaVụToolStripMenuItem
            // 
            this.đãHoànThànhNghĩaVụToolStripMenuItem.Image = global::Personal_management.Properties.Resources.xac_nhan;
            this.đãHoànThànhNghĩaVụToolStripMenuItem.Name = "đãHoànThànhNghĩaVụToolStripMenuItem";
            this.đãHoànThànhNghĩaVụToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.đãHoànThànhNghĩaVụToolStripMenuItem.Text = "Đã hoàn thành nghĩa vụ";
            this.đãHoànThànhNghĩaVụToolStripMenuItem.Click += new System.EventHandler(this.đãHoànThànhNghĩaVụToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(198, 6);
            // 
            // TraineethôiviệctoolStripMenuItem1
            // 
            this.TraineethôiviệctoolStripMenuItem1.Image = global::Personal_management.Properties.Resources.remove_user;
            this.TraineethôiviệctoolStripMenuItem1.Name = "TraineethôiviệctoolStripMenuItem1";
            this.TraineethôiviệctoolStripMenuItem1.Size = new System.Drawing.Size(201, 22);
            this.TraineethôiviệctoolStripMenuItem1.Text = "Trainee thôi việc";
            this.TraineethôiviệctoolStripMenuItem1.Click += new System.EventHandler(this.TraineethôiviệctoolStripMenuItem1_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(240, 6);
            // 
            // cậpNhậtSangBảngLươngToolStripMenuItem
            // 
            this.cậpNhậtSangBảngLươngToolStripMenuItem.Image = global::Personal_management.Properties.Resources.move;
            this.cậpNhậtSangBảngLươngToolStripMenuItem.Name = "cậpNhậtSangBảngLươngToolStripMenuItem";
            this.cậpNhậtSangBảngLươngToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.cậpNhậtSangBảngLươngToolStripMenuItem.Text = "Cập nhật sang bảng chấm công";
            this.cậpNhậtSangBảngLươngToolStripMenuItem.Click += new System.EventHandler(this.cậpNhậtSangBảngLươngToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(240, 6);
            // 
            // PhieuDanhGiaStripMenuItem1
            // 
            this.PhieuDanhGiaStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.viewsToolStripMenuItem});
            this.PhieuDanhGiaStripMenuItem1.Image = global::Personal_management.Properties.Resources.evaluation16;
            this.PhieuDanhGiaStripMenuItem1.Name = "PhieuDanhGiaStripMenuItem1";
            this.PhieuDanhGiaStripMenuItem1.Size = new System.Drawing.Size(243, 22);
            this.PhieuDanhGiaStripMenuItem1.Text = "Phiếu đánh giá";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = global::Personal_management.Properties.Resources.add;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // viewsToolStripMenuItem
            // 
            this.viewsToolStripMenuItem.Image = global::Personal_management.Properties.Resources.view;
            this.viewsToolStripMenuItem.Name = "viewsToolStripMenuItem";
            this.viewsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.viewsToolStripMenuItem.Text = "Views ";
            this.viewsToolStripMenuItem.Click += new System.EventHandler(this.viewsToolStripMenuItem_Click);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridView1.GridControl = this.grcNhanVien;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsFind.SearchInPreview = true;
            this.gridView1.OptionsFind.ShowClearButton = false;
            this.gridView1.OptionsFind.ShowFindButton = false;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ColumnAutoWidth = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.CustomDrawRowIndicator += new DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventHandler(this.gridView1_CustomDrawRowIndicator);
            this.gridView1.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridView1_RowStyle);
            this.gridView1.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridView1_FocusedRowChanged);
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "gridColumn1";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // OpenFileDia
            // 
            this.OpenFileDia.FileName = "Chọn ảnh đại diện";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 351F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.groupControl3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1045, 768);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupControl1);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(345, 762);
            this.panel3.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupControl2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(345, 488);
            this.panel1.TabIndex = 3;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.labelControl9);
            this.groupControl2.Controls.Add(this.cboOffice);
            this.groupControl2.Controls.Add(this.label4);
            this.groupControl2.Controls.Add(this.label3);
            this.groupControl2.Controls.Add(this.label2);
            this.groupControl2.Controls.Add(this.label1);
            this.groupControl2.Controls.Add(this.dtNgayBatDau);
            this.groupControl2.Controls.Add(this.dtngaysinh);
            this.groupControl2.Controls.Add(this.cbogroupteam);
            this.groupControl2.Controls.Add(this.labelControl14);
            this.groupControl2.Controls.Add(this.labelControl13);
            this.groupControl2.Controls.Add(this.txtSoTK);
            this.groupControl2.Controls.Add(this.labelControl12);
            this.groupControl2.Controls.Add(this.txtSoCMND);
            this.groupControl2.Controls.Add(this.cboChucVu);
            this.groupControl2.Controls.Add(this.cboChuyenMon);
            this.groupControl2.Controls.Add(this.cboHocVan);
            this.groupControl2.Controls.Add(this.cboBoPhan);
            this.groupControl2.Controls.Add(this.chbGioiTinh);
            this.groupControl2.Controls.Add(this.btnXoa);
            this.groupControl2.Controls.Add(this.btnXacNhan);
            this.groupControl2.Controls.Add(this.btnSua);
            this.groupControl2.Controls.Add(this.btnAdd);
            this.groupControl2.Controls.Add(this.txtGhiChu);
            this.groupControl2.Controls.Add(this.labelControl16);
            this.groupControl2.Controls.Add(this.labelControl11);
            this.groupControl2.Controls.Add(this.labelControl15);
            this.groupControl2.Controls.Add(this.labelControl8);
            this.groupControl2.Controls.Add(this.labelControl10);
            this.groupControl2.Controls.Add(this.chbTinhTrangHonNhan);
            this.groupControl2.Controls.Add(this.labelControl3);
            this.groupControl2.Controls.Add(this.txtEngTen);
            this.groupControl2.Controls.Add(this.labelControl4);
            this.groupControl2.Controls.Add(this.labelControl2);
            this.groupControl2.Controls.Add(this.txtTen);
            this.groupControl2.Controls.Add(this.labelControl1);
            this.groupControl2.Controls.Add(this.labelControl7);
            this.groupControl2.Controls.Add(this.txtEmail);
            this.groupControl2.Controls.Add(this.labelControl6);
            this.groupControl2.Controls.Add(this.txtSoDT);
            this.groupControl2.Controls.Add(this.labelControl5);
            this.groupControl2.Controls.Add(this.txtMa);
            this.groupControl2.Controls.Add(this.lvlMa);
            this.groupControl2.Controls.Add(this.txtQueQuan);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl2.Location = new System.Drawing.Point(0, 0);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(345, 488);
            this.groupControl2.TabIndex = 1;
            this.groupControl2.Text = "Staff info";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(192, 288);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(33, 13);
            this.labelControl9.TabIndex = 30;
            this.labelControl9.Text = "Office:";
            // 
            // cboOffice
            // 
            this.cboOffice.FormattingEnabled = true;
            this.cboOffice.Items.AddRange(new object[] {
            "Office 1",
            "Office 2"});
            this.cboOffice.Location = new System.Drawing.Point(228, 285);
            this.cboOffice.Name = "cboOffice";
            this.cboOffice.Size = new System.Drawing.Size(94, 21);
            this.cboOffice.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(323, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "(*)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(323, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "(*)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(323, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "(*)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(323, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "(*)";
            // 
            // dtNgayBatDau
            // 
            this.dtNgayBatDau.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayBatDau.Location = new System.Drawing.Point(82, 384);
            this.dtNgayBatDau.Name = "dtNgayBatDau";
            this.dtNgayBatDau.Size = new System.Drawing.Size(240, 21);
            this.dtNgayBatDau.TabIndex = 18;
            // 
            // dtngaysinh
            // 
            this.dtngaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtngaysinh.Location = new System.Drawing.Point(82, 99);
            this.dtngaysinh.Name = "dtngaysinh";
            this.dtngaysinh.Size = new System.Drawing.Size(240, 21);
            this.dtngaysinh.TabIndex = 4;
            // 
            // cbogroupteam
            // 
            this.cbogroupteam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbogroupteam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbogroupteam.FormattingEnabled = true;
            this.cbogroupteam.Location = new System.Drawing.Point(228, 258);
            this.cbogroupteam.Name = "cbogroupteam";
            this.cbogroupteam.Size = new System.Drawing.Size(94, 21);
            this.cbogroupteam.TabIndex = 12;
            this.cbogroupteam.DropDown += new System.EventHandler(this.cbogroupteam_DropDown);
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(192, 261);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(30, 13);
            this.labelControl14.TabIndex = 26;
            this.labelControl14.Text = "Team:";
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(8, 155);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(66, 13);
            this.labelControl13.TabIndex = 25;
            this.labelControl13.Text = "Bank number:";
            // 
            // txtSoTK
            // 
            this.txtSoTK.EnterMoveNextControl = true;
            this.txtSoTK.Location = new System.Drawing.Point(82, 152);
            this.txtSoTK.Name = "txtSoTK";
            this.txtSoTK.Size = new System.Drawing.Size(240, 20);
            this.txtSoTK.TabIndex = 6;
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(10, 129);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(41, 13);
            this.labelControl12.TabIndex = 23;
            this.labelControl12.Text = "ID code:";
            // 
            // txtSoCMND
            // 
            this.txtSoCMND.EnterMoveNextControl = true;
            this.txtSoCMND.Location = new System.Drawing.Point(82, 126);
            this.txtSoCMND.Name = "txtSoCMND";
            this.txtSoCMND.Size = new System.Drawing.Size(240, 20);
            this.txtSoCMND.TabIndex = 5;
            // 
            // cboChucVu
            // 
            this.cboChucVu.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboChucVu.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboChucVu.FormattingEnabled = true;
            this.cboChucVu.Location = new System.Drawing.Point(82, 285);
            this.cboChucVu.Name = "cboChucVu";
            this.cboChucVu.Size = new System.Drawing.Size(104, 21);
            this.cboChucVu.TabIndex = 13;
            this.cboChucVu.DropDown += new System.EventHandler(this.cboChucVu_DropDown);
            // 
            // cboChuyenMon
            // 
            this.cboChuyenMon.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboChuyenMon.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboChuyenMon.FormattingEnabled = true;
            this.cboChuyenMon.Location = new System.Drawing.Point(82, 230);
            this.cboChuyenMon.Name = "cboChuyenMon";
            this.cboChuyenMon.Size = new System.Drawing.Size(240, 21);
            this.cboChuyenMon.TabIndex = 10;
            this.cboChuyenMon.DropDown += new System.EventHandler(this.cboChuyenMon_DropDown);
            // 
            // cboHocVan
            // 
            this.cboHocVan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboHocVan.FormattingEnabled = true;
            this.cboHocVan.Location = new System.Drawing.Point(82, 203);
            this.cboHocVan.Name = "cboHocVan";
            this.cboHocVan.Size = new System.Drawing.Size(240, 21);
            this.cboHocVan.TabIndex = 9;
            this.cboHocVan.DropDown += new System.EventHandler(this.cboHocVan_DropDown);
            // 
            // cboBoPhan
            // 
            this.cboBoPhan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboBoPhan.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboBoPhan.FormattingEnabled = true;
            this.cboBoPhan.Location = new System.Drawing.Point(82, 258);
            this.cboBoPhan.Name = "cboBoPhan";
            this.cboBoPhan.Size = new System.Drawing.Size(104, 21);
            this.cboBoPhan.TabIndex = 11;
            this.cboBoPhan.DropDown += new System.EventHandler(this.cboBoPhan_DropDown);
            // 
            // chbGioiTinh
            // 
            this.chbGioiTinh.EnterMoveNextControl = true;
            this.chbGioiTinh.Location = new System.Drawing.Point(82, 178);
            this.chbGioiTinh.Name = "chbGioiTinh";
            this.chbGioiTinh.Properties.Caption = "Nam/Nữ";
            this.chbGioiTinh.Size = new System.Drawing.Size(77, 19);
            this.chbGioiTinh.TabIndex = 7;
            // 
            // btnXoa
            // 
            this.btnXoa.Image = ((System.Drawing.Image)(resources.GetObject("btnXoa.Image")));
            this.btnXoa.Location = new System.Drawing.Point(270, 462);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(52, 23);
            this.btnXoa.TabIndex = 23;
            this.btnXoa.Text = "Del";
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhan.Image")));
            this.btnXacNhan.Location = new System.Drawing.Point(212, 462);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(52, 23);
            this.btnXacNhan.TabIndex = 22;
            this.btnXacNhan.Text = "Save";
            this.btnXacNhan.Click += new System.EventHandler(this.btnXacNhan_Click);
            // 
            // btnSua
            // 
            this.btnSua.Image = ((System.Drawing.Image)(resources.GetObject("btnSua.Image")));
            this.btnSua.Location = new System.Drawing.Point(154, 462);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(52, 23);
            this.btnSua.TabIndex = 21;
            this.btnSua.Text = "Edit";
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(96, 462);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(52, 23);
            this.btnAdd.TabIndex = 20;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.EnterMoveNextControl = true;
            this.txtGhiChu.Location = new System.Drawing.Point(82, 413);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(240, 45);
            this.txtGhiChu.TabIndex = 19;
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(8, 233);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(31, 13);
            this.labelControl16.TabIndex = 5;
            this.labelControl16.Text = "Major:";
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(10, 415);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(23, 13);
            this.labelControl11.TabIndex = 15;
            this.labelControl11.Text = "Note";
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(8, 206);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(42, 13);
            this.labelControl15.TabIndex = 5;
            this.labelControl15.Text = "Literacy:";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(10, 288);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(41, 13);
            this.labelControl8.TabIndex = 13;
            this.labelControl8.Text = "Position:";
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(10, 261);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(61, 13);
            this.labelControl10.TabIndex = 5;
            this.labelControl10.Text = "Department:";
            // 
            // chbTinhTrangHonNhan
            // 
            this.chbTinhTrangHonNhan.EnterMoveNextControl = true;
            this.chbTinhTrangHonNhan.Location = new System.Drawing.Point(177, 178);
            this.chbTinhTrangHonNhan.Name = "chbTinhTrangHonNhan";
            this.chbTinhTrangHonNhan.Properties.Caption = "Đã kết hôn/Độc thân";
            this.chbTinhTrangHonNhan.Size = new System.Drawing.Size(135, 19);
            this.chbTinhTrangHonNhan.TabIndex = 8;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(10, 103);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(44, 13);
            this.labelControl3.TabIndex = 0;
            this.labelControl3.Text = "Birthday:";
            // 
            // txtEngTen
            // 
            this.txtEngTen.EnterMoveNextControl = true;
            this.txtEngTen.Location = new System.Drawing.Point(82, 74);
            this.txtEngTen.Name = "txtEngTen";
            this.txtEngTen.Size = new System.Drawing.Size(240, 20);
            this.txtEngTen.TabIndex = 3;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(8, 314);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(58, 13);
            this.labelControl4.TabIndex = 0;
            this.labelControl4.Text = "Home town:";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(8, 77);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(51, 13);
            this.labelControl2.TabIndex = 0;
            this.labelControl2.Text = "Eng name:";
            // 
            // txtTen
            // 
            this.txtTen.EnterMoveNextControl = true;
            this.txtTen.Location = new System.Drawing.Point(82, 48);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(240, 20);
            this.txtTen.TabIndex = 2;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(10, 51);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(47, 13);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "VN Name:";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(8, 390);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(54, 13);
            this.labelControl7.TabIndex = 0;
            this.labelControl7.Text = "Start work:";
            // 
            // txtEmail
            // 
            this.txtEmail.EnterMoveNextControl = true;
            this.txtEmail.Location = new System.Drawing.Point(82, 361);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(240, 20);
            this.txtEmail.TabIndex = 17;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(8, 364);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(28, 13);
            this.labelControl6.TabIndex = 0;
            this.labelControl6.Text = "Email:";
            // 
            // txtSoDT
            // 
            this.txtSoDT.EnterMoveNextControl = true;
            this.txtSoDT.Location = new System.Drawing.Point(82, 337);
            this.txtSoDT.Name = "txtSoDT";
            this.txtSoDT.Properties.Mask.EditMask = "d";
            this.txtSoDT.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSoDT.Size = new System.Drawing.Size(240, 20);
            this.txtSoDT.TabIndex = 16;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(8, 340);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(34, 13);
            this.labelControl5.TabIndex = 0;
            this.labelControl5.Text = "Phone:";
            // 
            // txtMa
            // 
            this.txtMa.EnterMoveNextControl = true;
            this.txtMa.Location = new System.Drawing.Point(82, 23);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(240, 20);
            this.txtMa.TabIndex = 1;
            // 
            // lvlMa
            // 
            this.lvlMa.Location = new System.Drawing.Point(10, 26);
            this.lvlMa.Name = "lvlMa";
            this.lvlMa.Size = new System.Drawing.Size(54, 13);
            this.lvlMa.TabIndex = 0;
            this.lvlMa.Text = "Staff code:";
            // 
            // txtQueQuan
            // 
            this.txtQueQuan.Location = new System.Drawing.Point(82, 312);
            this.txtQueQuan.Name = "txtQueQuan";
            this.txtQueQuan.Size = new System.Drawing.Size(240, 20);
            this.txtQueQuan.TabIndex = 15;
            // 
            // UC_Personal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_Personal";
            this.Size = new System.Drawing.Size(1045, 768);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgPersonals.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grcNhanVien)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoTK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoCMND.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chbGioiTinh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chbTinhTrangHonNhan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEngTen.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTen.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmail.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoDT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQueQuan.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private System.Windows.Forms.OpenFileDialog OpenFileDia;
        private DevExpress.XtraEditors.PictureEdit imgPersonals;
        private DevExpress.XtraGrid.GridControl grcNhanVien;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtSangBảngLươngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênTraineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênThaiSảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênĐãThôiViệcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênChínhThứcToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.ComboBox cbogroupteam;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtSoTK;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txtSoCMND;
        private System.Windows.Forms.ComboBox cboChucVu;
        private System.Windows.Forms.ComboBox cboBoPhan;
        private DevExpress.XtraEditors.CheckEdit chbGioiTinh;
        private DevExpress.XtraEditors.SimpleButton btnXoa;
        private DevExpress.XtraEditors.SimpleButton btnXacNhan;
        private DevExpress.XtraEditors.SimpleButton btnSua;
        private DevExpress.XtraEditors.SimpleButton btnAdd;
        private DevExpress.XtraEditors.MemoEdit txtGhiChu;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.CheckEdit chbTinhTrangHonNhan;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtEngTen;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtTen;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtEmail;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit txtSoDT;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtMa;
        private DevExpress.XtraEditors.LabelControl lvlMa;
        private DevExpress.XtraEditors.TextEdit txtQueQuan;
        private System.Windows.Forms.DateTimePicker dtNgayBatDau;
        private System.Windows.Forms.DateTimePicker dtngaysinh;
        private System.Windows.Forms.ToolStripMenuItem đãNộpĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đãHoànThànhNghĩaVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem TraineethôiviệctoolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem kếtthúcthaisảntoolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem rútĐơnToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private System.Windows.Forms.ComboBox cboOffice;
        private System.Windows.Forms.ComboBox cboChuyenMon;
        private System.Windows.Forms.ComboBox cboHocVan;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem PhieuDanhGiaStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewsToolStripMenuItem;
    }
}
