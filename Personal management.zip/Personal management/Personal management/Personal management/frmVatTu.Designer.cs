﻿namespace Personal_management
{
    partial class frmVatTu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVatTu));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboVatTu = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.searchVatTu = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSoLuong = new DevExpress.XtraEditors.TextEdit();
            this.label4 = new System.Windows.Forms.Label();
            this.dtInput = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.cboOffice = new System.Windows.Forms.ComboBox();
            this.cboDVT = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.searchDVT = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnXacNhan = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.cboVatTu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchVatTu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoLuong.Properties)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboDVT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchDVT)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Equipment:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Unit:";
            // 
            // cboVatTu
            // 
            this.cboVatTu.EditValue = "";
            this.cboVatTu.Location = new System.Drawing.Point(85, 7);
            this.cboVatTu.Name = "cboVatTu";
            this.cboVatTu.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboVatTu.Properties.View = this.searchVatTu;
            this.cboVatTu.Size = new System.Drawing.Size(379, 20);
            this.cboVatTu.TabIndex = 3;
            this.cboVatTu.EditValueChanged += new System.EventHandler(this.cboVatTu_EditValueChanged);
            // 
            // searchVatTu
            // 
            this.searchVatTu.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchVatTu.Name = "searchVatTu";
            this.searchVatTu.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchVatTu.OptionsView.ShowGroupPanel = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Quantity:";
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(85, 59);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Properties.Mask.EditMask = "d";
            this.txtSoLuong.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSoLuong.Size = new System.Drawing.Size(379, 20);
            this.txtSoLuong.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Date input:";
            // 
            // dtInput
            // 
            this.dtInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtInput.Location = new System.Drawing.Point(85, 86);
            this.dtInput.Name = "dtInput";
            this.dtInput.Size = new System.Drawing.Size(378, 21);
            this.dtInput.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelControl9);
            this.panel1.Controls.Add(this.cboOffice);
            this.panel1.Controls.Add(this.dtInput);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtSoLuong);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.cboDVT);
            this.panel1.Controls.Add(this.cboVatTu);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(474, 139);
            this.panel1.TabIndex = 7;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(19, 116);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(33, 13);
            this.labelControl9.TabIndex = 32;
            this.labelControl9.Text = "Office:";
            // 
            // cboOffice
            // 
            this.cboOffice.FormattingEnabled = true;
            this.cboOffice.Items.AddRange(new object[] {
            "Office 1",
            "Office 2"});
            this.cboOffice.Location = new System.Drawing.Point(85, 113);
            this.cboOffice.Name = "cboOffice";
            this.cboOffice.Size = new System.Drawing.Size(379, 21);
            this.cboOffice.TabIndex = 31;
            // 
            // cboDVT
            // 
            this.cboDVT.EditValue = "";
            this.cboDVT.Location = new System.Drawing.Point(85, 33);
            this.cboDVT.Name = "cboDVT";
            this.cboDVT.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboDVT.Properties.View = this.searchDVT;
            this.cboDVT.Size = new System.Drawing.Size(379, 20);
            this.cboDVT.TabIndex = 3;
            // 
            // searchDVT
            // 
            this.searchDVT.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchDVT.Name = "searchDVT";
            this.searchDVT.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchDVT.OptionsView.ShowGroupPanel = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnXacNhan);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 139);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(474, 30);
            this.panel5.TabIndex = 8;
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhan.Image")));
            this.btnXacNhan.Location = new System.Drawing.Point(406, 2);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(58, 25);
            this.btnXacNhan.TabIndex = 0;
            this.btnXacNhan.Text = "Save";
            this.btnXacNhan.ToolTip = "Lưu thông tin";
            this.btnXacNhan.Click += new System.EventHandler(this.btnXacNhan_Click);
            // 
            // frmVatTu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 171);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmVatTu";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vật tư - Trang thiết bị";
            this.Load += new System.EventHandler(this.frmVatTu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cboVatTu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchVatTu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoLuong.Properties)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboDVT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchDVT)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.SearchLookUpEdit cboVatTu;
        private DevExpress.XtraGrid.Views.Grid.GridView searchVatTu;
        private System.Windows.Forms.Label label3;
        private DevExpress.XtraEditors.TextEdit txtSoLuong;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtInput;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private DevExpress.XtraEditors.SimpleButton btnXacNhan;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private System.Windows.Forms.ComboBox cboOffice;
        private DevExpress.XtraEditors.SearchLookUpEdit cboDVT;
        private DevExpress.XtraGrid.Views.Grid.GridView searchDVT;
    }
}