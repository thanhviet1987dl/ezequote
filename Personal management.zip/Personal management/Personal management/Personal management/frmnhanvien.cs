﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class frmnhanvien : DevExpress.XtraEditors.XtraForm
    {
        UC_Personal uc = new UC_Personal();

        public frmnhanvien()
        {
            InitializeComponent();
            this.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }

    }
}