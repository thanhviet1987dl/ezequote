﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid;
using DevExpress.XtraSplashScreen;
using DevExpress.XtraTab;

namespace Personal_management
{
    public partial class UC_Personal : DevExpress.XtraEditors.XtraUserControl
    {
        Ezequote_personal ep = new Ezequote_personal();
        bool ktaddnew;
        string imagebyte;
        string _maNhanVien = "";
        string _tenNhanVien = "";
        int _idStatus = 0;

        public UC_Personal()
        {
            InitializeComponent();
            LoadBoPhan();
            LoadChucVu();
            LoadHocVan();
            LoadChuyenMon();
            FormatGrid_NhanVien();
            LoadGroupteam("No");
            LoadNhanVien();
            ReadOnly();
            btnXacNhan.Enabled = false;

        }

        #region Xử lý dữ liệu

        // Binding dữ liệu
        void AddBinding()
        {
            txtMa.DataBindings.Clear();
            txtMa.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "MaNV"));
            _maNhanVien = txtMa.Text;
            txtTen.DataBindings.Clear();
            txtTen.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "TenNV"));
            _tenNhanVien = txtTen.Text;
            txtEngTen.DataBindings.Clear();
            txtEngTen.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "TenEng"));
            dtngaysinh.DataBindings.Clear();
            dtngaysinh.DataBindings.Add(new Binding("Value", grcNhanVien.DataSource, "NgaySinh", true));
            cboBoPhan.DataBindings.Clear();
            cboBoPhan.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "TenBoPhan"));
            cboChucVu.DataBindings.Clear();
            cboChucVu.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "TenChucVu"));
            cbogroupteam.DataBindings.Clear();
            cbogroupteam.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "TenNhom"));
            txtQueQuan.DataBindings.Clear();
            txtQueQuan.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "QueQuan"));
            txtSoDT.DataBindings.Clear();
            txtSoDT.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "SoDT"));
            txtEmail.DataBindings.Clear();
            txtEmail.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "Email"));
            dtNgayBatDau.DataBindings.Clear();
            dtNgayBatDau.DataBindings.Add(new Binding("Value", grcNhanVien.DataSource, "NgayBatDau", true));
            //dtNgayKyHopDong.DataBindings.Clear();
            //dtNgayKyHopDong.DataBindings.Add(new Binding("EditValue", grcNhanVien.DataSource, "NgayKyHopDong", true));
            txtGhiChu.DataBindings.Clear();
            txtGhiChu.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "GhiChu"));
            txtSoCMND.DataBindings.Clear();
            txtSoCMND.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "SoCMND"));
            txtSoTK.DataBindings.Clear();
            txtSoTK.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "SoTaiKhoan"));
            cboOffice.DataBindings.Clear();
            cboOffice.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "VP"));
            cboHocVan.DataBindings.Clear();
            cboHocVan.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "HocVan"));
            cboChuyenMon.DataBindings.Clear();
            cboChuyenMon.DataBindings.Add(new Binding("Text", grcNhanVien.DataSource, "ChuyenMon"));

            try
            {
                _idStatus = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("IDStatus").ToString());
            }
            catch { }

            //chbGioiTinh.Checked = Convert.ToBoolean(gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "GioiTinh"));
            //chbTinhTrangHonNhan.Checked = Convert.ToBoolean(gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "TinhTrangHonNhan"));

            try
            {
                string a = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "GioiTinh").ToString();
                if (a == "Nam")
                    chbGioiTinh.Checked = true;
                else
                    chbGioiTinh.Checked = false;
            }
            catch (Exception)
            {
                chbGioiTinh.Checked = false;
            }

            try
            {
                string a = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "TinhTrangHonNhan").ToString();
                if (a == "Đã kết hôn")
                    chbTinhTrangHonNhan.Checked = true;
                else
                    chbTinhTrangHonNhan.Checked = false;
            }
            catch (Exception)
            {
                chbTinhTrangHonNhan.Checked = false;
            }

            try
            {
                string a = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "HinhAnh").ToString();
                imgPersonals.Image = Corelib.ByteToImg(a);
            }
            catch (Exception)
            {
                this.imgPersonals.EditValue = global::Personal_management.Properties.Resources.noimage;
            }

            KiemTraUpdateTobangChamCong();
            //1 Lấy dữ liệu
            //Gridview.GetRowCelValue(Gridview.FocusRowHandle, "Tên FieldName")
            //2 Gán dữ liệu
            //Gridview.SetRowCelValue(Gridview.FocusRowHandle, "Tên FieldName", Giá trị cần gán)
        }

        // Nạp combobox bộ phận
        void LoadBoPhan()
        {
            var result = from c in ep.BoPhans select new { c.MaBoPhan, c.TenBoPhan };
            cboBoPhan.DataSource = result.ToList();
            cboBoPhan.DisplayMember = "TenBoPhan";
            cboBoPhan.ValueMember = "MaBoPhan";

            //loupBoPhan1.Properties.Items.AddRange(result);
            //foreach(var item in result)
            //{
            //    loupBoPhan1.Properties.Items.Add("", "");
            //    loupBoPhan1.Properties.Items.Add(item.TenBoPhan, item.TenBoPhan);
            //}
        }

        // Nạp combobox groupteam
        void LoadGroupteam(string _mabophan)
        {
            var result = from c in ep.GroupTeams select new { c.MaNhom, c.TenNhom };
            cbogroupteam.DataSource = result.ToList();
            cbogroupteam.DisplayMember = "TenNhom";
            cbogroupteam.ValueMember = "MaNhom";

            //loupBoPhan1.Properties.Items.AddRange(result);
            //foreach(var item in result)
            //{
            //    loupBoPhan1.Properties.Items.Add("", "");
            //    loupBoPhan1.Properties.Items.Add(item.TenBoPhan, item.TenBoPhan);
            //}
        }

        // Nạp dữ liệu học vấn
        void LoadHocVan()
        {
            var result = from c in ep.TrinhDoHocVans select new { c.ID, c.HocVan };
            cboHocVan.DataSource = result.ToList();
            cboHocVan.DisplayMember = "HocVan";
            cboHocVan.ValueMember = "ID";
        }

        // Nạp dữ liệu chuyên môn
        void LoadChuyenMon()
        {
            var result = from c in ep.TrinhDoChuyenMons select new { c.ID, c.ChuyenMon };
            cboChuyenMon.DataSource = result.ToList();
            cboChuyenMon.DisplayMember = "ChuyenMon";
            cboChuyenMon.ValueMember = "ID";
        }

        // Nạp combobox chức vụ
        void LoadChucVu()
        {
            var result = from c in ep.ChucVus select new { c.MaChucVu, c.TenChucVu };
            cboChucVu.DataSource = result.ToList();
            cboChucVu.DisplayMember = "TenChucVu";
            cboChucVu.ValueMember = "MaChucVu";
            //loupBoPhan.Text = "Bộ phận trực thuộc";
        }

        // Nạp danh sách nhân viên
        private void FormatGrid_NhanVien()
        {
            gridView1.Columns.Clear();
            string[] fields = { "MaNV", "TenNV", "TenEng","VP","HocVan","ChuyenMon","NgaySinh", "TenBoPhan", "TenChucVu",
                "GioiTinh", "TinhTrangHonNhan", "TenNhom", "QueQuan", "HinhAnh", "SoDT",
            "Email", "NgayBatDau","SoCMND", "SoTaiKhoan","NameStatus","IDStatus", "GhiChu"};

            string[] captions = { "Mã NV", "Họ tên", "Tên Eng","Office","Học vấn","Chuyên môn", "Ngày sinh", "Bộ phận", "Chức vụ",
                "Giới tính", "Tình trạng hôn nhân", "Team", "Quê quán", "Hình ảnh", "Số ĐT",
            "Email", "Ngày bắt đầu", "Số CMND", "Số tài khoản","Trạng thái","IDStatus", "Ghi chú"};

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;
            }

            gridView1.Columns["TenNhom"].Visible = false;
            gridView1.Columns["HinhAnh"].Visible = false;
            gridView1.Columns["IDStatus"].Visible = false;
            //gridView1.Columns[11].Visible = false;
            //gridView1.Columns[12].Visible = false;
            //gridView1.Columns[13].Visible = false;
            gridView1.Columns["TenNV"].Width = 200;
        }

        void LoadNhanVien()
        {
            var result = from c in ep.NhanViens
                         where c.IsDelete == false && c.IDStatus != 6
                         //orderby c.BoPhan
                         select new
                         {
                             c.MaNV,
                             c.TenNV,
                             c.TenEng,
                             c.NgaySinh,
                             c.BoPhan.TenBoPhan,
                             c.ChucVu.TenChucVu,                             
                             GioiTinh = (c.GioiTinh != true) ? "Nữ" : "Nam",
                             TinhTrangHonNhan = (c.TinhTrangHonNhan != true) ? "Chưa kết hôn" : "Đã kết hôn",
                             c.GroupTeam.TenNhom,
                             c.QueQuan,
                             c.HinhAnh,
                             c.SoDT,
                             c.Email,
                             c.NgayBatDau,
                             //c.NgayKyHopDong,
                             c.GhiChu,
                             c.SoCMND,
                             c.SoTaiKhoan,
                             c.IDStatus,
                             c.Status.NameStatus,
                             c.VP,
                             c.TrinhDoHocVan.HocVan,
                             c.TrinhDoChuyenMon.ChuyenMon

                         };
            grcNhanVien.DataSource = result.ToList();
            gridView1.BestFitColumns();

            //Group by theo bộ phận
            //gridView1.Columns["TenBoPhan"].GroupIndex = 1;
            // gridView1.Columns["TenNhom"].GroupIndex = 1;
        }

        // Status Read only chỉ cho phép đọc
        void ReadOnly()
        {
            txtMa.ReadOnly = true;
            txtTen.ReadOnly = true;
            txtEngTen.ReadOnly = true;
            //loupChucVu.ReadOnly = true;
            //loupBoPhan.ReadOnly = true;
            //rdbgioitinh.ReadOnly = true;
            chbTinhTrangHonNhan.ReadOnly = true;
            chbGioiTinh.ReadOnly = true;
            txtQueQuan.ReadOnly = true;
            txtSoDT.ReadOnly = true;
            txtEmail.ReadOnly = true;
            //dtNgayKyHopDong.ReadOnly = true;
            txtGhiChu.ReadOnly = true;
            txtSoCMND.ReadOnly = true;
            txtSoTK.ReadOnly = true;

        }

        // Status Unread only và xóa dữ liệu để thực hiện thêm mới dữ liệu
        void UnReadOnlyandClear()
        {
            txtMa.ReadOnly = true;
            txtTen.ReadOnly = false;
            txtEngTen.ReadOnly = false;
            dtngaysinh.Value = DateTime.Now;
            chbGioiTinh.ReadOnly = false;
            chbTinhTrangHonNhan.ReadOnly = false;
            txtQueQuan.ReadOnly = false;
            txtSoDT.ReadOnly = false;
            txtEmail.ReadOnly = false;
            dtNgayBatDau.Value = DateTime.Now;
            //dtNgayKyHopDong.ReadOnly = false;
            txtGhiChu.ReadOnly = false;
            txtSoCMND.ReadOnly = false;
            txtSoTK.ReadOnly = false;

            txtMa.Text = "";
            txtTen.Text = "";
            txtEngTen.Text = "";
            txtQueQuan.Text = "";
            txtSoDT.Text = "";
            txtEmail.Text = "";
            txtGhiChu.Text = "";
            txtSoCMND.Text = "";
            txtSoTK.Text = "";
        }

        // Status Unread only để thực hiện update mới dữ liệu
        void UnReadOnly()
        {
            txtMa.ReadOnly = true;
            txtTen.ReadOnly = false;
            txtEngTen.ReadOnly = false;
            chbGioiTinh.ReadOnly = false;
            chbTinhTrangHonNhan.ReadOnly = false;
            txtQueQuan.ReadOnly = false;
            txtSoDT.ReadOnly = false;
            txtEmail.ReadOnly = false;
            //dtNgayKyHopDong.ReadOnly = false;
            txtGhiChu.ReadOnly = false;
            txtSoCMND.ReadOnly = false;
            txtSoTK.ReadOnly = false;
        }

        // Hàm thêm mới nhân viên
        void AddNhanVien()
        {
            string _MaNV = txtMa.Text;
            string _MaChucVu = Convert.ToString(cboChucVu.SelectedValue);
            string _MaBoPhan = Convert.ToString(cboBoPhan.SelectedValue);
            string _MaNhom = Convert.ToString(cbogroupteam.SelectedValue);
            int _HocVan = Convert.ToInt32(cboHocVan.SelectedValue);
            int _ChuyenMon = Convert.ToInt32(cboChuyenMon.SelectedValue);
            string _TenNV = txtTen.Text;
            string _TenEng = txtEngTen.Text;
            string _VP = cboOffice.SelectedItem.ToString();
            DateTime _NgaySinh = Convert.ToDateTime(dtngaysinh.Value.ToString());
            bool _GioiTinh = true;
            if (chbGioiTinh.Checked == true)
                _GioiTinh = true;
            else
                _GioiTinh = false;

            bool _TinhTrangHonNhan = true;
            if (chbTinhTrangHonNhan.Checked == true)
                _TinhTrangHonNhan = true;
            else
                _TinhTrangHonNhan = false;

            string _QueQuan = txtQueQuan.Text;
            string _SoDT = txtSoDT.Text;
            string _Email = txtEmail.Text;
            DateTime _NgayBatDau = Convert.ToDateTime(dtNgayBatDau.Value.ToString());
            //DateTime _NgayKyHopDong = Convert.ToDateTime(dtNgayKyHopDong.EditValue.ToString());
            string _GhiChu = txtGhiChu.Text;
            string _SoCMND = txtSoCMND.Text;
            string _SoTaiKhoan = txtSoTK.Text;


            NhanVien nv = new NhanVien()
            {
                MaNV = _MaNV,
                MaChucVu = _MaChucVu,
                MaBoPhan = _MaBoPhan,
                TenNV = _TenNV,
                TenEng = _TenEng,
                NgaySinh = _NgaySinh,
                GioiTinh = _GioiTinh,
                TinhTrangHonNhan = _TinhTrangHonNhan,
                QueQuan = _QueQuan,
                SoDT = _SoDT,
                Email = _Email,
                NgayBatDau = _NgayBatDau,
                //NgayKyHopDong = _NgayKyHopDong,
                GhiChu = _GhiChu,
                HinhAnh = imagebyte,
                IsDelete = false,
                SoCMND = _SoCMND,
                SoTaiKhoan = _SoTaiKhoan,
                MaNhom = _MaNhom,

                // IDStatus = 1: Waiting
                // IDStatus = 2: Trainee
                // IDStatus = 3: Đã ký hợp đồng
                // IDStatus = 4: Thai sản
                // IDStatus = 4: Đã nộp đơn xin thôi việc
                // IDStatus = 5: Đã nghỉ việc
                IDStatus = 1,
                VP = _VP,
                IDHocVan = _HocVan,
                IDChuyenMon = _ChuyenMon


            };
            ep.NhanViens.Add(nv);
            ep.SaveChanges();
        }

        // Hàm xóa nhân viên
        void XoaNhanVien()
        {
            //NhanVien nv = ep.NhanViens.Where(p => p.MaNV == txtMa.Text).SingleOrDefault();
            //ep.NhanViens.Remove(nv);
            //ep.SaveChanges();
            NhanVien nv = ep.NhanViens.Find(txtMa.Text);
            nv.IsDelete = true;
            ep.SaveChanges();
        }

        // Hàm sửa thông tin nhân viên
        void SuaNhanVien()
        {
            NhanVien nv = ep.NhanViens.Find(txtMa.Text);
            nv.MaChucVu = Convert.ToString(cboChucVu.SelectedValue);
            nv.MaBoPhan = Convert.ToString(cboBoPhan.SelectedValue);
            nv.IDHocVan = Convert.ToInt32(cboHocVan.SelectedValue);
            nv.IDChuyenMon = Convert.ToInt32(cboChuyenMon.SelectedValue);
            nv.TenNV = txtTen.Text;
            nv.TenEng = txtEngTen.Text;
            nv.NgaySinh = Convert.ToDateTime(dtngaysinh.Value.ToString());
            //bool _GioiTinh = true;
            if (chbGioiTinh.Checked == true)
                nv.GioiTinh = true;
            else
                nv.GioiTinh = false;

            //bool _TinhTrangHonNhan = true;
            if (chbTinhTrangHonNhan.Checked == true)
                nv.TinhTrangHonNhan = true;
            else
                nv.TinhTrangHonNhan = false;

            nv.QueQuan = txtQueQuan.Text;
            nv.SoDT = txtSoDT.Text;
            nv.Email = txtEmail.Text;
            nv.NgayBatDau = Convert.ToDateTime(dtNgayBatDau.Value.ToString());
            //if (dtNgayKyHopDong.SelectedText == "")
            //    dtNgayKyHopDong.DateTime.ToString();
            //else
            //    nv.NgayKyHopDong = Convert.ToDateTime(dtNgayKyHopDong.EditValue);
            nv.GhiChu = txtGhiChu.Text;
            nv.HinhAnh = imagebyte;
            nv.SoCMND = txtSoCMND.Text;
            nv.SoTaiKhoan = txtSoTK.Text;
            nv.MaNhom = Convert.ToString(cbogroupteam.SelectedValue);
            nv.VP = cboOffice.SelectedItem.ToString();
            ep.SaveChanges();

        }

        void KiemTraUpdateTobangChamCong()
        {
            var kiemtradacotrongbangchamcong = from c in ep.ChamCongs
                                               where c.MaNV == _maNhanVien && c.Thang == DateTime.Now.Month.ToString() && c.Nam == DateTime.Now.Year.ToString()
                                               select new
                                               {
                                                   c.MaNV
                                               };

            if (kiemtradacotrongbangchamcong.Count() == 1)
                cậpNhậtSangBảngLươngToolStripMenuItem.Enabled = false;
        }

        #endregion

        #region Event   

        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            AddBinding();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            LoadBoPhan();
            LoadChucVu();
            LoadGroupteam("NO");
            ktaddnew = true;
            UnReadOnlyandClear();
            txtMa.Text = Corelib.maTuTang("EZE", Convert.ToInt32(ep.NhanViens.Count().ToString()));
            btnXacNhan.Enabled = true;
            btnAdd.Enabled = false;
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            //XtraMessageBox.Show(cboBoPhan.SelectedValue.ToString());   
        }

        bool KiemTraNull()
        {
            if (string.IsNullOrEmpty(txtTen.Text))
            {
                txtTen.Focus();
                errorProvider1.SetError(txtTen, "Chưa nhập họ tên");
                return false;
            }

            if (string.IsNullOrEmpty(txtEngTen.Text))
            {
                txtEngTen.Focus();
                errorProvider1.SetError(txtEngTen, "Chưa nhập tên tiếng anh");
                return false;
            }

            if (string.IsNullOrEmpty(txtSoCMND.Text))
            {
                txtSoCMND.Focus();
                errorProvider1.SetError(txtSoCMND, "Chưa nhập số CMND/Hộ chiếu");
                return false;
            }

            if (cboBoPhan.SelectedIndex == -1)
            {
                cboBoPhan.Focus();
                errorProvider1.SetError(cboBoPhan, "Chưa chọn bộ phận");
                return false;
            }

            if (cboChucVu.SelectedIndex == -1)
            {
                cboChucVu.Focus();
                errorProvider1.SetError(cboChucVu, "Chưa chọn chức vụ");
                return false;
            }

            return true;
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            if (ktaddnew == true)
            {
                if (KiemTraNull())
                {
                    AddNhanVien();
                    XtraMessageBox.Show("Thêm mới nhân viên thành công.", "Thông báo", MessageBoxButtons.OK);
                    btnAdd.Enabled = true;
                    ReadOnly();
                    LoadNhanVien();
                    btnXacNhan.Enabled = false;
                    btnAdd.Enabled = true;
                    btnXoa.Enabled = true;
                    btnSua.Enabled = true;
                }

            }

            if (ktaddnew == false)
            {
                SuaNhanVien();
                XtraMessageBox.Show("Cập nhật dữ liệu cho " + txtTen.Text + " thành công.", "Thông báo", MessageBoxButtons.OK);
                btnSua.Enabled = true;
                ReadOnly();
                LoadNhanVien();
                btnXacNhan.Enabled = false;
                btnSua.Enabled = true;
                btnXoa.Enabled = true;
                btnAdd.Enabled = true;
            }

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dlg = XtraMessageBox.Show("Bạn có chắc chắn muốn xóa nhân viên này không?", "Thông báo", MessageBoxButtons.YesNo);
            if (dlg == DialogResult.Yes)
            {
                XoaNhanVien();
                LoadNhanVien();
            }

        }

        private void imgPersonals_DoubleClick(object sender, EventArgs e)
        {
            if (OpenFileDia.ShowDialog() == DialogResult.OK)
            {
                string pathimage = OpenFileDia.FileName;
                imgPersonals.Image = Image.FromFile(pathimage);
                imagebyte = Convert.ToBase64String(Corelib.converImgToByte(pathimage));
            }
        }

        private void gridView1_RowStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs e)
        {
            GridView View = sender as GridView;
            if (e.RowHandle >= 0)
            {
                string _gioitinh = View.GetRowCellDisplayText(e.RowHandle, View.Columns["GioiTinh"]);
                if (_gioitinh == "Nam")
                {
                    e.Appearance.BackColor = Color.Salmon;
                    e.Appearance.BackColor2 = Color.SeaShell;
                    e.HighPriority = true;
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            btnSua.Enabled = false;
            ktaddnew = false;
            UnReadOnly();
            btnXacNhan.Enabled = true;
            btnAdd.Enabled = false;
            btnXoa.Enabled = false;

        }

        #endregion

        #region In trực tiếp trên gridview
        private void ShowGridPreview(GridControl grid)
        {
            // Check whether the GridControl can be previewed. 
            if (!grid.IsPrintingAvailable)
            {
                XtraMessageBox.Show("The 'DevExpress.XtraPrinting' library is not found", "Error");
                return;
            }

            // Open the Preview window. 
            grid.ShowPrintPreview();
        }

        private void PrintGrid(GridControl grid)
        {
            // Check whether the GridControl can be printed. 
            if (!grid.IsPrintingAvailable)
            {
                XtraMessageBox.Show("The 'DevExpress.XtraPrinting' library is not found", "Error");
                return;
            }

            // Print. 
            grid.Print();
        }



        #endregion

        #region Xử lý đánh số thứ tự
        private void gridView1_CustomDrawRowIndicator(object sender, RowIndicatorCustomDrawEventArgs e)
        {
            if (!gridView1.IsGroupRow(e.RowHandle)) //Nếu không phải là Group
            {
                if (e.Info.IsRowIndicator) //Nếu là dòng Indicator
                {
                    if (e.RowHandle < 0)
                    {
                        e.Info.ImageIndex = 0;
                        e.Info.DisplayText = string.Empty;
                    }
                    else
                    {
                        e.Info.ImageIndex = -1; //Không hiển thị hình
                        e.Info.DisplayText = (e.RowHandle + 1).ToString(); //Số thứ tự tăng dần
                    }

                    //hàm này dùng thay đổi độ rộng mặc định của cột số thứ tự
                    var _Size = e.Graphics.MeasureString(e.Info.DisplayText, e.Appearance.Font);
                    var _Width = Convert.ToInt32(_Size.Width) + 20;
                    BeginInvoke(new MethodInvoker(delegate { cal(_Width, gridView1); }));
                }
            }
            else
            {
                e.Info.ImageIndex = -1;
                e.Info.DisplayText = string.Format("[{0}]", e.RowHandle * -1); //Nhân -1 để đánh lại số thứ tự tăng dần
                var _Size = e.Graphics.MeasureString(e.Info.DisplayText, e.Appearance.Font);
                var _Width = Convert.ToInt32(_Size.Width) + 20;
                BeginInvoke(new MethodInvoker(delegate { cal(_Width, gridView1); }));
            }
        }

        private bool cal(int _Width, GridView _View)
        {
            _View.IndicatorWidth = _View.IndicatorWidth < _Width ? _Width : _View.IndicatorWidth;
            return true;
        }



        #endregion

        private void cậpNhậtSangBảngLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChamCong ccong = new ChamCong()
            {
                MaNV = _maNhanVien,
                Thang = DateTime.Now.Month.ToString(),
                Nam = DateTime.Now.Year.ToString(),
                TongPhep = 12,
                PhepConLai = 12,
                NgayNghi = 0,
                VeSom = 0,
                DiTre = 0,
                DateOTCuoiTuan = 0,
                TimeOTCuoiTuan = 0,
                IsLock = 0,

            };
            ep.ChamCongs.Add(ccong);
            if (ep.SaveChanges() > 0)
                XtraMessageBox.Show("Đã cập nhật thành công sang bảng chấm công.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void nhânViênTraineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_idStatus == 1)
            {
                frmNhanVienThuViec frm = new frmNhanVienThuViec();
                frm.MaNhanVien = _maNhanVien;
                if (frm.ShowDialog() == DialogResult.OK)
                    LoadNhanVien();
            }
            else
                if (_idStatus == 2)
                XtraMessageBox.Show("Nhân viên bạn đang chọn đang trong quá trình thử việc.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
                XtraMessageBox.Show("Nhân viên bạn đang chọn đã hoàn thành quá trình thử việc.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void nhânViênThaiSảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Kiểm tra nhân viên thai sản phải 
            // là nhân viên nữ mới hiển thị cửa sổ bổ sung thông tin
            if (chbGioiTinh.Checked == false)
            {
                // Kiểm tra nếu đang thai sản thì không đc thực hiện chức năng này
                if (_idStatus == 4)
                    XtraMessageBox.Show("Nhân viên bạn đang chọn đang trong thời gian thai sản. Vui lòng kiểm tra lại.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    frmNhanVienThaiSan frm = new frmNhanVienThaiSan();
                    frm.MaNhanVien = _maNhanVien;
                    frm.TenNhanVien = _tenNhanVien;
                    if (frm.ShowDialog() == DialogResult.OK)
                        LoadNhanVien();
                }
            }
            else
                XtraMessageBox.Show("Nhân viên bạn đang chọn là Nam. Vui lòng kiểm tra lại.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void đãNộpĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_idStatus == 5)
                XtraMessageBox.Show("Nhân viên bạn đang chọn đang trong thời gian chờ. Vui lòng kiểm tra lại.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            if (_idStatus == 2)
                XtraMessageBox.Show("Nhân viên bạn đang chọn đang trong thời gian Trainee. Không cần làm thêm 45 ngày", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                frmNhanVienNghiViec frm = new frmNhanVienNghiViec();
                frm.MaNhanVien = _maNhanVien;
                frm.TenNhanVien = _tenNhanVien;
                if (frm.ShowDialog() == DialogResult.OK)
                    LoadNhanVien();
            }
        }

        private void nhânViênChínhThứcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem nhân viên đã ký hợp đồng hay chưa.
            // Nếu chưa ký mới được thực hiện chức năng này.
            // Nếu ký rồi thì hiện thông báo.
            if (_idStatus == 1 || _idStatus == 2)
            {
                NhanVien nv = ep.NhanViens.Find(txtMa.Text);
                nv.IDStatus = 3;
                if (XtraMessageBox.Show("Bạn chắc chắn là nhân viên " + txtTen.Text + " đã được ký hợp đồng.", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ep.SaveChanges();
            }
            else
                XtraMessageBox.Show("Nhân viên bạn đang chọn đã được ký hợp đồng trước đó. Vui lòng kiểm tra lại.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            LoadNhanVien();
        }

        private void đãHoànThànhNghĩaVụToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_idStatus == 5)
            {
                NhanVien nv = ep.NhanViens.Find(txtMa.Text);
                nv.IDStatus = 6;
                if (XtraMessageBox.Show("Bạn chắc chắn là nhân viên " + txtTen.Text + " đã hoàn thành đủ 45 ngày làm việc kể từ ngày nộp đơn xin thôi việc.", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ep.SaveChanges();
            }
            else
                XtraMessageBox.Show("Nhân viên bạn đang chọn chưa nộp đơn xin thôi việc. Vui lòng kiểm tra lại.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            LoadNhanVien();
        }

        private void TraineethôiviệctoolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (_idStatus == 2)
            {
                NhanVien nv = ep.NhanViens.Find(txtMa.Text);
                nv.IDStatus = 6;
                if (XtraMessageBox.Show("Bạn chắc chắn là nhân viên " + txtTen.Text + " đã nghỉ việc", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    ep.SaveChanges();
                    NhanVienNghiViec nvnghiviec = new NhanVienNghiViec()
                    {
                        MaNV = _maNhanVien,
                        TuNgay = DateTime.Now,
                        DenNgay = DateTime.Now
                    };
                    ep.NhanVienNghiViecs.Add(nvnghiviec);
                    ep.SaveChanges();
                }
            }
            LoadNhanVien();

        }

        private void kếtthúcthaisảntoolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (_idStatus == 4)
            {
                NhanVien nv = ep.NhanViens.Find(txtMa.Text);
                nv.IDStatus = 3;
                if (XtraMessageBox.Show("Nhân viên " + txtTen.Text + " đã hoàn thành thời gian thai sản.", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ep.SaveChanges();
            }

            LoadNhanVien();
        }

        private void rútĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem nhân viên đã ký hợp đồng hay chưa.
            // Nếu chưa ký mới được thực hiện chức năng này.
            // Nếu ký rồi thì hiện thông báo.
            if (_idStatus == 5)
            {
                NhanVien nv = ep.NhanViens.Find(txtMa.Text);
                nv.IDStatus = 3;
                if (XtraMessageBox.Show("Bạn chắc chắn là nhân viên " + txtTen.Text + " đã rút đơn xin thôi việc.", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    ep.SaveChanges();
            }
            else
                XtraMessageBox.Show("Nhân viên bạn đang chọn đã được ký hợp đồng trước đó. Vui lòng kiểm tra lại.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            LoadNhanVien();
        }

        private void cbogroupteam_DropDown(object sender, EventArgs e)
        {
            LoadGroupteam("oo");
        }

        private void cboBoPhan_DropDown(object sender, EventArgs e)
        {
            LoadBoPhan();
        }

        private void cboChucVu_DropDown(object sender, EventArgs e)
        {
            LoadChucVu();
        }

        private void cboHocVan_DropDown(object sender, EventArgs e)
        {
            LoadHocVan();
        }

        private void cboChuyenMon_DropDown(object sender, EventArgs e)
        {
            LoadChuyenMon();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPhieuDanhGia frm = new frmPhieuDanhGia();
            frm._MaNV = _maNhanVien;
            frm._ThemMoi = "Insert";
            frm.ShowDialog();
        }

        private void viewsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDanhSachPhieuDanhGia frm = new frmDanhSachPhieuDanhGia();
            frm._MaNV = _maNhanVien;
            frm.ShowDialog();
        }
    }
}
