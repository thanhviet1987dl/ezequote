﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;

namespace Personal_management
{
    public partial class frmCTNhapVatTu : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        int index = -1;
        public frmCTNhapVatTu()
        {
            InitializeComponent();
            LoadNam();
            NapDanhSachVatTu(DateTime.Today.Month, DateTime.Today.Year);
        }

        void NapDanhSachVatTu(int thang, int nam)
        {
            gridView1.Columns.Clear();
            string[] fields = { "ID", "Office", "TenVatTu", "NgayNhap", "SoLuong", "DVT" };

            string[] captions = { "ID", "Office", "Equipment", "Date Input", "Quantity", "Unit" };

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;

            }
            gridView1.Columns["ID"].Visible = false;



            // set autocolumnwith = false
            // sau đó bật thuộc tính bestfitcolumn để tự chỉnh độ rộng theo độ rộng nội dung
            gridView1.BestFitColumns();

            var result = from c in ep.ChiTietNhaps
                         join c2 in ep.DonViTinhs on c.DVT equals c2.ID
                         where c.NgayNhap.Value.Month == thang && c.NgayNhap.Value.Year == nam
                         select new { c.ID, c.Office, c.VatTu.TenVatTu, c.NgayNhap, c.SoLuong, c2.DVT };
            grcChiTietVatTu.DataSource = result.ToList();
        }

        void NapDanhSachVatTu(int nam)
        {
            gridView1.Columns.Clear();
            string[] fields = { "ID", "Office", "TenVatTu", "NgayNhap", "SoLuong", "DVT" };

            string[] captions = { "ID", "Office", "Equipment", "Date Input", "Quantity", "Unit" };

            for (int i = 0; i < fields.Length; i++)
            {
                DevExpress.XtraGrid.Columns.GridColumn col = new DevExpress.XtraGrid.Columns.GridColumn();
                col.FieldName = fields[i];
                col.Caption = captions[i];
                gridView1.Columns.Add(col);
                gridView1.Columns[i].Visible = true;
                gridView1.Columns[i].OptionsColumn.AllowEdit = false;

            }
            gridView1.Columns["ID"].Visible = false;



            // set autocolumnwith = false
            // sau đó bật thuộc tính bestfitcolumn để tự chỉnh độ rộng theo độ rộng nội dung
            gridView1.BestFitColumns();

            var result = from c in ep.ChiTietNhaps
                         join c2 in ep.DonViTinhs on c.DVT equals c2.ID
                         where c.NgayNhap.Value.Year == nam
                         select new { c.ID, c.Office, c.VatTu.TenVatTu, c.NgayNhap, c.SoLuong, c2.DVT };
            grcChiTietVatTu.DataSource = result.ToList();
        }

        void LoadNam()
        {
            cboNam.Items.Clear();
            for (int i = 2014; i <= DateTime.Now.Year; i++)
            {
                cboNam.Items.Add(i);
            }
        }

        private void addNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVatTu frm = new frmVatTu();
            frm._KiemTraThemMoi = "Insert";
            if (frm.ShowDialog() == DialogResult.OK)
            {
                NapDanhSachVatTu(DateTime.Today.Month, DateTime.Today.Year);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVatTu frm = new frmVatTu();
            frm._KiemTraThemMoi = "Update";

            if (index == -1)
                XtraMessageBox.Show("Chưa có dữ liệu để cập nhật", "Thông báo", MessageBoxButtons.OK);
            else
            {
                frm._IDChiTietVatTu = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("ID").ToString());
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    NapDanhSachVatTu(DateTime.Today.Month, DateTime.Today.Year);
                }
            }

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int IDCanXoa = Convert.ToInt32(gridView1.GetFocusedRowCellDisplayText("ID").ToString());
            var itemToRemove = ep.ChiTietNhaps.SingleOrDefault(x => x.ID == IDCanXoa); //returns a single item.

            if (itemToRemove != null)
            {
                if (XtraMessageBox.Show("Bạn có chắc chắn muốn xóa vật tư này khỏi danh sách lưu trữ không", "Thông Báo", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    ep.ChiTietNhaps.Remove(itemToRemove);
                    ep.SaveChanges();
                }
            }

            NapDanhSachVatTu(DateTime.Today.Month, DateTime.Today.Year);
        }

        private void gridView1_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            index = e.FocusedRowHandle;
        }

        private void gridView1_RowStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs e)
        {
            try
            {
                GridView View = sender as GridView;
                if (e.RowHandle >= 0)
                {
                    string _Office = View.GetRowCellDisplayText(e.RowHandle, View.Columns["Office"]);
                    if (_Office == "Office 1")
                    {
                        e.Appearance.BackColor = Color.Blue;
                        e.Appearance.BackColor2 = Color.SeaShell;
                        e.HighPriority = true;
                    }
                }
            }
            catch { }

        }

        private void loadDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int _thang = -1;
            if ((cboThang.Text == "" || cboThang.Text == null))
                XtraMessageBox.Show("Chưa chọn tháng cần xem dữ liệu", "Thông Báo");
            if ((cboNam.Text == "" || cboNam.Text == null))
                XtraMessageBox.Show("Chưa chọn năm cần xem dữ liệu", "Thông Báo");
            else
            {
                switch (cboThang.SelectedItem.ToString())
                {
                    case "Tất cả":
                        _thang = 0;
                        break;
                    case "Tháng giêng":
                        _thang = 1;
                        break;
                    case "Tháng 2":
                        _thang = 2;
                        break;
                    case "Tháng 3":
                        _thang = 3;
                        break;
                    case "Tháng 4":
                        _thang = 4;
                        break;
                    case "Tháng 5":
                        _thang = 5;
                        break;
                    case "Tháng 6":
                        _thang = 6;
                        break;
                    case "Tháng 7":
                        _thang = 7;
                        break;
                    case "Tháng 8":
                        _thang = 8;
                        break;
                    case "Tháng 9":
                        _thang = 9;
                        break;
                    case "Tháng 10":
                        _thang = 10;
                        break;
                    case "Tháng 11":
                        _thang = 11;
                        break;
                    case "Tháng 12":
                        _thang = 12;
                        break;
                }

                if (_thang == 0)
                    NapDanhSachVatTu(Convert.ToInt32(cboNam.SelectedItem.ToString()));
                else
                    NapDanhSachVatTu(_thang, Convert.ToInt32(cboNam.SelectedItem.ToString()));
            }
        }

        private void frmCTNhapVatTu_Load(object sender, EventArgs e)
        {
            cboThang.SelectedIndex = 0;
            cboNam.SelectedIndex = cboNam.Items.Count-1;
        }
    }
}