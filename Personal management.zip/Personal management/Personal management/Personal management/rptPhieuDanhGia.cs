﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;
using System.Data;

namespace Personal_management
{
    public partial class rptPhieuDanhGia : DevExpress.XtraReports.UI.XtraReport
    {
        Ezequote_personal ep = new Ezequote_personal();
        public rptPhieuDanhGia()
        {
            InitializeComponent();
        }

        public void LoadData(string hoten, string teneng, string bophan, string chucvu, string gioitinh, DateTime ngaybatdau,
            double taptrung, double viecrieng, double ngaynghi, double kienthuc,
            double kynang, double langnghe, double giaotiep, double canthan, string laudai, string lanhdao, string note)
        {
            pHoTen.Value = hoten;
            pTenEng.Value = teneng;
            pBoPhan.Value = bophan;
            pChucVu.Value = chucvu;
            pGioiTinh.Value = gioitinh;
            pNgayBatDau.Value = ngaybatdau;
            pTapTrung.Value = taptrung;
            pViecRieng.Value = viecrieng;
            pSoNgayNghi.Value = ngaynghi;
            pKienThuc.Value = kienthuc;
            pKyNang.Value = kynang;
            pLangNghe.Value = langnghe;
            pGiaoTiep.Value = giaotiep;
            pCanThan.Value = canthan;
            pLauDai.Value = laudai;
            pLanhDao.Value = lanhdao;
            pNote.Value = note;
        }

    }
}
