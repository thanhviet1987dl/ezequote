﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Personal_management
{
    public partial class Check_License : DevExpress.XtraEditors.XtraForm
    {
        Ezequote_personal ep = new Ezequote_personal();
        public Check_License()
        {
            InitializeComponent();
            
            txtProductID.Text = Corelib.HardDiskSeriesNumber();
        }

        void KiemTraBanQuyenPhanMem()
        {
            string _Keyphanmem = Corelib.GetRequestLicenseCode();
            string _ProductID = Corelib.HardDiskSeriesNumber();
            var result = from c in ep.Licensecodes where c.ProductID == _ProductID && c.LicensecodeID == _Keyphanmem select new { c.ProductID, c.LicensecodeID };
            if (result.ToList().Count == 0)
            {
                XtraMessageBox.Show("Phần mềm chưa được kích hoạt bản quyền. Vui lòng gửi mã kích hoạt (ProductID) cho quản lý của bạn để được kích hoạt.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Show();
            } else
            {
                frmlogin frm = new frmlogin();
                frm.ShowDialog();
                this.Close();
            }
        }

        private void btnActive_Click(object sender, EventArgs e)
        {
            Licensecode licen = new Licensecode()
            {
                ProductID = txtProductID.Text,
                LicensecodeID = txtLicence.Text
            };
            ep.Licensecodes.Add(licen);
            if (ep.SaveChanges() > 0)
            {
                XtraMessageBox.Show("Kích hoạt thành công.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                frmlogin frm = new frmlogin();
                frm.ShowDialog();
                this.Close();
            }
                
            else
                XtraMessageBox.Show("Kích hoạt không thành công.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Check_License_Load(object sender, EventArgs e)
        {
            KiemTraBanQuyenPhanMem();
        }
    }
}